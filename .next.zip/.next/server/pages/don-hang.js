(() => {
var exports = {};
exports.id = 441;
exports.ids = [441];
exports.modules = {

/***/ 989:
/***/ ((module) => {

// Exports
module.exports = {
	"form": "Order_form__CmED1",
	"control": "Order_control__G1qtC",
	"cart-items": "Order_cart-items___nNY_",
	"total": "Order_total__ObazO",
	"actions": "Order_actions__UuZQ3",
	"button--alt": "Order_button--alt__FKk4k",
	"button": "Order_button__IZ8RX"
};


/***/ }),

/***/ 2869:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4516);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8612);
/* harmony import */ var _components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2678);
/* harmony import */ var _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1556);
/* harmony import */ var _components_elements_navigation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7641);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _slices_cartSlice__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(633);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_elements_cart_Cart__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1684);
/* harmony import */ var _Order_module_css__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(989);
/* harmony import */ var _Order_module_css__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_Order_module_css__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7631);
/* harmony import */ var store_actions_cart_actions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8724);
/* harmony import */ var _service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2065);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_4__, _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_5__, _api__WEBPACK_IMPORTED_MODULE_12__, _service__WEBPACK_IMPORTED_MODULE_14__]);
([_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_4__, _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_5__, _api__WEBPACK_IMPORTED_MODULE_12__, _service__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







// sử dụng redux









const OrdersCart = (props)=>{
    const { dataMenu , dataFooter  } = props;
    const [nameInputRef, setNameInputRef] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [phoneInputRef, setPhoneInputRef] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [emailInputRef, setEmailInputRef] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [addressInputRef, setAddressInputRef] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const descInputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const timeInputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    const [orderSucceeded, setOrderSucceeded] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [submitted, setSubmitted] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const cart = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.cart);
    const cartItems = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.cart.items);
    const [t, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_languages_vie_json__WEBPACK_IMPORTED_MODULE_2__);
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.language.currentLanguage);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (0,_languages__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(lang, setText);
    }, [
        lang
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (cart) {
            (0,store_actions_cart_actions__WEBPACK_IMPORTED_MODULE_13__/* .saveCartData */ .Q)(cart);
        }
    }, [
        cart
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const customerInfoString = localStorage.getItem("customerInfo");
        if (customerInfoString) {
            const customerInfo = JSON.parse(customerInfoString);
            if (customerInfo) {
                const { name , phone , email , address  } = customerInfo;
                setNameInputRef(name);
                setPhoneInputRef(phone);
                setEmailInputRef(email);
                setAddressInputRef(address);
            }
        }
    }, []);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useDispatch)();
    const { TextArea  } = antd__WEBPACK_IMPORTED_MODULE_9__.Input;
    const pageSEOData = {
        name: "Thương Thương",
        pageSEO: {
            title: "Đơn H\xe0ng | Thương Thương",
            url: "https://www.critistudio.top/gioi-thieu",
            keywords: "website",
            description: "Thuong Thuong tổ chức đ\xe0o tạo nghề cho đối tượng người khuyết tật v\xe0 người yếu thế nhằm giảm g\xe1nh nặng cho gia đ\xecnh v\xe0 x\xe3 hội.",
            image: "https://www.critistudio.top/images/seo.jpg"
        }
    };
    const [values, setValues] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const onChange = (e)=>{
        console.log("radio checked", e.target.value);
        setValues(e.target.value);
    };
    const dataNavigation = [
        {
            id: 1,
            title: `${t.navigator.HOME}`,
            link: "/"
        },
        {
            id: 2,
            title: `${t.navigator.MENU6}`,
            link: "/"
        }
    ];
    // const selectedItems = cartItems.filter((item) => item.selected);
    const [selectedItems, setSelectedItems] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [totalOrderItems, setTotalOrderItems] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (cartItems) {
            const selecteditem = cartItems.filter((item)=>item.selected);
            setSelectedItems(selecteditem);
            const totalorderItems = selecteditem.reduce((currNumber, item)=>currNumber + item.quantity, 0);
            setTotalOrderItems(totalorderItems);
        }
    }, [
        cartItems
    ]);
    async function submitHandler(event) {
        event.preventDefault();
        const enteredName = nameInputRef;
        const enteredPhone = phoneInputRef;
        const enteredEmail = emailInputRef;
        const enteredAddress = addressInputRef;
        let time;
        switch(values){
            case 1:
                time = t.bills.DESCRIPTION2_1;
                break;
            case 2:
                time = t.bills.DESCRIPTION2_2;
                break;
            case 3:
                time = t.bills.DESCRIPTION2_3;
                break;
            default:
                time = timeInputRef.current?.value;
                break;
        }
        const customerInfo = {
            name: enteredName,
            phone: enteredPhone,
            email: enteredEmail,
            address: enteredAddress
        };
        localStorage.setItem("customerInfo", JSON.stringify(customerInfo));
        const orderData = {
            ...customerInfo,
            time: time,
            description: descInputRef.current?.value,
            products: selectedItems.map((item)=>{
                return {
                    productId: item.id,
                    quantity: item.quantity
                };
            })
        };
        try {
            await _api__WEBPACK_IMPORTED_MODULE_12__/* .Order.placeOrder */ .KM.placeOrder(orderData);
            dispatch(_slices_cartSlice__WEBPACK_IMPORTED_MODULE_8__/* .cartActions.removeItemFromCart */ .Uw.removeItemFromCart(selectedItems.map((item)=>item.id)));
            setOrderSucceeded(true);
        } catch (error) {
            setOrderSucceeded(false);
            console.log("Error when placing order ", error);
        } finally{
            setSubmitted(true);
        }
    }
    const nameChangeHandler = (event)=>{
        setNameInputRef(event.target.value);
    };
    const phoneChangeHandler = (event)=>{
        setPhoneInputRef(event.target.value);
    };
    const emailChangeHandler = (event)=>{
        setEmailInputRef(event.target.value);
    };
    const addressChangeHandler = (event)=>{
        setAddressInputRef(event.target.value);
    };
    const confirmHandler = ()=>{
        if (orderSucceeded) {
            router.push("/");
        }
        setSubmitted(false);
    };
    const url = `${"https://thuongthuonghandmade.vn"}/`;
    const image = "";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            "(",
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_9__.Modal, {
                centered: true,
                className: "products-cart-modal",
                onCancel: confirmHandler,
                visible: submitted,
                footer: [],
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "products-cart-modal-description",
                        children: orderSucceeded ? t.bills.TITLE9 : t.bills.TITLE10
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "products-cart-modal-group-btn2",
                        style: {
                            width: "30%",
                            marginLeft: "35%"
                        },
                        onClick: confirmHandler,
                        children: orderSucceeded ? t.bills.TITLE11 : t.bills.TITLE12
                    })
                ]
            }),
            ")",
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                pageSEO: pageSEOData.pageSEO,
                url: url,
                image: image
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                dataMenu: dataMenu,
                dataFooter: dataFooter,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                    className: (_Order_module_css__WEBPACK_IMPORTED_MODULE_15___default().form),
                    onSubmit: submitHandler,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "list-products",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "list-products-navigation",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_navigation__WEBPACK_IMPORTED_MODULE_6__/* .NavigationTopBar */ .a, {
                                    data: dataNavigation
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "products-cart-title",
                                children: t.bills.HEADER
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "products-bill",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "products-bill-block",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "products-bill-block-b1",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "products-bill-block-b1-title",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "products-bill-block-b1-title-text",
                                                            children: t.bills.TITLE1
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: (_Order_module_css__WEBPACK_IMPORTED_MODULE_15___default().control),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_9__.Input, {
                                                            type: "text",
                                                            required: true,
                                                            id: "name",
                                                            placeholder: t.bills.TITLE5,
                                                            value: nameInputRef,
                                                            onChange: nameChangeHandler
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: (_Order_module_css__WEBPACK_IMPORTED_MODULE_15___default().control),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_9__.Input, {
                                                            type: "text",
                                                            required: true,
                                                            id: "phone",
                                                            placeholder: t.bills.TITLE6,
                                                            pattern: "[0-9]{10,}",
                                                            value: phoneInputRef,
                                                            onChange: phoneChangeHandler
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: (_Order_module_css__WEBPACK_IMPORTED_MODULE_15___default().control),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_9__.Input, {
                                                            type: "email",
                                                            required: true,
                                                            id: "email",
                                                            placeholder: t.bills.TITLE7,
                                                            value: emailInputRef,
                                                            onChange: emailChangeHandler
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: (_Order_module_css__WEBPACK_IMPORTED_MODULE_15___default().control),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextArea, {
                                                            id: "address",
                                                            required: true,
                                                            rows: 5,
                                                            placeholder: t.bills.TITLE8,
                                                            value: addressInputRef,
                                                            onChange: addressChangeHandler
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "products-bill-block-b1 products-bill-block-b2",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "products-bill-block-b1-title-text",
                                                        children: t.bills.TITLE2
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_9__.Radio.Group, {
                                                        onChange: onChange,
                                                        value: values,
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "products-bill-block-b2-group",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_9__.Radio, {
                                                                        value: 1,
                                                                        className: "products-bill-block-b2-group-item",
                                                                        children: t.bills.DESCRIPTION2_1
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_9__.Radio, {
                                                                        value: 2,
                                                                        className: "products-bill-block-b2-group-item",
                                                                        children: t.bills.DESCRIPTION2_2
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_9__.Radio, {
                                                                        value: 3,
                                                                        className: "products-bill-block-b2-group-item",
                                                                        children: t.bills.DESCRIPTION2_3
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_9__.Radio, {
                                                                        value: 4,
                                                                        className: "products-bill-block-b2-group-item",
                                                                        children: [
                                                                            t.bills.DESCRIPTION2_4,
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: (_Order_module_css__WEBPACK_IMPORTED_MODULE_15___default().control),
                                                                                children: [
                                                                                    " ",
                                                                                    values === 4 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                        ref: timeInputRef,
                                                                                        style: {
                                                                                            marginLeft: 10
                                                                                        }
                                                                                    }) : null
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "products-bill-block-b1 products-bill-block-b3",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "products-bill-block-b1-title-text",
                                                        children: t.bills.TITLE3
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: (_Order_module_css__WEBPACK_IMPORTED_MODULE_15___default().control),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                            id: "description",
                                                            rows: 5,
                                                            placeholder: t.bills.DESCRIPTION3,
                                                            ref: descInputRef
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_cart_Cart__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                items: selectedItems,
                                                showCheckbox: false
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "products-cart-infor",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "products-cart-infor-header",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "products-cart-infor-title",
                                                        children: t.carts.TITLE
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "products-cart-infor-block",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "products-cart-infor-block-title",
                                                                children: [
                                                                    t.carts.LABEL1,
                                                                    " ",
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                        className: "products-cart-infor-block-title-s",
                                                                        children: [
                                                                            "(",
                                                                            totalOrderItems,
                                                                            " ",
                                                                            t.carts.LABEL2,
                                                                            ")"
                                                                        ]
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "products-cart-infor-block-number",
                                                                children: t.products.PRICE
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "products-cart-infor-blockt",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "products-cart-infor-blockt-title",
                                                                children: t.carts.LABEL3
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "products-cart-infor-blockt-number",
                                                                children: t.products.PRICE
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "products-cart-infor-sub",
                                                        children: t.carts.LABEL4
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                type: "submit",
                                                className: "products-cart-infor-btn",
                                                style: {
                                                    border: "none"
                                                },
                                                children: t.carts.NOTICAL3
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
};
async function getServerSideProps(context) {
    try {
        const lang = context.query.lang;
        if (lang === "en") {
            const MenuEN = await _service__WEBPACK_IMPORTED_MODULE_14__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("5");
            const FooterEN = await _service__WEBPACK_IMPORTED_MODULE_14__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("3");
            return {
                props: {
                    dataMenu: JSON.parse(MenuEN.value) || {},
                    dataFooter: JSON.parse(FooterEN.value) || {}
                }
            };
        } else {
            const MenuVI = await _service__WEBPACK_IMPORTED_MODULE_14__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("4");
            const FooterVI = await _service__WEBPACK_IMPORTED_MODULE_14__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("2");
            return {
                props: {
                    dataMenu: JSON.parse(MenuVI.value) || {},
                    dataFooter: JSON.parse(FooterVI.value) || {}
                }
            };
        }
    } catch (e) {
        return {
            props: {}
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OrdersCart);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7066:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 5725:
/***/ ((module) => {

"use strict";
module.exports = require("antd");

/***/ }),

/***/ 9843:
/***/ ((module) => {

"use strict";
module.exports = require("diacritic");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 3991:
/***/ ((module) => {

"use strict";
module.exports = import("ramda");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2636,5675,1664,2065,2287,2678,1556,633,1876], () => (__webpack_exec__(2869)));
module.exports = __webpack_exports__;

})();