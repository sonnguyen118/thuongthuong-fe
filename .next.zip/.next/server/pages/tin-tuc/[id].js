"use strict";
(() => {
var exports = {};
exports.id = 5394;
exports.ids = [5394];
exports.modules = {

/***/ 8269:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2678);
/* harmony import */ var _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1556);
/* harmony import */ var _components_elements_navigation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7641);
/* harmony import */ var _components_molecules_ckeditor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7811);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4516);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8612);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7631);
/* harmony import */ var _service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2065);
/* harmony import */ var _utils_Functions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9343);
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6158);
/* harmony import */ var react_share__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_share__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_2__, _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_3__, _components_molecules_ckeditor__WEBPACK_IMPORTED_MODULE_5__, _api__WEBPACK_IMPORTED_MODULE_11__, _service__WEBPACK_IMPORTED_MODULE_12__, _utils_Functions__WEBPACK_IMPORTED_MODULE_13__]);
([_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_2__, _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_3__, _components_molecules_ckeditor__WEBPACK_IMPORTED_MODULE_5__, _api__WEBPACK_IMPORTED_MODULE_11__, _service__WEBPACK_IMPORTED_MODULE_12__, _utils_Functions__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















class ArticleDetail {
    title = "";
    image = "";
    createdAt = "";
    content = "";
    description = "";
    breadCrumb = [];
}
const DetailNews = (props)=>{
    const { dataMenu , dataFooter , article  } = props;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    const currentUrl =  false ? 0 : "";
    const [leng, setLeng] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("VI");
    const [t, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_languages_vie_json__WEBPACK_IMPORTED_MODULE_8__);
    // const lang = useSelector(
    //   (state: ReturnType<typeof store.getState>) => state.language.currentLanguage
    // );
    const [articleDetail, setArticleDetail] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(new ArticleDetail());
    const pageSEOData = {
        name: "Thương Thương",
        pageSEO: {
            title: "Tin Tức Nổi Bật | Thương Thương",
            url: "https://www.critistudio.top/gioi-thieu",
            keywords: "website",
            description: "Thuong Thuong tổ chức đ\xe0o tạo nghề cho đối tượng người khuyết tật v\xe0 người yếu thế nhằm giảm g\xe1nh nặng cho gia đ\xecnh v\xe0 x\xe3 hội.",
            image: "https://www.critistudio.top/images/seo.jpg"
        }
    };
    let initDataNavigation = [
        {
            id: 1,
            title: `${t.navigator.HOME}`,
            link: "/"
        },
        {
            id: 2,
            title: `${t.navigator.MENU7}`,
            link: "/tin-tuc"
        }
    ];
    const [dataNavigation, setDataNavigation] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initDataNavigation);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const lang = localStorage.getItem("lang");
        setLeng(lang);
        if (lang) {
            (0,_languages__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)(lang, setText);
        } else {
            (0,_languages__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("vi", setText);
        }
        getArticleDetail();
    }, []);
    // useEffect(() => {
    //   loadLanguageText(lang, setText);
    //   getArticleDetail();
    // }, [id, lang, language]);
    const getArticleDetail = async ()=>{
        const data = props.article;
        const detail = {
            title: data?.name,
            image: data?.image,
            content: data?.content,
            description: data?.description,
            createdAt: data?.createdAt,
            breadCrumb: data?.breadCrumb
        };
        setArticleDetail(detail);
        setBreadCrumb(detail);
    };
    const setBreadCrumb = async (detail)=>{
        // if (detail?.breadCrumb) {
        //   const breadCrumb = detail?.breadCrumb.map(obj => {
        //     return { id: obj.id, link: `/tin-tuc${obj.link}`, title: obj.menu }
        //   })
        //   initDataNavigation = [...dataNavigation, ...breadCrumb]
        // }
        const artBreadCrumb = {
            id: 10,
            link: "",
            title: detail.title
        };
        initDataNavigation.push(artBreadCrumb);
        setDataNavigation(initDataNavigation);
    };
    const [isShare, setIsShare] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const handleOnShare = ()=>{
        setIsShare(!isShare);
        const icon = document.querySelector(".icon");
        if (icon instanceof HTMLElement) {
            icon.classList.toggle("dis");
            if (icon.classList.contains("dis")) {
                icon.style.animation = "fade-out 0.6s linear";
            } else {
                icon.style.animation = "fade-in 0.6s linear";
            }
        }
    };
    const url = `${"https://thuongthuonghandmade.vn"}/`;
    const image = "";
    // console.log(t, "đây là t");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                pageSEO: pageSEOData.pageSEO,
                url: url,
                image: image
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                dataMenu: dataMenu,
                dataFooter: dataFooter,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "news",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "news-navigation",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_navigation__WEBPACK_IMPORTED_MODULE_4__/* .NavigationTopBar */ .a, {
                                    data: dataNavigation
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "news-navigation-time",
                                    children: _utils_Functions__WEBPACK_IMPORTED_MODULE_13__/* .DateTime.formatDateTime */ .ou.formatDateTime(articleDetail.createdAt, leng)
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "news-wrap",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "news-wrap-title",
                                    children: articleDetail.title
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "news-wrap-information",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "news-wrap-information-text",
                                            children: [
                                                t.news.MENU,
                                                ":",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "news-wrap-information-text-hightline",
                                                    children: t.news.SUB1
                                                }),
                                                " ",
                                                "|",
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "news-wrap-information-text-hightline",
                                                    children: t.news.SUB2
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "news-wrap-information-share",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: isShare ? "icon news-wrap-information-share-icon" : "icon news-wrap-information-share-icon-dis dis",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_14__.FacebookShareButton, {
                                                            url: currentUrl,
                                                            className: "news-wrap-information-share-icon-item",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_14__.FacebookIcon, {
                                                                size: 32,
                                                                round: true
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_14__.LinkedinShareButton, {
                                                            url: currentUrl,
                                                            className: "news-wrap-information-share-icon-item",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_14__.LinkedinIcon, {
                                                                size: 32,
                                                                round: true
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_14__.TelegramShareButton, {
                                                            url: currentUrl,
                                                            className: "news-wrap-information-share-icon-item",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_14__.TelegramIcon, {
                                                                size: 32,
                                                                round: true
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_14__.TwitterShareButton, {
                                                            url: currentUrl,
                                                            className: "news-wrap-information-share-icon-item",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_14__.TwitterIcon, {
                                                                size: 32,
                                                                round: true
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_14__.ViberShareButton, {
                                                            url: currentUrl,
                                                            className: "news-wrap-information-share-icon-item",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_14__.ViberIcon, {
                                                                size: 32,
                                                                round: true
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_14__.WhatsappShareButton, {
                                                            url: currentUrl,
                                                            className: "news-wrap-information-share-icon-item",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_share__WEBPACK_IMPORTED_MODULE_14__.WhatsappIcon, {
                                                                size: 32,
                                                                round: true
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_7__.Button, {
                                                    type: "primary",
                                                    className: "news-wrap-information-btn",
                                                    onClick: handleOnShare,
                                                    children: [
                                                        isShare ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_6__.CloseOutlined, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_6__.PlusOutlined, {}),
                                                        " ",
                                                        t.button.BUTTON7
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "news-wrap-description",
                                    children: articleDetail.description
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_molecules_ckeditor__WEBPACK_IMPORTED_MODULE_5__/* .CkeditorDisable */ .n, {
                                    data: articleDetail.content
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
async function getServerSideProps(context) {
    try {
        const lang = context.query.lang;
        const { id  } = context.query;
        if (lang === "en") {
            const article = await _api__WEBPACK_IMPORTED_MODULE_11__/* .articleClient.getArticleDetail */ ._t.getArticleDetail("EN", id).then((res)=>res.data.data);
            const MenuEN = await _service__WEBPACK_IMPORTED_MODULE_12__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("5");
            const FooterEN = await _service__WEBPACK_IMPORTED_MODULE_12__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("3");
            return {
                props: {
                    dataMenu: JSON.parse(MenuEN.value) || {},
                    dataFooter: JSON.parse(FooterEN.value) || {},
                    article: article
                }
            };
        } else {
            const article = await _api__WEBPACK_IMPORTED_MODULE_11__/* .articleClient.getArticleDetail */ ._t.getArticleDetail("VI", id).then((res)=>res.data.data);
            const MenuVI = await _service__WEBPACK_IMPORTED_MODULE_12__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("4");
            const FooterVI = await _service__WEBPACK_IMPORTED_MODULE_12__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("2");
            return {
                props: {
                    dataMenu: JSON.parse(MenuVI.value) || {},
                    dataFooter: JSON.parse(FooterVI.value) || {},
                    article: article
                }
            };
        }
    } catch (e) {
        return {
            props: {}
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DetailNews);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7066:
/***/ ((module) => {

module.exports = require("@ant-design/icons");

/***/ }),

/***/ 384:
/***/ ((module) => {

module.exports = require("@ckeditor/ckeditor5-react");

/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 4082:
/***/ ((module) => {

module.exports = require("ckeditor5-custom-build/build/ckeditor");

/***/ }),

/***/ 9843:
/***/ ((module) => {

module.exports = require("diacritic");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5515:
/***/ ((module) => {

module.exports = require("react-cookie");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 6158:
/***/ ((module) => {

module.exports = require("react-share");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 3991:
/***/ ((module) => {

module.exports = import("ramda");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2636,5675,1664,2065,2287,2678,1556,7811], () => (__webpack_exec__(8269)));
module.exports = __webpack_exports__;

})();