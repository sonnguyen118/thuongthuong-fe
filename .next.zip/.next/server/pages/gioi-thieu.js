"use strict";
(() => {
var exports = {};
exports.id = 9148;
exports.ids = [9148];
exports.modules = {

/***/ 2855:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2678);
/* harmony import */ var _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1556);
/* harmony import */ var _components_templates_abouts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6387);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4516);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8612);
/* harmony import */ var _service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2065);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_2__, _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_3__, _service__WEBPACK_IMPORTED_MODULE_8__]);
([_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_2__, _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_3__, _service__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const AboutPage = (props)=>{
    const { dataPages , dataMenu , dataFooter , dataContact  } = props;
    console.log(dataPages, "dataPages");
    const [t, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_languages_vie_json__WEBPACK_IMPORTED_MODULE_6__);
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.language.currentLanguage);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (0,_languages__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(lang, setText);
    }, [
        lang
    ]);
    const pageSEOData = {
        name: "Thương Thương",
        pageSEO: {
            title: "Giới Thiệu | Thương Thương",
            url: "https://www.critistudio.top/gioi-thieu",
            keywords: "website",
            description: "Thuong Thuong tổ chức đ\xe0o tạo nghề cho đối tượng người khuyết tật v\xe0 người yếu thế nhằm giảm g\xe1nh nặng cho gia đ\xecnh v\xe0 x\xe3 hội.",
            image: "https://www.critistudio.top/images/seo.jpg"
        }
    };
    const dataAbout = [
        {
            id: "1",
            image: [
                "/images/slide/slide1.jpg"
            ],
            title: `${t.about_pages.TITLE1}`,
            description: `${t.about_pages.DESCRIPTION1}`,
            position: {
                image: 1,
                block: 2
            }
        },
        {
            id: "2",
            image: [
                "/images/slide/slide1.jpg",
                "/images/slide/slide2.jpg",
                "/images/slide/slide3.jpg"
            ],
            title: `${t.about_pages.TITLE2}`,
            description: `${t.about_pages.DESCRIPTION2}`,
            position: {
                image: 2,
                block: 1
            }
        }
    ];
    const url = `${"https://thuongthuonghandmade.vn"}/`;
    const image = "";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                pageSEO: pageSEOData.pageSEO,
                url: url,
                image: image
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                dataMenu: dataMenu,
                dataFooter: dataFooter,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_templates_abouts__WEBPACK_IMPORTED_MODULE_4__/* .BanerAbout */ .q, {
                        imageUrl: dataPages.imageBaner[0]
                    }),
                    dataPages.title1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_templates_abouts__WEBPACK_IMPORTED_MODULE_4__/* .BlockInformation */ .T, {
                            isShow: dataPages.show1,
                            image: dataPages.image1,
                            title: dataPages.title1,
                            description: dataPages.description1,
                            position: dataPages.isReversed1
                        })
                    }, 1),
                    dataPages.title2 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_templates_abouts__WEBPACK_IMPORTED_MODULE_4__/* .BlockInformation */ .T, {
                            isShow: dataPages.show2,
                            image: dataPages.image2,
                            title: dataPages.title2,
                            description: dataPages.description2,
                            position: dataPages.isReversed2
                        })
                    }, 3),
                    dataPages.title3 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_templates_abouts__WEBPACK_IMPORTED_MODULE_4__/* .BlockInformation */ .T, {
                            isShow: dataPages.show3,
                            image: dataPages.image3,
                            title: dataPages.title3,
                            description: dataPages.description3,
                            position: dataPages.isReversed3
                        })
                    }, 3),
                    dataPages.title4 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_templates_abouts__WEBPACK_IMPORTED_MODULE_4__/* .BlockInformation */ .T, {
                            isShow: dataPages.show4,
                            image: dataPages.image4,
                            title: dataPages.title4,
                            description: dataPages.description4,
                            position: dataPages.isReversed4
                        })
                    }, 4),
                    dataPages.title5 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_templates_abouts__WEBPACK_IMPORTED_MODULE_4__/* .BlockInformation */ .T, {
                            isShow: dataPages.show5,
                            image: dataPages.image5,
                            title: dataPages.title5,
                            description: dataPages.description5,
                            position: dataPages.isReversed5
                        })
                    }, 5)
                ]
            })
        ]
    });
};
async function getServerSideProps(context) {
    try {
        const lang = context.query.lang;
        if (lang === "en") {
            const DatapageEN = await _service__WEBPACK_IMPORTED_MODULE_8__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("9");
            const MenuEN = await _service__WEBPACK_IMPORTED_MODULE_8__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("5");
            const FooterEN = await _service__WEBPACK_IMPORTED_MODULE_8__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("3");
            const ContactEN = await _service__WEBPACK_IMPORTED_MODULE_8__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("13");
            return {
                props: {
                    dataPages: JSON.parse(DatapageEN.value) || {},
                    dataMenu: JSON.parse(MenuEN.value) || {},
                    dataFooter: JSON.parse(FooterEN.value) || {},
                    dataContact: JSON.parse(ContactEN.value) || {}
                }
            };
        } else {
            const DatapageVI = await _service__WEBPACK_IMPORTED_MODULE_8__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("8");
            const MenuVI = await _service__WEBPACK_IMPORTED_MODULE_8__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("4");
            const FooterVI = await _service__WEBPACK_IMPORTED_MODULE_8__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("2");
            const ContactVI = await _service__WEBPACK_IMPORTED_MODULE_8__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("12");
            return {
                props: {
                    dataPages: JSON.parse(DatapageVI.value) || {},
                    dataMenu: JSON.parse(MenuVI.value) || {},
                    dataFooter: JSON.parse(FooterVI.value) || {},
                    dataContact: JSON.parse(ContactVI.value) || {}
                }
            };
        }
    } catch (e) {
        return {
            props: {}
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AboutPage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6387:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "q": () => (/* reexport */ abouts_BanerAbout),
  "T": () => (/* reexport */ abouts_BlockInformation)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/elements/baner/BanerImage.tsx


const ImagesBaner = ({ urlImage  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
        src: urlImage,
        alt: "ThuongThuong",
        width: 80,
        height: 80,
        loading: "lazy",
        style: {
            objectFit: "cover",
            width: "100%",
            height: "100%"
        }
    });
};
/* harmony default export */ const BanerImage = (ImagesBaner);

;// CONCATENATED MODULE: ./src/components/elements/baner/index.ts


;// CONCATENATED MODULE: ./src/components/templates/abouts/BanerAbout.tsx


const BanerAbout = (props)=>{
    const { imageUrl  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "about__baner",
        children: /*#__PURE__*/ jsx_runtime_.jsx(BanerImage, {
            urlImage: "https://api.thuongthuonghandmade.vn" + "/" + imageUrl
        })
    });
};
/* harmony default export */ const abouts_BanerAbout = (BanerAbout);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
// EXTERNAL MODULE: external "@ant-design/icons"
var icons_ = __webpack_require__(7066);
;// CONCATENATED MODULE: ./src/components/templates/abouts/BlockInformation.tsx





const BlockInformation = ({ isShow , image , title , description , position  })=>{
    console.log(image);
    const settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000
    };
    const slider = (0,external_react_.useRef)(null);
    const next = ()=>{
        slider.current?.slickNext();
    };
    const previous = ()=>{
        slider.current?.slickPrev();
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: isShow && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "about__block",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "about__block-image",
                    style: {
                        order: position ? 2 : 1
                    },
                    children: [
                        image.length > 1 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "about__block-image-btn1",
                                    onClick: previous,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(icons_.RightCircleOutlined, {})
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "about__block-image-btn2",
                                    onClick: next,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(icons_.LeftCircleOutlined, {})
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
                            ref: slider,
                            ...settings,
                            children: image && image.map((data, i)=>/*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "https://api.thuongthuonghandmade.vn" + "/" + data,
                                    alt: "Thương Thương Giới thiệu",
                                    className: "about__block-image-item",
                                    width: 500,
                                    height: 500
                                }, i))
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "about__block-information",
                    style: {
                        order: position ? 1 : 2
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: "about__block-information-title",
                            children: title
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "about__block-information-description",
                            children: description.content1
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "about__block-information-description",
                            children: description.content2
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "about__block-information-description",
                            children: description.content3
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const abouts_BlockInformation = (BlockInformation);

;// CONCATENATED MODULE: ./src/components/templates/abouts/index.ts




/***/ }),

/***/ 7066:
/***/ ((module) => {

module.exports = require("@ant-design/icons");

/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 9843:
/***/ ((module) => {

module.exports = require("diacritic");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 3991:
/***/ ((module) => {

module.exports = import("ramda");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2636,5675,1664,2065,2678,1556], () => (__webpack_exec__(2855)));
module.exports = __webpack_exports__;

})();