"use strict";
(() => {
var exports = {};
exports.id = 5405;
exports.ids = [5405];
exports.modules = {

/***/ 2603:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2678);
/* harmony import */ var _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1556);
/* harmony import */ var _components_elements_Slider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6903);
/* harmony import */ var _components_templates_home__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6430);
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4516);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8612);
/* harmony import */ var _service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2065);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_2__, _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_3__, _components_elements_Slider__WEBPACK_IMPORTED_MODULE_4__, _components_templates_home__WEBPACK_IMPORTED_MODULE_5__, _service__WEBPACK_IMPORTED_MODULE_8__]);
([_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_2__, _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_3__, _components_elements_Slider__WEBPACK_IMPORTED_MODULE_4__, _components_templates_home__WEBPACK_IMPORTED_MODULE_5__, _service__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const Home = (props)=>{
    const { dataPages , dataMenu , dataFooter , dataContact , dataProductHighlight , dataListProducts  } = props;
    const [t, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_languages_vie_json__WEBPACK_IMPORTED_MODULE_6__);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const lang = localStorage.getItem("lang");
        if (lang) {
            (0,_languages__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(lang, setText);
        } else {
            (0,_languages__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)("vi", setText);
        }
    }, []);
    const url = `${"https://thuongthuonghandmade.vn"}/`;
    const image = "";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                pageSEO: dataPages.SEO,
                url: url,
                image: image
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                dataMenu: dataMenu,
                dataFooter: dataFooter,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_Slider__WEBPACK_IMPORTED_MODULE_4__/* .SlideBarsHome */ .JF, {
                        isShow: dataPages.showBlock1,
                        dataSlider: dataPages.dataSlider,
                        t: t
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_templates_home__WEBPACK_IMPORTED_MODULE_5__/* .PrinciplesHome */ .A, {
                        isShow: dataPages.showBlockS,
                        dataBlock: dataPages.dataBlockS
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_templates_home__WEBPACK_IMPORTED_MODULE_5__/* .PiecesPuzzleHome */ .So, {
                        isShow: dataPages.showBlock2,
                        uderlineBlock: dataPages.uderlineBlock2,
                        iconBlock: dataPages.iconBlock2,
                        titleBlock: dataPages.titleBlock2,
                        listSliderBlock: dataPages.listSliderBlock2,
                        contentBlock: dataPages.contentBlock2,
                        t: t
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_templates_home__WEBPACK_IMPORTED_MODULE_5__/* .ListProducts */ .uP, {
                        isShow: dataPages.showBlock3,
                        uderlineBlock: dataPages.uderlineBlock3,
                        iconBlock: dataPages.iconBlock3,
                        titleBlock: dataPages.titleBlock3,
                        listSliderBlock: dataPages.listSliderBlock3,
                        t: t
                    }),
                    dataProductHighlight && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_templates_home__WEBPACK_IMPORTED_MODULE_5__/* .BlockProducts */ .tg, {
                        dataProductHighlight: dataProductHighlight,
                        dataListProducts: dataListProducts,
                        t: t
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_templates_home__WEBPACK_IMPORTED_MODULE_5__/* .ListPartner */ .yF, {
                        isShow: dataPages.showBlock5,
                        uderlineBlock: dataPages.uderlineBlock5,
                        iconBlock: dataPages.iconBlock5,
                        titleBlock: dataPages.titleBlock5,
                        listSliderBlock: dataPages.listSliderBlock5,
                        t: t
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_templates_home__WEBPACK_IMPORTED_MODULE_5__/* .ContactHome */ .OE, {
                        data: dataContact,
                        t: t
                    })
                ]
            })
        ]
    });
};
async function getServerSideProps(context) {
    try {
        const lang = context.query.lang;
        if (lang === "en") {
            const DatapageEN = await _service__WEBPACK_IMPORTED_MODULE_8__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("7");
            const MenuEN = await _service__WEBPACK_IMPORTED_MODULE_8__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("5");
            const FooterEN = await _service__WEBPACK_IMPORTED_MODULE_8__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("3");
            const ContactEN = await _service__WEBPACK_IMPORTED_MODULE_8__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("13");
            const ListProduct = await _service__WEBPACK_IMPORTED_MODULE_8__/* .handleProductsClient.handleGetHighlight */ .oO.handleGetHighlight();
            try {
                const dataPages = JSON.parse(DatapageEN.value);
                if (dataPages.dataProduct && dataPages.dataProduct.length > 0) {
                    const promises = dataPages.dataProduct.map(async (item)=>{
                        if (item.value) {
                            const body = {
                                categoryId: item.value,
                                language: "VI",
                                page: 1,
                                size: 20,
                                productName: ""
                            };
                            const apiData = await _service__WEBPACK_IMPORTED_MODULE_8__/* .handleProductsClient.getProductsByCategoryID */ .oO.getProductsByCategoryID(body);
                            return apiData.data;
                        }
                    });
                    const resultArray = await Promise.all(promises);
                    return {
                        props: {
                            dataPages: JSON.parse(DatapageEN.value) || {},
                            dataMenu: JSON.parse(MenuEN.value) || {},
                            dataFooter: JSON.parse(FooterEN.value) || {},
                            dataContact: JSON.parse(ContactEN.value) || {},
                            dataProductHighlight: ListProduct.data?.products,
                            dataListProducts: resultArray
                        }
                    };
                }
            } catch (e) {
            // Xử lý lỗi
            }
            if (ListProduct.meta?.status === 200) {
                return {
                    props: {
                        dataPages: JSON.parse(DatapageEN.value) || {},
                        dataMenu: JSON.parse(MenuEN.value) || {},
                        dataFooter: JSON.parse(FooterEN.value) || {},
                        dataContact: JSON.parse(ContactEN.value) || {},
                        dataProductHighlight: ListProduct.data?.products,
                        dataListProducts: null
                    }
                };
            }
            return {
                props: {
                    dataPages: JSON.parse(DatapageEN.value) || {},
                    dataMenu: JSON.parse(MenuEN.value) || {},
                    dataFooter: JSON.parse(FooterEN.value) || {},
                    dataContact: JSON.parse(ContactEN.value) || {},
                    dataProductHighlight: null,
                    dataListProducts: null
                }
            };
        } else {
            const DatapageVI = await _service__WEBPACK_IMPORTED_MODULE_8__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("6");
            const MenuVI = await _service__WEBPACK_IMPORTED_MODULE_8__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("4");
            const FooterVI = await _service__WEBPACK_IMPORTED_MODULE_8__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("2");
            const ContactVI = await _service__WEBPACK_IMPORTED_MODULE_8__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("12");
            const ListProduct = await _service__WEBPACK_IMPORTED_MODULE_8__/* .handleProductsClient.handleGetHighlight */ .oO.handleGetHighlight();
            try {
                const dataPages = JSON.parse(DatapageVI.value);
                if (dataPages.dataProduct && dataPages.dataProduct.length > 0) {
                    const promises = dataPages.dataProduct.map(async (item)=>{
                        if (item.value) {
                            const body = {
                                categoryId: item.value,
                                language: "VI",
                                page: 1,
                                size: 20,
                                productName: ""
                            };
                            console.log(body, "body");
                            const apiData = await _service__WEBPACK_IMPORTED_MODULE_8__/* .handleProductsClient.getProductsByCategoryID */ .oO.getProductsByCategoryID(body);
                            return apiData.data;
                        }
                    });
                    const resultArray = await Promise.all(promises);
                    return {
                        props: {
                            dataPages: JSON.parse(DatapageVI.value) || {},
                            dataMenu: JSON.parse(MenuVI.value) || {},
                            dataFooter: JSON.parse(FooterVI.value) || {},
                            dataContact: JSON.parse(ContactVI.value) || {},
                            dataProductHighlight: ListProduct.data?.products,
                            dataListProducts: resultArray
                        }
                    };
                }
            } catch (e) {
                // Xử lý lỗi
                console.log("lol");
            }
            if (ListProduct.meta?.status === 200) {
                return {
                    props: {
                        dataPages: JSON.parse(DatapageVI.value) || {},
                        dataMenu: JSON.parse(MenuVI.value) || {},
                        dataFooter: JSON.parse(FooterVI.value) || {},
                        dataContact: JSON.parse(ContactVI.value) || {},
                        dataProductHighlight: ListProduct.data?.products,
                        dataListProducts: null
                    }
                };
            }
            return {
                props: {
                    dataPages: JSON.parse(DatapageVI.value) || {},
                    dataMenu: JSON.parse(MenuVI.value) || {},
                    dataFooter: JSON.parse(FooterVI.value) || {},
                    dataContact: JSON.parse(ContactVI.value) || {},
                    dataProductHighlight: null,
                    dataListProducts: null
                }
            };
        }
    } catch (e) {
        return {
            props: {}
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4853:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_elements_card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3249);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_elements_card__WEBPACK_IMPORTED_MODULE_2__]);
_components_elements_card__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const CustomList = ({ items  })=>{
    return /*#__PURE__*/ _jsx(List, {
        className: "home__event-list",
        itemLayout: "vertical",
        dataSource: items,
        renderItem: (item)=>/*#__PURE__*/ _jsx(List.Item, {
                children: /*#__PURE__*/ _jsx(CardNewsList, {
                    title: item.title,
                    description: item.description,
                    imageSrc: item.imageSrc
                })
            })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (CustomList)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2789:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var _ListNewsHome__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4853);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ListNewsHome__WEBPACK_IMPORTED_MODULE_0__]);
_ListNewsHome__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9749:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_elements_Slider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6903);
/* harmony import */ var _components_elements_block__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(461);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_elements_Slider__WEBPACK_IMPORTED_MODULE_1__]);
_components_elements_Slider__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const BlockProducts = (props)=>{
    const { dataProductHighlight , dataListProducts , t  } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "home__products",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_block__WEBPACK_IMPORTED_MODULE_2__/* .TitleProduct */ .L, {
                title: t.home.HEADER3,
                link: "/san-pham",
                t: t
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_Slider__WEBPACK_IMPORTED_MODULE_1__/* .SlideProductsHome */ .yu, {
                data: dataProductHighlight,
                t: t
            }),
            dataListProducts && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: dataListProducts.map((data, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_block__WEBPACK_IMPORTED_MODULE_2__/* .TitleProduct */ .L, {
                                title: data.category.name,
                                link: "/san-pham/" + data.category.link,
                                t: t
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_Slider__WEBPACK_IMPORTED_MODULE_1__/* .SlideProductsHome */ .yu, {
                                data: data.products,
                                t: t
                            })
                        ]
                    }, index))
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BlockProducts);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1364:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_elements_block__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(461);



const { TabPane  } = antd__WEBPACK_IMPORTED_MODULE_1__.Tabs;
const CardTabs = ()=>{
    const listData = [
        {
            id: "3423saxczxc",
            header: "Thương thương 1",
            title: "Bộ Thương binh và LĐXH - tab1",
            content: "“Kymviet chơi” l\xe0 chương tr\xecnh gi\xe1o dục trải nghiệm độc đ\xe1o d\xe0nh ri\xeang cho đối tượng học sinh. Chương tr\xecnh được x\xe2y dựng bởi doanh nghiệp x\xe3 hội Kymviet v\xe0 những chuy\xean gia gi\xe1o dục uy t\xedn. “Kymviet chơi” nằm trong khu\xf4n khổ của “Kymviet Edu”, một nh\xe1nh thuộc hệ sinh th\xe1i Kymviet. Với chương tr\xecnh c\xf4ng phu, \xfd nghĩa v\xe0 hấp dẫn như “Kymviet chơi”, Kymviet kh\xe1t khao chung tay ph\xe1t triển gi\xe1o dục, c\xf9ng x\xe3 hội vun đắp những thế hệ Việt ưu t\xfa, gi\xe0u cảm x\xfac, gi\xe0u kĩ năng, gi\xe0u trải nghiệm."
        },
        {
            id: "3423saxczxc2",
            header: "Thương thương 2",
            title: "Bộ Thương binh và LĐXH - tab 2",
            content: "“Kymviet chơi” l\xe0 chương tr\xecnh gi\xe1o dục trải nghiệm độc đ\xe1o d\xe0nh ri\xeang cho đối tượng học sinh. Chương tr\xecnh được x\xe2y dựng bởi doanh nghiệp x\xe3 hội Kymviet v\xe0 những chuy\xean gia gi\xe1o dục uy t\xedn. “Kymviet chơi” nằm trong khu\xf4n khổ của “Kymviet Edu”, một nh\xe1nh thuộc hệ sinh th\xe1i Kymviet. Với chương tr\xecnh c\xf4ng phu, \xfd nghĩa v\xe0 hấp dẫn như “Kymviet chơi”, Kymviet kh\xe1t khao chung tay ph\xe1t triển gi\xe1o dục, c\xf9ng x\xe3 hội vun đắp những thế hệ Việt ưu t\xfa, gi\xe0u cảm x\xfac, gi\xe0u kĩ năng, gi\xe0u trải nghiệm."
        },
        {
            id: "3423saxczxcg",
            header: "Thương thương 3",
            title: "Bộ Thương binh và LĐXH - tab3",
            content: "“Kymviet chơi” l\xe0 chương tr\xecnh gi\xe1o dục trải nghiệm độc đ\xe1o d\xe0nh ri\xeang cho đối tượng học sinh. Chương tr\xecnh được x\xe2y dựng bởi doanh nghiệp x\xe3 hội Kymviet v\xe0 những chuy\xean gia gi\xe1o dục uy t\xedn. “Kymviet chơi” nằm trong khu\xf4n khổ của “Kymviet Edu”, một nh\xe1nh thuộc hệ sinh th\xe1i Kymviet. Với chương tr\xecnh c\xf4ng phu, \xfd nghĩa v\xe0 hấp dẫn như “Kymviet chơi”, Kymviet kh\xe1t khao chung tay ph\xe1t triển gi\xe1o dục, c\xf9ng x\xe3 hội vun đắp những thế hệ Việt ưu t\xfa, gi\xe0u cảm x\xfac, gi\xe0u kĩ năng, gi\xe0u trải nghiệm."
        },
        {
            id: "3423saxczxcs",
            header: "Thương thương 4",
            title: "Bộ Thương binh và LĐXH - tab4",
            content: "“Kymviet chơi” l\xe0 chương tr\xecnh gi\xe1o dục trải nghiệm độc đ\xe1o d\xe0nh ri\xeang cho đối tượng học sinh. Chương tr\xecnh được x\xe2y dựng bởi doanh nghiệp x\xe3 hội Kymviet v\xe0 những chuy\xean gia gi\xe1o dục uy t\xedn. “Kymviet chơi” nằm trong khu\xf4n khổ của “Kymviet Edu”, một nh\xe1nh thuộc hệ sinh th\xe1i Kymviet. Với chương tr\xecnh c\xf4ng phu, \xfd nghĩa v\xe0 hấp dẫn như “Kymviet chơi”, Kymviet kh\xe1t khao chung tay ph\xe1t triển gi\xe1o dục, c\xf9ng x\xe3 hội vun đắp những thế hệ Việt ưu t\xfa, gi\xe0u cảm x\xfac, gi\xe0u kĩ năng, gi\xe0u trải nghiệm."
        }
    ];
    return /*#__PURE__*/ _jsxs("div", {
        className: "home__cardtabs",
        children: [
            /*#__PURE__*/ _jsx(TitleBlock, {
                title: "Hệ sinh th\xe1i ThuongThuong",
                urlImage: "/images/home/iconnho06.png",
                underlined: false
            }),
            /*#__PURE__*/ _jsx(Tabs, {
                defaultActiveKey: "1",
                type: "card",
                tabBarStyle: {
                    background: "none",
                    borderBottom: "none"
                },
                className: "home__cardtabs-wrap",
                children: listData ? /*#__PURE__*/ _jsx(_Fragment, {
                    children: listData.map((data, i)=>/*#__PURE__*/ _jsx(TabPane, {
                            tab: data.header,
                            children: /*#__PURE__*/ _jsx(Card, {
                                title: data.title,
                                bordered: false,
                                children: data.content
                            })
                        }, data.id))
                }) : /*#__PURE__*/ _jsx(_Fragment, {})
            })
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (CardTabs)));


/***/ }),

/***/ 7244:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_elements_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(277);
/* harmony import */ var _components_elements_block__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(461);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_elements_form__WEBPACK_IMPORTED_MODULE_3__]);
_components_elements_form__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Contact = (props)=>{
    const { data , t  } = props;
    const onFinish = (values)=>{
        console.log("Received values of form: ", values);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "home__contact",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_block__WEBPACK_IMPORTED_MODULE_4__/* .TitleBlock */ .E, {
                title: data.titleBlock,
                urlImage: data.iconBlock ? data.iconBlock[0] : "",
                underlined: data.underlineBlock
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "home__contact-map",
                dangerouslySetInnerHTML: {
                    __html: data.map
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_2__.Row, {
                className: "home__contact-wrap",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "home__contact-wrap-left",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "home__contact-wrap-left-title",
                                children: [
                                    data.phone,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    data.hotline,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    data.email,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    data.adress1,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    data.adress2
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "home__contact-wrap-left-text",
                                children: [
                                    data.content?.content1,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    data.content?.content2,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    data.content?.content3
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "home__contact-wrap-right",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_form__WEBPACK_IMPORTED_MODULE_3__/* .FormContactHome */ .U, {
                            t: t
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Contact);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 488:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_elements_card__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3249);
/* harmony import */ var _components_elements_list__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2789);
/* harmony import */ var _components_elements_block__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(461);
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4516);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8612);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_elements_card__WEBPACK_IMPORTED_MODULE_3__, _components_elements_list__WEBPACK_IMPORTED_MODULE_4__]);
([_components_elements_card__WEBPACK_IMPORTED_MODULE_3__, _components_elements_list__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const EventNews = ({ cardTitle , cardDescription , cardImageSrc , listItems  })=>{
    const [t, setText] = useState(viText);
    useEffect(()=>{
        const lang = localStorage.getItem("lang");
        console.log(lang, "lang");
        if (lang) {
            loadLanguageText(lang, setText);
        } else {
            loadLanguageText("vi", setText);
        }
    }, []);
    return /*#__PURE__*/ _jsxs("div", {
        className: "home__event",
        children: [
            /*#__PURE__*/ _jsx(TitleBlock, {
                title: t.home.HEADER4,
                urlImage: "/images/home/iconnho06.png",
                underlined: false
            }),
            /*#__PURE__*/ _jsxs(Row, {
                className: "home__event-wrap",
                children: [
                    /*#__PURE__*/ _jsx(Col, {
                        span: 12,
                        children: /*#__PURE__*/ _jsx(CardNewsHome, {
                            title: cardTitle,
                            description: cardDescription,
                            imageSrc: cardImageSrc
                        })
                    }),
                    /*#__PURE__*/ _jsx(Col, {
                        span: 12,
                        children: /*#__PURE__*/ _jsx(ListNewsHome, {
                            items: listItems
                        })
                    })
                ]
            })
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (EventNews)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2006:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_elements_Slider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6903);
/* harmony import */ var _components_elements_block__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(461);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_elements_Slider__WEBPACK_IMPORTED_MODULE_2__]);
_components_elements_Slider__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const ListPartner = (props)=>{
    const { isShow , uderlineBlock , iconBlock , titleBlock , listSliderBlock , t  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: isShow && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "home__partner",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_block__WEBPACK_IMPORTED_MODULE_3__/* .TitleBlock */ .E, {
                    title: titleBlock,
                    urlImage: iconBlock[0],
                    underlined: uderlineBlock
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_Slider__WEBPACK_IMPORTED_MODULE_2__/* .SlidePartner */ .oh, {
                    listSliderBlock: listSliderBlock
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ListPartner);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3059:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_elements_Slider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6903);
/* harmony import */ var _components_elements_block__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(461);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_elements_Slider__WEBPACK_IMPORTED_MODULE_2__]);
_components_elements_Slider__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const ListProducts = (props)=>{
    const { isShow , uderlineBlock , iconBlock , titleBlock , listSliderBlock , t  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: isShow && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "home__listproducts",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_block__WEBPACK_IMPORTED_MODULE_3__/* .TitleBlock */ .E, {
                    title: titleBlock,
                    urlImage: iconBlock[0],
                    underlined: uderlineBlock
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_Slider__WEBPACK_IMPORTED_MODULE_2__/* .SlideBarsImageProductsHome */ .Ac, {
                    listSlider: listSliderBlock
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ListProducts);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8700:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_elements_block__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(461);





const { Title , Text  } = antd__WEBPACK_IMPORTED_MODULE_2__.Typography;
const PiecesPuzzle = (props)=>{
    const { isShow , uderlineBlock , iconBlock , titleBlock , listSliderBlock , contentBlock , t  } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "home__principles",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_block__WEBPACK_IMPORTED_MODULE_4__/* .TitleBlock */ .E, {
                title: null,
                urlImage: iconBlock[0],
                underlined: uderlineBlock
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_2__.Row, {
                className: "home__principles-puzzle",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Col, {
                        className: "home__principles-puzzle-image",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            src: "https://api.thuongthuonghandmade.vn" + "/" + listSliderBlock[0],
                            alt: "My Image",
                            layout: "fill",
                            objectFit: "cover",
                            className: "home__principles-puzzle-image-src"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_2__.Col, {
                        className: "home__principles-puzzle-infor",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Title, {
                                        level: 2,
                                        className: "home__principles-puzzle-infor-title",
                                        children: titleBlock
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Text, {
                                        className: "home__principles-puzzle-infor-text",
                                        children: [
                                            contentBlock.content1,
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            contentBlock.content2,
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            contentBlock.content3
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                type: "primary",
                                className: "home__principles-puzzle-infor-btn",
                                children: t.button.BUTTON1
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PiecesPuzzle);


/***/ }),

/***/ 3861:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Principles = (props)=>{
    const { isShow , dataBlock  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: isShow && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "home__principles",
            children: dataBlock.map((data, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: index !== 1 ? "home__principles-block" : "home__principles-block-active",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: index !== 1 ? "home__principles-block-title" : "home__principles-block-active-title",
                            children: data.title
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: index !== 1 ? "home__principles-block-description" : "home__principles-block-active-description",
                            children: data.content
                        })
                    ]
                }, index))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Principles);


/***/ }),

/***/ 6430:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* reexport safe */ _Principles__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "OE": () => (/* reexport safe */ _Contact__WEBPACK_IMPORTED_MODULE_7__.Z),
/* harmony export */   "So": () => (/* reexport safe */ _PiecesPuzzle__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "tg": () => (/* reexport safe */ _BlockProducts__WEBPACK_IMPORTED_MODULE_4__.Z),
/* harmony export */   "uP": () => (/* reexport safe */ _ListProducts__WEBPACK_IMPORTED_MODULE_3__.Z),
/* harmony export */   "yF": () => (/* reexport safe */ _ListPartner__WEBPACK_IMPORTED_MODULE_6__.Z)
/* harmony export */ });
/* harmony import */ var _Principles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3861);
/* harmony import */ var _PiecesPuzzle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8700);
/* harmony import */ var _CardTabs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1364);
/* harmony import */ var _ListProducts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3059);
/* harmony import */ var _BlockProducts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9749);
/* harmony import */ var _EventNews__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(488);
/* harmony import */ var _ListPartner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2006);
/* harmony import */ var _Contact__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7244);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ListProducts__WEBPACK_IMPORTED_MODULE_3__, _BlockProducts__WEBPACK_IMPORTED_MODULE_4__, _EventNews__WEBPACK_IMPORTED_MODULE_5__, _ListPartner__WEBPACK_IMPORTED_MODULE_6__, _Contact__WEBPACK_IMPORTED_MODULE_7__]);
([_ListProducts__WEBPACK_IMPORTED_MODULE_3__, _BlockProducts__WEBPACK_IMPORTED_MODULE_4__, _EventNews__WEBPACK_IMPORTED_MODULE_5__, _ListPartner__WEBPACK_IMPORTED_MODULE_6__, _Contact__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7066:
/***/ ((module) => {

module.exports = require("@ant-design/icons");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 9843:
/***/ ((module) => {

module.exports = require("diacritic");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 3991:
/***/ ((module) => {

module.exports = import("ramda");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2636,5675,1664,2065,2678,1556,633,3249,9722,8580], () => (__webpack_exec__(2603)));
module.exports = __webpack_exports__;

})();