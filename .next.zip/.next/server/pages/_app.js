(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 4178:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_sass_main_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3498);
/* harmony import */ var _styles_sass_main_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_sass_main_scss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1598);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var antd_dist_reset_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9107);
/* harmony import */ var antd_dist_reset_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd_dist_reset_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(938);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_8__]);
react_toastify__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const App = ({ Component , pageProps  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_redux__WEBPACK_IMPORTED_MODULE_5__.Provider, {
        store: _store__WEBPACK_IMPORTED_MODULE_6__/* .store */ .h,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                ...pageProps
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_8__.ToastContainer, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (App);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 938:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "h": () => (/* binding */ store)
});

// UNUSED EXPORTS: persistor

// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(5184);
;// CONCATENATED MODULE: external "redux-persist"
const external_redux_persist_namespaceObject = require("redux-persist");
;// CONCATENATED MODULE: external "redux-persist/lib/storage"
const storage_namespaceObject = require("redux-persist/lib/storage");
var storage_default = /*#__PURE__*/__webpack_require__.n(storage_namespaceObject);
// EXTERNAL MODULE: ./store/slices/loadingState.ts
var loadingState = __webpack_require__(4214);
;// CONCATENATED MODULE: ./store/slices/languageSlice.ts

const initialState = {
    currentLanguage: "VI",
    titleLanguage: "Tiếng Việt"
};
const languageSlice = (0,toolkit_.createSlice)({
    name: "language",
    initialState,
    reducers: {
        setLanguage: (state, action)=>{
            state.currentLanguage = action.payload.current;
            state.titleLanguage = action.payload.title;
        }
    }
});
const { setLanguage  } = languageSlice.actions;
/* harmony default export */ const slices_languageSlice = (languageSlice);

// EXTERNAL MODULE: ./store/slices/cartSlice.ts
var cartSlice = __webpack_require__(633);
;// CONCATENATED MODULE: ./store/slices/adressSlice.ts

const adressSlice_initialState = {
    adress: []
};
const adressSlice = (0,toolkit_.createSlice)({
    name: "adress",
    initialState: adressSlice_initialState,
    reducers: {
        addAdress: (state, action)=>{
            const index = state.adress.findIndex((item)=>item.id === action.payload.id);
            if (index >= 0) {} else {
                state.adress.push(action.payload);
            }
        },
        removeAdress: (state, action)=>{
            state.adress = state.adress.filter((item)=>item.id !== action.payload);
        },
        updateAdress: (state, action)=>{
            const index = state.adress.findIndex((item)=>item.id === action.payload.id);
            if (index >= 0) {
                state.adress[index].name = action.payload.name;
                state.adress[index].phone = action.payload.phone;
                state.adress[index].email = action.payload.email;
                state.adress[index].conscious = action.payload.conscious;
                state.adress[index].district = action.payload.district;
                state.adress[index].commune = action.payload.commune;
            }
        }
    }
});
const { addAdress , removeAdress , updateAdress  } = adressSlice.actions;
/* harmony default export */ const slices_adressSlice = (adressSlice);

;// CONCATENATED MODULE: ./store/slices/uiSlice.ts

const uiSlice_initialState = {
    isCartVisible: false,
    notification: {
        status: "ok",
        title: "",
        message: ""
    }
};
const uiSlice = (0,toolkit_.createSlice)({
    name: "ui",
    initialState: uiSlice_initialState,
    reducers: {
        toggle (state) {
            state.isCartVisible = !state.isCartVisible;
        },
        showNotification (state, action) {
            state.notification = {
                status: action.payload.status,
                title: action.payload.title,
                message: action.payload.message
            };
        }
    }
});
const uiActions = uiSlice.actions;
/* harmony default export */ const slices_uiSlice = (uiSlice);

;// CONCATENATED MODULE: ./store/persistedReducer.ts

 // defaults to localStorage for web and AsyncStorage for react-native






const rootReducer = (0,toolkit_.combineReducers)({
    language: slices_languageSlice.reducer,
    cart: cartSlice/* default.reducer */.ZP.reducer,
    adress: slices_adressSlice.reducer,
    loading: loadingState/* default */.ZP,
    ui: slices_uiSlice.reducer
});
const persistConfig = {
    key: "root",
    storage: (storage_default()),
    whitelist: [
        "language",
        "cart",
        "adress"
    ]
};
const persistedReducer = (0,external_redux_persist_namespaceObject.persistReducer)(persistConfig, rootReducer);
/* harmony default export */ const store_persistedReducer = (persistedReducer);

;// CONCATENATED MODULE: ./store/index.ts



const store = (0,toolkit_.configureStore)({
    reducer: store_persistedReducer
});
const persistor = (0,external_redux_persist_namespaceObject.persistStore)(store);


/***/ }),

/***/ 4214:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K4": () => (/* binding */ setLoading),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export loadingSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    loading: false
};
const loadingSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "loading",
    initialState,
    reducers: {
        setLoading: (state, action)=>{
            state.loading = action.payload;
        }
    }
});
const { setLoading  } = loadingSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (loadingSlice.reducer);


/***/ }),

/***/ 9107:
/***/ (() => {



/***/ }),

/***/ 8819:
/***/ (() => {



/***/ }),

/***/ 1598:
/***/ (() => {



/***/ }),

/***/ 8278:
/***/ (() => {



/***/ }),

/***/ 3498:
/***/ (() => {



/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [633], () => (__webpack_exec__(4178)));
module.exports = __webpack_exports__;

})();