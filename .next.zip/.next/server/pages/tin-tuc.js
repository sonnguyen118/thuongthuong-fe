"use strict";
(() => {
var exports = {};
exports.id = 3081;
exports.ids = [3081];
exports.modules = {

/***/ 562:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2678);
/* harmony import */ var _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1556);
/* harmony import */ var _components_elements_card__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3249);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_elements_navigation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7641);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4516);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8612);
/* harmony import */ var src_constant_link_master__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9144);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7631);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2065);
/* harmony import */ var _utils_Functions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9343);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_2__, _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_3__, _components_elements_card__WEBPACK_IMPORTED_MODULE_4__, _api__WEBPACK_IMPORTED_MODULE_10__, _service__WEBPACK_IMPORTED_MODULE_12__, _utils_Functions__WEBPACK_IMPORTED_MODULE_13__]);
([_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_2__, _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_3__, _components_elements_card__WEBPACK_IMPORTED_MODULE_4__, _api__WEBPACK_IMPORTED_MODULE_10__, _service__WEBPACK_IMPORTED_MODULE_12__, _utils_Functions__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const { Search  } = antd__WEBPACK_IMPORTED_MODULE_5__.Input;
const ListNews = (props)=>{
    const { dataMenu , dataFooter , articles , pagination  } = props;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    const { id , language  } = router.query;
    const [t, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_languages_vie_json__WEBPACK_IMPORTED_MODULE_8__);
    const [leng, setLeng] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("VI");
    const [page, setPage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const [pageSize, setPageSize] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(10);
    const [total, setTotal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [articleSearchName, setArticleSearchName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.language.currentLanguage);
    const pageSEOData = {
        name: "Thương Thương",
        pageSEO: {
            title: "Tin Tức | Thương Thương",
            url: "https://www.critistudio.top/gioi-thieu",
            keywords: "website",
            description: "Thuong Thuong tổ chức đ\xe0o tạo nghề cho đối tượng người khuyết tật v\xe0 người yếu thế nhằm giảm g\xe1nh nặng cho gia đ\xecnh v\xe0 x\xe3 hội.",
            image: "https://www.critistudio.top/images/seo.jpg"
        }
    };
    const dataNavigation = [
        {
            id: 1,
            title: `${t.navigator.HOME}`,
            link: "/"
        },
        {
            id: 2,
            title: `${t.navigator.MENU1}`,
            link: "/"
        }
    ];
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const lang = localStorage.getItem("lang");
        setLeng(lang);
        if (lang) {
            (0,_languages__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)(lang, setText);
        } else {
            (0,_languages__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)("vi", setText);
        }
        getAllArticles(props);
    }, []);
    // useEffect(() => {
    //   loadLanguageText(lang, setText);
    //   getAllArticles(props);
    // }, [lang, language]);
    const getAllArticles = async (props)=>{
        const articles = props.articles;
        const paging = props.pagination;
        setPageSize(paging.page);
        setPageSize(paging.size);
        setTotal(paging.totalRecords);
        const listNewsData = articles?.map((article)=>({
                id: article.id,
                title: article.name,
                image: article.imageUrl ? `${"https://api.thuongthuonghandmade.vn"}/${article.imageUrl}` : "",
                descriptions: article.descriptions ? article.descriptions : "",
                time: article.createdAt ? article.createdAt : "",
                link: `${src_constant_link_master__WEBPACK_IMPORTED_MODULE_14__/* .TIN_TUC */ .T0}${article.link}`
            }));
    // setArticles(listNewsData)
    // setPagination(paging)
    };
    const pagingList = async (lang, page, pageSize, searchName)=>{
        const data = await _api__WEBPACK_IMPORTED_MODULE_10__/* .articleClient.getArticleClient */ ._t.getArticleClient(lang, page, pageSize, searchName).then((res)=>res.data.data);
        await getAllArticles(data);
    };
    const onChangePagination = async (_page, _pageSize)=>{
        if (_pageSize != pageSize) {
            _page = 1;
            await pagingList(lang, _page, _pageSize, articleSearchName);
        }
        if (_page != page) {
            await pagingList(lang, _page, _pageSize, articleSearchName);
        }
        setPage(_page);
        setPageSize(_pageSize);
    };
    const searchArticles = async (value)=>{
        setArticleSearchName(value);
        pagingList(lang, 1, pagination.size, value);
    };
    const url = `${"https://thuongthuonghandmade.vn"}/`;
    const image = "";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                pageSEO: pageSEOData.pageSEO,
                url: url,
                image: image
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                dataMenu: dataMenu,
                dataFooter: dataFooter,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "list-products",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "list-products-navigation",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_navigation__WEBPACK_IMPORTED_MODULE_6__/* .NavigationTopBar */ .a, {
                                data: dataNavigation
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "list-news",
                        children: articles.map((data, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "list-news-item",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_card__WEBPACK_IMPORTED_MODULE_4__/* .CardPageNews */ .KQ, {
                                    title: data.name,
                                    description: data.description,
                                    imageSrc: "https://api.thuongthuonghandmade.vn" + "/" + data.imageUrl,
                                    link: data.link,
                                    time: _utils_Functions__WEBPACK_IMPORTED_MODULE_13__/* .DateTime.formatDateTime */ .ou.formatDateTime(data.createdAt, leng)
                                })
                            }, data.id))
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_5__.Pagination, {
                        total: total,
                        current: page,
                        pageSize: pageSize,
                        // pageSizeOptions={PAGE_SIZE}
                        showPrevNextJumpers: true,
                        // showSizeChanger
                        onChange: onChangePagination,
                        onShowSizeChange: onChangePagination,
                        className: "list-news-pagination"
                    })
                ]
            })
        ]
    });
};
async function getServerSideProps(context) {
    try {
        const page = 1;
        const size = 20;
        const lang = context.query.lang;
        if (lang === "en") {
            const data = await _api__WEBPACK_IMPORTED_MODULE_10__/* .articleClient.getArticleClient */ ._t.getArticleClient("EN", page, size).then((res)=>res.data.data);
            const articles = data.articles;
            let pagination = data.pagination;
            const MenuEN = await _service__WEBPACK_IMPORTED_MODULE_12__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("5");
            const FooterEN = await _service__WEBPACK_IMPORTED_MODULE_12__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("3");
            return {
                props: {
                    dataMenu: JSON.parse(MenuEN.value) || {},
                    dataFooter: JSON.parse(FooterEN.value) || {},
                    articles: articles,
                    pagination: pagination
                }
            };
        } else {
            const data = await _api__WEBPACK_IMPORTED_MODULE_10__/* .articleClient.getArticleClient */ ._t.getArticleClient("VI", page, size).then((res)=>res.data.data);
            const articles = data.articles;
            let pagination = data.pagination;
            const MenuVI = await _service__WEBPACK_IMPORTED_MODULE_12__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("4");
            const FooterVI = await _service__WEBPACK_IMPORTED_MODULE_12__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("2");
            return {
                props: {
                    dataMenu: JSON.parse(MenuVI.value) || {},
                    dataFooter: JSON.parse(FooterVI.value) || {},
                    articles: articles,
                    pagination: pagination
                }
            };
        }
    } catch (e) {
        return {
            props: {}
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ListNews);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7066:
/***/ ((module) => {

module.exports = require("@ant-design/icons");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 9843:
/***/ ((module) => {

module.exports = require("diacritic");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 3991:
/***/ ((module) => {

module.exports = import("ramda");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2636,5675,1664,2065,2287,2678,1556,633,3249], () => (__webpack_exec__(562)));
module.exports = __webpack_exports__;

})();