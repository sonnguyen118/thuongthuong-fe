"use strict";
(() => {
var exports = {};
exports.id = 6303;
exports.ids = [6303];
exports.modules = {

/***/ 8023:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4516);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8612);
/* harmony import */ var _components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2678);
/* harmony import */ var _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1556);
/* harmony import */ var _components_elements_navigation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7641);
/* harmony import */ var _service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2065);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var store_actions_cart_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8724);
/* harmony import */ var _components_elements_cart_Cart__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1684);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_4__, _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_5__, _service__WEBPACK_IMPORTED_MODULE_7__]);
([_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_4__, _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_5__, _service__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








// sử dụng redux



const OrdersCart = (props)=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useDispatch)();
    const { dataMenu , dataFooter  } = props;
    const cartItems = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state.cart.items);
    const [t, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_languages_vie_json__WEBPACK_IMPORTED_MODULE_2__);
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state.language.currentLanguage);
    const cart = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state.cart);
    let isInitial = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        dispatch((0,store_actions_cart_actions__WEBPACK_IMPORTED_MODULE_9__/* .fetchCartData */ .m)());
    }, [
        dispatch
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isInitial.current) {
            isInitial.current = false;
            return;
        }
        if (cart.changed) {
            (0,store_actions_cart_actions__WEBPACK_IMPORTED_MODULE_9__/* .saveCartData */ .Q)(cart);
        }
    }, [
        cart,
        dispatch
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (0,_languages__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(lang, setText);
    }, [
        lang
    ]);
    const dataNavigation = [
        {
            id: 1,
            title: `${t.navigator.HOME}`,
            link: "/"
        },
        {
            id: 2,
            title: `${t.navigator.MENU6}`,
            link: "/"
        }
    ];
    const pageSEOData = {
        name: "Thương Thương",
        pageSEO: {
            title: "Tranh cuốn giấy | Thương Thương",
            url: "https://www.critistudio.top/gioi-thieu",
            keywords: "website",
            description: "Thuong Thuong tổ chức đ\xe0o tạo nghề cho đối tượng người khuyết tật v\xe0 người yếu thế nhằm giảm g\xe1nh nặng cho gia đ\xecnh v\xe0 x\xe3 hội.",
            image: "https://www.critistudio.top/images/seo.jpg"
        }
    };
    const url = `${"https://thuongthuonghandmade.vn"}/`;
    const image = "";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                pageSEO: pageSEOData.pageSEO,
                url: url,
                image: image
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                dataMenu: dataMenu,
                dataFooter: dataFooter,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "list-products",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "list-products-navigation",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_navigation__WEBPACK_IMPORTED_MODULE_6__/* .NavigationTopBar */ .a, {
                                data: dataNavigation
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "products-cart-title",
                            children: "GIỎ H\xc0NG"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_cart_Cart__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            items: cartItems,
                            showCheckbox: true
                        })
                    ]
                })
            })
        ]
    });
};
async function getServerSideProps(context) {
    try {
        const lang = context.query.lang;
        if (lang === "en") {
            const MenuEN = await _service__WEBPACK_IMPORTED_MODULE_7__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("5");
            const FooterEN = await _service__WEBPACK_IMPORTED_MODULE_7__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("3");
            return {
                props: {
                    dataMenu: JSON.parse(MenuEN.value) || {},
                    dataFooter: JSON.parse(FooterEN.value) || {}
                }
            };
        } else {
            const MenuVI = await _service__WEBPACK_IMPORTED_MODULE_7__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("4");
            const FooterVI = await _service__WEBPACK_IMPORTED_MODULE_7__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("2");
            return {
                props: {
                    dataMenu: JSON.parse(MenuVI.value) || {},
                    dataFooter: JSON.parse(FooterVI.value) || {}
                }
            };
        }
    } catch (e) {
        return {
            props: {}
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OrdersCart);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7066:
/***/ ((module) => {

module.exports = require("@ant-design/icons");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 9843:
/***/ ((module) => {

module.exports = require("diacritic");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 3991:
/***/ ((module) => {

module.exports = import("ramda");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2636,5675,1664,2065,2287,2678,1556,633,1876], () => (__webpack_exec__(8023)));
module.exports = __webpack_exports__;

})();