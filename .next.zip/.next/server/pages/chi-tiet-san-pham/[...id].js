"use strict";
(() => {
var exports = {};
exports.id = 2241;
exports.ids = [2241];
exports.modules = {

/***/ 5144:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4516);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8612);
/* harmony import */ var _components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2678);
/* harmony import */ var _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1556);
/* harmony import */ var _components_elements_navigation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7641);
/* harmony import */ var _components_templates_products__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1399);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var src_constant_link_master__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9144);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7631);
/* harmony import */ var _service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2065);
/* harmony import */ var src_constant_constant__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6223);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_4__, _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_5__, _components_templates_products__WEBPACK_IMPORTED_MODULE_7__, _api__WEBPACK_IMPORTED_MODULE_9__, _service__WEBPACK_IMPORTED_MODULE_10__]);
([_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_4__, _components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_5__, _components_templates_products__WEBPACK_IMPORTED_MODULE_7__, _api__WEBPACK_IMPORTED_MODULE_9__, _service__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const ListNews = (props)=>{
    const { product , dataMenu , dataFooter , dataProductHighlight  } = props;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const { id , language  } = router.query;
    const [t, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_languages_vie_json__WEBPACK_IMPORTED_MODULE_2__);
    const [listProductSame, setListProductSame] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_12__.useSelector)((state)=>state.language.currentLanguage);
    const initDataNavigation = [
        {
            id: 1,
            title: `${t.navigator.HOME}`,
            link: "/"
        },
        {
            id: 2,
            title: `${t.menu.MENU4}`,
            link: `${src_constant_link_master__WEBPACK_IMPORTED_MODULE_13__/* .SAN_PHAM */ .fx}?language=${lang}`
        }
    ];
    const [dataNavigation, setDataNavigation] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initDataNavigation);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (0,_languages__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(lang, setText);
        setBreadCrumb();
    }, [
        lang,
        language,
        id
    ]);
    // Lấy ra danh sách 20 sản phẩm cùng loại ( cùng danh mục cấp 2)
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (product && product.danhMuc1) {
            const fetchData = async ()=>{
                const body = {
                    categoryId: product.danhMuc1.id,
                    language: "VI",
                    page: 1,
                    size: 20
                };
                try {
                    const response = await _service__WEBPACK_IMPORTED_MODULE_10__/* .handleProductsClient.getProductsByCategoryID */ .oO.getProductsByCategoryID(body);
                    const { meta , data  } = response;
                    if (meta.status === 200) {
                        setListProductSame(data.products);
                    } else {
                        console.log("lỗi server");
                    }
                } catch (err) {
                    console.log(err);
                }
            };
            fetchData();
        }
    }, [
        product
    ]);
    const setBreadCrumb = async ()=>{
        const languageFromURL = language?.toString().toUpperCase();
        if (languageFromURL == "VI") {
            initDataNavigation[0].title = src_constant_constant__WEBPACK_IMPORTED_MODULE_11__/* .bread_crumb.home.VI */ .rb.home.VI;
            initDataNavigation[1].title = src_constant_constant__WEBPACK_IMPORTED_MODULE_11__/* .bread_crumb.product.VI */ .rb.product.VI;
        }
        if (languageFromURL == "EN") {
            initDataNavigation[0].title = src_constant_constant__WEBPACK_IMPORTED_MODULE_11__/* .bread_crumb.home.EN */ .rb.home.EN;
            initDataNavigation[1].title = src_constant_constant__WEBPACK_IMPORTED_MODULE_11__/* .bread_crumb.product.EN */ .rb.product.EN;
        }
        const detailProduct = props.product;
        const danhMuc1 = {
            id: 3,
            title: `${detailProduct.danhMuc1.name}`,
            link: `${src_constant_link_master__WEBPACK_IMPORTED_MODULE_13__/* .SAN_PHAM */ .fx}${detailProduct.danhMuc1.link}?language=${lang}`
        };
        initDataNavigation.push(danhMuc1);
        if (detailProduct.danhMuc2) {
            const danhMuc2 = {
                id: 4,
                title: `${detailProduct.danhMuc2.name}`,
                link: `${src_constant_link_master__WEBPACK_IMPORTED_MODULE_13__/* .SAN_PHAM */ .fx}${detailProduct.danhMuc2.link}?language=${lang}`
            };
            initDataNavigation.push(danhMuc2);
        }
        const product = {
            id: 5,
            title: `${detailProduct.name}`,
            link: `${detailProduct.link}?language=${lang}`
        };
        initDataNavigation.push(product);
        console.log(initDataNavigation);
        setDataNavigation(initDataNavigation);
    };
    const pageSEOData = {
        name: "Thương Thương",
        pageSEO: {
            title: "Tranh cuốn giấy | Thương Thương",
            url: "https://www.critistudio.top/gioi-thieu",
            keywords: "website",
            description: "Thuong Thuong tổ chức đ\xe0o tạo nghề cho đối tượng người khuyết tật v\xe0 người yếu thế nhằm giảm g\xe1nh nặng cho gia đ\xecnh v\xe0 x\xe3 hội.",
            image: "https://www.critistudio.top/images/seo.jpg"
        }
    };
    const url = `${"https://thuongthuonghandmade.vn"}/`;
    const image = "";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_header_HeadSEO__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                pageSEO: pageSEOData.pageSEO,
                url: url,
                image: image
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_layout_LayoutClient__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                dataMenu: dataMenu,
                dataFooter: dataFooter,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "list-products",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "list-products-navigation",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_navigation__WEBPACK_IMPORTED_MODULE_6__/* .NavigationTopBar */ .a, {
                                data: dataNavigation
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "list-products-wrap",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_templates_products__WEBPACK_IMPORTED_MODULE_7__/* .ProductsDetails */ .Aj, {
                                data: product
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_templates_products__WEBPACK_IMPORTED_MODULE_7__/* .ProductsSeems */ .Gi, {
                            title: t.products.HEADER1,
                            data: listProductSame
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_templates_products__WEBPACK_IMPORTED_MODULE_7__/* .ProductsContent */ .Py, {
                            data: product.content
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_templates_products__WEBPACK_IMPORTED_MODULE_7__/* .ProductsSeems */ .Gi, {
                            title: t.products.HEADER3,
                            data: dataProductHighlight
                        })
                    ]
                })
            })
        ]
    });
};
async function getServerSideProps({ params , query  }) {
    try {
        const lang = query.lang;
        const { id  } = params;
        if (lang === "en") {
            const product = await _api__WEBPACK_IMPORTED_MODULE_9__/* .productClient.getDetailProduct */ .Mn.getDetailProduct(id, "EN").then((res)=>res.data.data);
            const MenuVI = await _service__WEBPACK_IMPORTED_MODULE_10__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("5");
            const FooterVI = await _service__WEBPACK_IMPORTED_MODULE_10__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("3");
            const ProductHighlight = await _service__WEBPACK_IMPORTED_MODULE_10__/* .handleProductsClient.handleGetHighlight */ .oO.handleGetHighlight();
            // Pass data to the page via props
            return {
                props: {
                    product: product,
                    dataMenu: JSON.parse(MenuVI.value) || {},
                    dataFooter: JSON.parse(FooterVI.value) || {},
                    dataProductHighlight: ProductHighlight.data?.products
                }
            };
        } else {
            const product = await _api__WEBPACK_IMPORTED_MODULE_9__/* .productClient.getDetailProduct */ .Mn.getDetailProduct(id, "VI").then((res)=>res.data.data);
            const MenuVI = await _service__WEBPACK_IMPORTED_MODULE_10__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("4");
            const FooterVI = await _service__WEBPACK_IMPORTED_MODULE_10__/* .webInformationClient.handleGetWebInformation */ .xP.handleGetWebInformation("2");
            const ProductHighlight = await _service__WEBPACK_IMPORTED_MODULE_10__/* .handleProductsClient.handleGetHighlight */ .oO.handleGetHighlight();
            // Pass data to the page via props
            return {
                props: {
                    product: product,
                    dataMenu: JSON.parse(MenuVI.value) || {},
                    dataFooter: JSON.parse(FooterVI.value) || {},
                    dataProductHighlight: ProductHighlight.data?.products
                }
            };
        }
    } catch (error) {
        return {
            props: {}
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ListNews);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3233:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4516);
/* harmony import */ var _components_molecules_ckeditor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7811);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_molecules_ckeditor__WEBPACK_IMPORTED_MODULE_4__]);
_components_molecules_ckeditor__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const ProductsContent = (props)=>{
    const { data  } = props;
    const [t, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_languages_vie_json__WEBPACK_IMPORTED_MODULE_3__);
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.language.currentLanguage);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "products-seems",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "products-seems-title",
                children: t.products.HEADER2
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_molecules_ckeditor__WEBPACK_IMPORTED_MODULE_4__/* .CkeditorDisable */ .n, {
                data: data
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductsContent);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2502:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4516);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8612);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _slices_cartSlice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(633);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);









const ProductsDetails = (props)=>{
    const [t, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_languages_vie_json__WEBPACK_IMPORTED_MODULE_2__);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useDispatch)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const [productDetail, setProductDetail] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.language.currentLanguage);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (0,_languages__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(lang, setText);
        if (props?.data) {
            setProductDetail(props?.data);
        }
    }, [
        lang,
        props
    ]);
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const [expanded, setExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const toggleExpanded = ()=>{
        setExpanded(!expanded);
    };
    const handleOnChange = (newValue)=>{
        if (newValue === null) {
            setValue(1);
        } else {
            setValue(newValue);
        }
    };
    // mua ngay
    const handlePayNow = ()=>{
        if (productDetail) {
            const item = {
                id: productDetail.id,
                imageUrl: productDetail.imageUrl,
                title: productDetail.title,
                price: 0,
                quantity: 1,
                selected: true
            };
            dispatch(_slices_cartSlice__WEBPACK_IMPORTED_MODULE_6__/* .cartActions.addItemToCart */ .Uw.addItemToCart(item));
            router.push("/gio-hang");
        }
    };
    const handleAddCart = ()=>{
        if (productDetail) {
            const item = {
                id: productDetail.id,
                imageUrl: productDetail.imageUrl,
                title: productDetail.title,
                price: 0,
                quantity: 1,
                selected: false
            };
            dispatch(_slices_cartSlice__WEBPACK_IMPORTED_MODULE_6__/* .cartActions.addItemToCart */ .Uw.addItemToCart(item));
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "products",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "products-image",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Image, {
                    src: `${"https://api.thuongthuonghandmade.vn"}/${productDetail?.imageUrl}`,
                    alt: productDetail?.title,
                    style: {
                        objectFit: "cover",
                        width: "100%",
                        height: "100%"
                    }
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "products-detail",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "products-detail-title",
                        children: productDetail?.title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "products-detail-price",
                        children: t.products.PRICE
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "products-detail-selector",
                        style: {
                            display: "flex",
                            alignItems: "center"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "products-detail-selector-text",
                                children: t.products.QUANTITY
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                onClick: ()=>handleOnChange(value - 1),
                                children: "-"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.InputNumber, {
                                defaultValue: 1,
                                min: 1,
                                max: 10,
                                value: value,
                                onChange: handleOnChange,
                                style: {
                                    margin: "0 0.2em"
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                onClick: ()=>handleOnChange(value + 1),
                                children: "+"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "products-detail-group",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "products-detail-group-btn",
                                onClick: handlePayNow,
                                children: t.button.BUTTON4
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "products-detail-group-btn",
                                onClick: handleAddCart,
                                children: t.button.BUTTON5
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "products-detail-description",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "products-detail-description-title",
                                children: t.products.DES_TITLE
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "products-detail-description-body",
                                children: expanded ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "products-detail-description-body-hide",
                                            children: productDetail?.description
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "products-detail-description-body-btn",
                                            onClick: toggleExpanded,
                                            children: t.button.BUTTON1
                                        })
                                    ]
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "products-detail-description-body-show",
                                            children: productDetail?.description
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "products-detail-description-body-btn",
                                            onClick: toggleExpanded,
                                            children: t.button.BUTTON2
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductsDetails);


/***/ }),

/***/ 5402:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_elements_Slider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6903);
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4516);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8612);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_elements_Slider__WEBPACK_IMPORTED_MODULE_2__]);
_components_elements_Slider__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const ProductsSeems = (props)=>{
    const { title , data  } = props;
    const [t, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_languages_vie_json__WEBPACK_IMPORTED_MODULE_3__);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const lang = localStorage.getItem("lang");
        if (lang) {
            (0,_languages__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(lang, setText);
        } else {
            (0,_languages__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)("vi", setText);
        }
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "products-seems",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "products-seems-title",
                children: title.toUpperCase()
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_Slider__WEBPACK_IMPORTED_MODULE_2__/* .SlideProductsHome */ .yu, {
                data: data,
                t: t
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductsSeems);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1399:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Aj": () => (/* reexport safe */ _ProductsDetails__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "Gi": () => (/* reexport safe */ _ProductsSeems__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "Py": () => (/* reexport safe */ _ProductsContent__WEBPACK_IMPORTED_MODULE_2__.Z)
/* harmony export */ });
/* harmony import */ var _ProductsDetails__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2502);
/* harmony import */ var _ProductsSeems__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5402);
/* harmony import */ var _ProductsContent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3233);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ProductsSeems__WEBPACK_IMPORTED_MODULE_1__, _ProductsContent__WEBPACK_IMPORTED_MODULE_2__]);
([_ProductsSeems__WEBPACK_IMPORTED_MODULE_1__, _ProductsContent__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6223:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IV": () => (/* binding */ PAGE_SIZE),
/* harmony export */   "rb": () => (/* binding */ bread_crumb)
/* harmony export */ });
/* unused harmony exports home, product, CONTACT_STATUS */
const PAGE_SIZE = [
    "1",
    "2",
    "10",
    "20",
    "50"
];
const bread_crumb = {
    home: {
        VI: "Trang chủ",
        EN: "Home"
    },
    product: {
        VI: "Sản phẩm",
        EN: "Products"
    }
};
const home = {
    VI: "VI",
    EN: "EN"
};
const product = {
    VI: "Sản phẩm",
    EN: "Products"
};
const CONTACT_STATUS = {
    CHUA_XU_LY: "Chưa xử l\xfd",
    DA_XU_LY: "Đ\xe3 xử l\xfd"
};


/***/ }),

/***/ 7066:
/***/ ((module) => {

module.exports = require("@ant-design/icons");

/***/ }),

/***/ 384:
/***/ ((module) => {

module.exports = require("@ckeditor/ckeditor5-react");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 4082:
/***/ ((module) => {

module.exports = require("ckeditor5-custom-build/build/ckeditor");

/***/ }),

/***/ 9843:
/***/ ((module) => {

module.exports = require("diacritic");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5515:
/***/ ((module) => {

module.exports = require("react-cookie");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 3991:
/***/ ((module) => {

module.exports = import("ramda");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2636,5675,1664,2065,2287,2678,1556,633,7811,3249,9722], () => (__webpack_exec__(5144)));
module.exports = __webpack_exports__;

})();