"use strict";
exports.id = 633;
exports.ids = [633];
exports.modules = {

/***/ 633:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Uw": () => (/* binding */ cartActions),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export cartSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    items: [],
    totalQuantity: 0,
    changed: false,
    allSelected: false
};
const cartSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "cart",
    initialState,
    reducers: {
        toggleSelected (state) {
            state.allSelected = !state.allSelected;
        },
        replaceCart (state, action) {
            // console.log(state, "state");
            state.items = action.payload.items;
            state.items.forEach((item)=>{
                if (item.selected) {
                    item.selected = false;
                }
            });
            state.totalQuantity = action.payload.totalQuantity;
            state.allSelected = action.payload.allSelected;
            console.log(action, "action");
        },
        checkItem (state, action) {
            const selectedId = action.payload;
            const selectedItem = state.items.find((item)=>item.id === selectedId);
            if (selectedItem) {
                selectedItem.selected = !selectedItem.selected;
                const checkedType = selectedItem.selected;
                if (state.allSelected && !checkedType) {
                    state.allSelected = false;
                } else if (!state.allSelected && checkedType) {
                    if (state.items.every((item)=>item.selected)) {
                        state.allSelected = true;
                    }
                }
            }
        },
        checkAllItems (state) {
            const isAllSelected = state.allSelected;
            state.items.forEach((item)=>{
                item.selected = isAllSelected ? false : true;
            });
            state.allSelected = !isAllSelected;
        },
        addItemToCart (state, action) {
            const newItem = action.payload;
            const existingItem = state.items.find((item)=>item.id === newItem.id);
            state.totalQuantity++;
            state.changed = true;
            if (!existingItem) {
                state.items.push({
                    id: newItem.id,
                    price: newItem.price,
                    quantity: 1,
                    title: newItem.title,
                    imageUrl: newItem.imageUrl,
                    selected: newItem.selected
                });
                state.allSelected = false;
            } else {
                existingItem.selected = existingItem.selected ? true : newItem.selected;
                existingItem.quantity++;
            }
        },
        decreaseItemQuantity (state, action) {
            const id = action.payload;
            const existingItem = state.items.find((item)=>item.id === id);
            if (!existingItem) {
                return;
            }
            if (existingItem.quantity === 1) {
                state.items = state.items.filter((item)=>item.id !== id);
            } else {
                existingItem.quantity--;
            }
            state.totalQuantity--;
            state.changed = true;
        },
        removeItemFromCart (state, action) {
            const ids = action.payload;
            ids.forEach((id)=>{
                const existingItem = state.items.find((item)=>item.id === id);
                if (!existingItem) {
                    return;
                }
                state.items = state.items.filter((item)=>item.id !== id);
                state.totalQuantity -= existingItem.quantity;
            });
            state.changed = true;
        }
    }
});
const cartActions = cartSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cartSlice);


/***/ })

};
;