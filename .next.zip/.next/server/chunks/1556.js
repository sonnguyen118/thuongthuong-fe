exports.id = 1556;
exports.ids = [1556];
exports.modules = {

/***/ 7192:
/***/ ((module) => {

// Exports
module.exports = {
	"bump": "Nav_bump__c70bs"
};


/***/ }),

/***/ 7735:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "t": () => (/* reexport */ buttonLanguage)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: external "@ant-design/icons"
var icons_ = __webpack_require__(7066);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./src/components/elements/button/buttonLanguage.tsx






const ButtonLanguage = ()=>{
    const router = (0,router_.useRouter)();
    const [items, setItems] = (0,external_react_.useState)([]);
    const [titleLang, setTitleLang] = (0,external_react_.useState)("");
    const [urlImage, setUrlImage] = (0,external_react_.useState)("");
    // kiểm tra xem url có lang hay không
    const langURL = router.query["lang"];
    (0,external_react_.useEffect)(()=>{
        const lang = localStorage.getItem("lang");
        if (lang === "en") {
            const currentUrl = window.location.href;
            const urlWithInAppParam = currentUrl.includes("?") ? `${currentUrl}&lang=en` : `${currentUrl}?lang=en`;
            if (!currentUrl.includes("lang=en")) {
                // Thực hiện chuyển hướng đến URL mới
                router.replace(urlWithInAppParam);
            }
        }
    }, [
        langURL
    ]);
    const handleLanguageChange = (newLang, newTitleLang)=>{
        const currentUrl = router.asPath;
        const currentLang = router.query["lang"];
        localStorage.setItem("lang", newLang);
        let newUrl = currentUrl;
        console.log(currentLang, "currentLang");
        if (currentLang && currentLang === "en") {
            console.log("v\xe3i lồng");
            newUrl = currentUrl.replace(`?lang=${currentLang}`, ``);
        // newUrl = currentUrl.replace(`lang=${currentLang}`, `lang=${newLang}`);
        } else {
            newUrl = `${newUrl}?lang=${newLang}`;
        }
        // router.push(newUrl)
        window.location.href = newUrl;
    };
    (0,external_react_.useEffect)(()=>{
        if (langURL === "en") {
            localStorage.setItem("lang", "en");
            setTitleLang("English");
            setUrlImage(`/icon/lang/en.png`);
        } else {
            localStorage.setItem("lang", "vi");
            setTitleLang("Tiếng Việt");
            setUrlImage(`/icon/lang/vi.png`);
        }
    }, [
        langURL
    ]);
    (0,external_react_.useEffect)(()=>{
        if (langURL === "en") {
            setItems([
                {
                    key: "vi",
                    label: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Button, {
                        onClick: (e)=>handleLanguageChange("vi", "Tiếng Việt"),
                        icon: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/icon/lang/vi.png",
                            alt: "Thương Thương",
                            width: 30,
                            height: 19,
                            loading: "lazy",
                            className: "button-lang-img"
                        }),
                        type: "text",
                        className: "button-lang-btn",
                        style: {
                            backgroundColor: "transparent"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "Tiếng Việt"
                        })
                    })
                }
            ]);
        } else {
            setItems([
                {
                    key: "en",
                    label: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Button, {
                        onClick: (e)=>handleLanguageChange("en", "English"),
                        icon: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/icon/lang/en.png",
                            alt: "Thương Thương",
                            width: 30,
                            height: 19,
                            loading: "lazy",
                            className: "button-lang-img"
                        }),
                        type: "text",
                        className: "button-lang-btn",
                        style: {
                            backgroundColor: "transparent"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "English"
                        })
                    })
                }
            ]);
        }
    }, [
        langURL
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Space, {
        direction: "vertical",
        className: "button-lang",
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Space, {
            wrap: true,
            children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Dropdown, {
                menu: {
                    items
                },
                placement: "topLeft",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Button, {
                    icon: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: urlImage,
                        alt: "Thương Thương",
                        width: 30,
                        height: 19,
                        loading: "lazy",
                        className: "button-lang-img"
                    }),
                    type: "text",
                    className: "button-lang-btn",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "button-lang-btn-text",
                            children: titleLang
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(icons_.CaretRightOutlined, {
                            className: "button-lang-btn-icon"
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const buttonLanguage = (ButtonLanguage);

;// CONCATENATED MODULE: ./src/components/elements/button/index.ts



/***/ }),

/***/ 3154:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4516);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8612);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);








const Footer = (props)=>{
    const { data  } = props;
    console.log(data.subMenu1);
    const [menu1, setMenu1] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [menu2, setMenu2] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [t, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_languages_vie_json__WEBPACK_IMPORTED_MODULE_5__);
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.language.currentLanguage);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (0,_languages__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(lang, setText);
    }, [
        lang
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (data) {
            setMenu1(data.subMenu1);
            setMenu2(data.subMenu2);
        }
    }, [
        data
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
        className: "footer",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "footer__wrap",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_2__.Row, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Col, {
                            lg: 8,
                            sm: 24,
                            xs: 24,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "footer__wrap-item",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "footer__wrap-item-title",
                                        children: data.title1
                                    }),
                                    menu1.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                target: "_blank ",
                                                href: item.link,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                    children: item.title
                                                })
                                            })
                                        }, item.key))
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Col, {
                            lg: 8,
                            sm: 24,
                            xs: 24,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "footer__wrap-item",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "footer__wrap-item-title",
                                        children: data.title2
                                    }),
                                    menu2.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                target: "_blank ",
                                                href: item.link,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                    children: item.title
                                                })
                                            })
                                        }, item.key))
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Col, {
                            lg: 8,
                            sm: 24,
                            xs: 24,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "footer__wrap-item",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "footer__wrap-item-title",
                                        children: t.footer.TITLE4
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "footer__wrap-item-infor",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__.EnvironmentOutlined, {
                                                style: {
                                                    marginRight: 8
                                                },
                                                className: "footer__wrap-item-infor-icon"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "footer__wrap-item-infor-text",
                                                children: data.adress
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "footer__wrap-item-infor",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__.PhoneOutlined, {
                                                style: {
                                                    marginRight: 8
                                                },
                                                className: "footer__wrap-item-infor-icon"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "footer__wrap-item-infor-text",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: `tel: ${data.hotLine}`,
                                                    style: {
                                                        color: "#fff"
                                                    },
                                                    children: data.hotLine
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "footer__wrap-item-infor",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__.MailOutlined, {
                                                style: {
                                                    marginRight: 8
                                                },
                                                className: "footer__wrap-item-infor-icon"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "footer__wrap-item-infor-text",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: `mailto: ${data.email}`,
                                                    style: {
                                                        color: "#fff"
                                                    },
                                                    children: data.email
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Row, {
                className: "footer__bottom",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    style: {
                        textAlign: "center",
                        width: "100%"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            style: {
                                marginRight: 12
                            },
                            children: "\xa92023"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            style: {
                                marginRight: 12
                            },
                            children: t.footer.LISTMENU5_3
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 1556:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _navbar_navbarPC__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1864);
/* harmony import */ var _navbar_navbarMobile__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3316);
/* harmony import */ var _footer_FooterPC__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3154);
/* harmony import */ var _components_elements_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7735);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_navbar_navbarPC__WEBPACK_IMPORTED_MODULE_1__, _navbar_navbarMobile__WEBPACK_IMPORTED_MODULE_2__]);
([_navbar_navbarPC__WEBPACK_IMPORTED_MODULE_1__, _navbar_navbarMobile__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const Layout = (props)=>{
    const { dataMenu , dataFooter , children  } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_navbar_navbarPC__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                data: dataMenu
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_navbar_navbarMobile__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                data: dataMenu
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: children
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_button__WEBPACK_IMPORTED_MODULE_4__/* .ButtonLanguage */ .t, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_footer_FooterPC__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                data: dataFooter
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "icon-zalo",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: "https://zalo.me/g/qzhgkf395",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                        src: "/icon/zalo-icon-circle-1.png",
                        alt: "thuongthuong",
                        width: 55,
                        height: 55,
                        className: "icon-zalo-img"
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_5__.BackTop, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_5__.Button, {
                    type: "primary",
                    shape: "circle",
                    size: "large",
                    className: "custom-scroll-top",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_6__.UpOutlined, {})
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3316:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4516);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8612);
/* harmony import */ var _Nav_module_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7192);
/* harmony import */ var _Nav_module_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_Nav_module_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2065);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_service__WEBPACK_IMPORTED_MODULE_10__]);
_service__WEBPACK_IMPORTED_MODULE_10__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







// sử dụng redux






const NavbarMobile = (props)=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const currentUrl = router.asPath;
    const { data  } = props;
    const [isBtnHighlighted, setIsBtnHighlighted] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [t, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_languages_vie_json__WEBPACK_IMPORTED_MODULE_7__);
    const [category, setCategory] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        _service__WEBPACK_IMPORTED_MODULE_10__/* .handleCategoryClient.handleGetAllCategory */ .J0.handleGetAllCategory("VI").then((result)=>{
            setCategory(result);
        }).catch((error)=>{});
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (category && category.length > 0) {
            const newArray = category.map((item)=>({
                    key: item.id,
                    label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                        target: "_blank",
                        rel: "noopener noreferrer",
                        href: item.link,
                        className: "navbar__pc-item-dropdown-item",
                        children: item.name
                    })
                }));
            setItems(newArray);
        }
    }, [
        category
    ]);
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.language.currentLanguage);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (0,_languages__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(lang, setText);
    }, [
        lang
    ]);
    const cartItems = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.cart.items);
    const totalQuantity = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.cart.totalQuantity);
    const [searchVisible, setSearchVisible] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [searchText, setSearchText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [btnClasses, setBtnCalss] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [numberOfCartItems, setNumberOfCartItems] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    // const numberOfCartItems = cartItems.reduce((currNumber, item) => {
    //   return currNumber + item.quantity;
    // }, 0);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (cartItems) {
            setBtnCalss(`"cart" ${isBtnHighlighted ? (_Nav_module_css__WEBPACK_IMPORTED_MODULE_11___default().bump) : ""}`);
            const number = cartItems.reduce((currNumber, item)=>{
                return currNumber + item.quantity;
            }, 0);
            setNumberOfCartItems(number);
        }
    }, [
        cartItems
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (totalQuantity) {
            setIsBtnHighlighted(true);
            const timer = setTimeout(()=>{
                setIsBtnHighlighted(false);
            }, 300);
            return ()=>{
                clearTimeout(timer);
            };
        }
    }, [
        totalQuantity
    ]);
    const handleSearch = (e)=>{
        setSearchText(e.target.value);
    };
    const toggleSearchVisible = ()=>{
        setSearchVisible(!searchVisible);
    };
    const handleInputClick = (e)=>{
        e.stopPropagation();
    };
    const menu = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Menu, {
        className: "navbar__mobile-body-icon-dropdown",
        style: {
            width: "100%"
        },
        children: data.map((item, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Menu.Item, {
                    className: "navbar__mobile-body-icon-dropdown-item",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                        href: item.link,
                        children: item.title
                    })
                }, item.key)
            }))
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "navbar__mobile",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "navbar__mobile-header",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "navbar__mobile-header-icon",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__.SearchOutlined, {
                                    className: "navbar__mobile-header-icon-item"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Badge, {
                                    count: numberOfCartItems,
                                    overflowCount: 99,
                                    style: {
                                        backgroundColor: "red"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        href: "/gio-hang",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__.ShoppingCartOutlined, {
                                                className: "navbar__mobile-header-icon-item"
                                            }),
                                            style: {
                                                border: "none",
                                                textDecoration: "underline",
                                                boxShadow: "none"
                                            }
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "navbar__mobile-header-title",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "navbar__mobile-header-title-item",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    href: "/san-pham/danh-muc",
                                    children: [
                                        "Danh Mục Sản Phẩm",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__.CaretRightOutlined, {
                                            className: "navbar__mobile-header-title-item-icon"
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "navbar__mobile-body",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "navbar__mobile-body-logo",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                href: "/",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    src: "/icon/logo.png",
                                    alt: "ThuongThuong",
                                    width: 55,
                                    height: 45,
                                    loading: "lazy",
                                    className: "navbar__mobile-body-logo-img"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Dropdown, {
                            overlay: menu,
                            trigger: [
                                "click"
                            ],
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__.UnorderedListOutlined, {
                                className: "navbar__mobile-body-icon"
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavbarMobile);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1864:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4516);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8612);
/* harmony import */ var _Nav_module_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7192);
/* harmony import */ var _Nav_module_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_Nav_module_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2065);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_service__WEBPACK_IMPORTED_MODULE_10__]);
_service__WEBPACK_IMPORTED_MODULE_10__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



// Import thư viện Ant Design



// sử dụng redux






const NavbarPC = (props)=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const currentUrl = router.asPath;
    const { data  } = props;
    const [isBtnHighlighted, setIsBtnHighlighted] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [t, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_languages_vie_json__WEBPACK_IMPORTED_MODULE_7__);
    const [category, setCategory] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const lang = localStorage.getItem("lang");
        if (lang) {
            (0,_languages__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(lang, setText);
        } else {
            (0,_languages__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)("vi", setText);
        }
        if (lang === "en") {
            _service__WEBPACK_IMPORTED_MODULE_10__/* .handleCategoryClient.handleGetAllCategory */ .J0.handleGetAllCategory("EN").then((result)=>{
                setCategory(result);
            }).catch((error)=>{});
        } else {
            _service__WEBPACK_IMPORTED_MODULE_10__/* .handleCategoryClient.handleGetAllCategory */ .J0.handleGetAllCategory("VI").then((result)=>{
                setCategory(result);
            }).catch((error)=>{});
        }
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (category && category.length > 0) {
            const newArray = category.map((item)=>({
                    key: item.id,
                    label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                        href: `/san-pham/` + item.link,
                        className: "navbar__pc-item-dropdown-item",
                        style: {
                            width: 500
                        },
                        children: item.name
                    })
                }));
            setItems(newArray);
        }
    }, [
        category
    ]);
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.language.currentLanguage);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (0,_languages__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(lang, setText);
    }, [
        lang
    ]);
    const cartItems = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.cart.items);
    const totalQuantity = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.cart.totalQuantity);
    const [searchVisible, setSearchVisible] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [searchText, setSearchText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [btnClasses, setBtnCalss] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [numberOfCartItems, setNumberOfCartItems] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    // console.log(cartItems, "cartItems");
    // const numberOfCartItems = cartItems.reduce((currNumber, item) => {
    //   return currNumber + item.quantity;
    // }, 0);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (cartItems) {
            setBtnCalss(`"cart" ${isBtnHighlighted ? (_Nav_module_css__WEBPACK_IMPORTED_MODULE_11___default().bump) : ""}`);
            const number = cartItems.reduce((currNumber, item)=>{
                return currNumber + item.quantity;
            }, 0);
            setNumberOfCartItems(number);
        }
    }, [
        cartItems
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (totalQuantity) {
            setIsBtnHighlighted(true);
            const timer = setTimeout(()=>{
                setIsBtnHighlighted(false);
            }, 300);
            return ()=>{
                clearTimeout(timer);
            };
        }
    }, [
        totalQuantity
    ]);
    const handleSearch = (e)=>{
        setSearchText(e.target.value);
    };
    const toggleSearchVisible = ()=>{
        setSearchVisible(!searchVisible);
    };
    const handleInputClick = (e)=>{
        e.stopPropagation();
    };
    const cartContent = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: cartItems.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                    className: "cart-title",
                    children: t.button.BUTTON8
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.List, {
                    size: "small",
                    dataSource: cartItems,
                    className: "cart-list",
                    renderItem: (item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_2__.List.Item, {
                            className: "cart-item",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "cart-item-information",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            src: `${"https://api.thuongthuonghandmade.vn"}/${item.imageUrl}`,
                                            alt: item.title,
                                            className: "cart-item-information-img",
                                            width: 60,
                                            height: 60
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "cart-item-information-text",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                    className: "cart-item-information-text-title",
                                                    children: item.title
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                    className: "cart-item-information-text-quantity",
                                                    children: [
                                                        t.products.QUANTITY,
                                                        ": x",
                                                        item.quantity
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "cart-item-price",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "cart-item-price-text",
                                        children: item.price === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: t.products.PRICE
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: item.price
                                        })
                                    })
                                })
                            ]
                        })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "cart-btn",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                        href: "/gio-hang",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Button, {
                            type: "primary",
                            className: "btn btn-primary cart-btn-item",
                            children: t.button.BUTTON9
                        })
                    })
                })
            ]
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                    src: "images/cart_empty.png",
                    alt: "Thương Thương giỏ h\xe0ng",
                    className: "cart-none-image",
                    width: 360,
                    height: 260
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                    className: "cart-none-text",
                    children: t.notical.TITLE1
                })
            ]
        })
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "navbar__pc",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: "navbar__pc-logo",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                        href: "/",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            src: "/icon/logo.png",
                            alt: "ThuongThuong",
                            width: 70,
                            height: 60,
                            loading: "lazy",
                            className: "navbar__pc-logo-img"
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "navbar__pc-menu",
                    children: [
                        data.map((item, index)=>{
                            if (item.isActivate) {
                                if (item.link === "/san-pham") {
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Dropdown, {
                                        menu: {
                                            items
                                        },
                                        placement: "bottom",
                                        // trigger={["click"]}
                                        className: "navbar__pc-menu-products",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                            className: currentUrl.includes(item.link) ? "navbar__pc-item-active" : "navbar__pc-item",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                href: item.link,
                                                children: item.title
                                            })
                                        })
                                    }, item.key);
                                } else if (item.link.includes("tin-tuc")) {
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: currentUrl.includes("tin-tuc") ? "navbar__pc-item-active" : "navbar__pc-item",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            href: item.link,
                                            children: item.title
                                        })
                                    }, item.key);
                                } else {
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: item.link === currentUrl ? "navbar__pc-item-active" : "navbar__pc-item",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                            href: item.link,
                                            children: item.title
                                        })
                                    }, item.key);
                                }
                            } else {
                                return null;
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Menu, {
                            mode: "horizontal",
                            style: {
                                display: "flex",
                                justifyContent: "space-between",
                                alignItems: "center"
                            },
                            items: [
                                {
                                    key: "cart",
                                    label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Popover, {
                                        placement: "bottom",
                                        content: cartContent,
                                        className: btnClasses,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Badge, {
                                            count: numberOfCartItems,
                                            overflowCount: 99,
                                            style: {
                                                backgroundColor: "red"
                                            },
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                href: "/gio-hang",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__.ShoppingCartOutlined, {
                                                        style: {
                                                            fontSize: "18px",
                                                            color: "#fff"
                                                        }
                                                    }),
                                                    style: {
                                                        border: "none",
                                                        textDecoration: "underline",
                                                        boxShadow: "none"
                                                    }
                                                })
                                            })
                                        })
                                    }),
                                    className: "navbar__pc-icon"
                                },
                                {
                                    key: "search",
                                    label: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        style: {
                                            position: "relative"
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__.SearchOutlined, {
                                                style: {
                                                    fontSize: "18px",
                                                    color: "#fff"
                                                }
                                            }),
                                            searchVisible && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    position: "absolute",
                                                    top: "100%",
                                                    right: 0,
                                                    width: "300px",
                                                    zIndex: 1
                                                },
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Input, {
                                                    placeholder: t.label.LABEL5,
                                                    prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_5__.SearchOutlined, {}),
                                                    style: {
                                                        width: "100%"
                                                    },
                                                    onClick: handleInputClick
                                                })
                                            })
                                        ]
                                    }),
                                    className: "navbar__pc-icon",
                                    onClick: toggleSearchVisible
                                }
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavbarPC);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8612:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4516);

const loadLanguageText = (lang, setText)=>{
    switch(lang){
        case "vi":
            Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 4516, 19)).then((vieText)=>{
                setText(vieText);
            });
            break;
        case "en":
            __webpack_require__.e(/* import() */ 2682).then(__webpack_require__.t.bind(__webpack_require__, 2682, 19)).then((engText)=>{
                setText(engText);
            });
            break;
        case "por":
            __webpack_require__.e(/* import() */ 7504).then(__webpack_require__.t.bind(__webpack_require__, 7504, 19)).then((porText)=>{
                setText(porText);
            });
            break;
        case "fr":
            __webpack_require__.e(/* import() */ 6348).then(__webpack_require__.t.bind(__webpack_require__, 6348, 19)).then((freText)=>{
                setText(freText);
            });
            break;
        default:
            setText(_languages_vie_json__WEBPACK_IMPORTED_MODULE_0__);
            break;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (loadLanguageText);


/***/ }),

/***/ 4516:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"menu":{"MENU1":"Trang Chủ","MENU2":"Giới Thiệu","MENU3":"Tin tức","MENU4":"Sản Phẩm","SUBMENU1":"Tranh Giấy","SUBMENU2":"Đồ Thủ Công Khảm Trai","SUBMENU3":"Tranh Lụa","SUBMENU4":"Tranh Khắc Gỗ","MENU5":"Tuyển Dụng","MENU6":"Liên Hệ"},"home":{"SLIDER":"Xem chi tiết","HEADER1":"Những mảnh ghép","TITLE1":"Những mảnh ghép","DESCRIPTION1":"Cuộc sống luôn là những mảnh ghép đầy sắc màu. Bên cạnh những màu đỏ chói lọi là màu trắng tinh khôi, bên cạnh màu vàng rực rỡ là màu xanh dịu mát… Mỗi chúng ta là một mảnh ghép số phận mang cá tính, sứ mệnh, sự khiếm khuyết khác nhau và cùng góp mặt trên cuộc sống này.","DESCRIPTION1_SUB":"Mảnh ghép nào cũng quý, màu sắc nào cũng đẹp, đừng để gam màu của mình bị pha tạp, những hình dạng của mình bị méo mó, hãy biến sự khiếm khuyết thành hoàn hảo, sống như những gì vốn có, để khẳng định bản thân mình…","HEADER2":"Sản phẩm thay lời nói","HEADER3":"SẢN PHẨM NỔI BẬT","HEADER4":"Tin tức sự kiện","TITLE4_1":"Thương Thương test tin tức","DESCRIPTION4_1":"Sản phẩm bộ mèo Đại Cát được bà Vũ Chi Mai tổng lãnh sự quán Việt Nam lựa chọn làm quà tặng cho bà Lương Thị Lan Anh Chủ tịch Hiệp hội DN Kyushu phía Việt Nam và ông Naoki Koga Ủy viên Hiệp hội DN Kyushu Việt Nam.","TIME4_1":"Thứ sáu, ngày 27/02/2023","TITLE4_2":"Kết nối thương mại, đầu tư giữa các DN trong nước, DN kiều bào và DN Nhật Bản","DESCRIPTION4_2":"Kết nối thương mại, đầu tư giữa các DN trong nước, DN kiều bào và DN Nhật Bản Kết nối thương mại, đầu tư giữa các DN trong nước","TIME4_2":"Thứ sáu, ngày 27/02/2023","TITLE4_3":"Ủy ban Xã hội thăm, làm việc với Công ty Thương Thương","DESCRIPTION4_3":"Ủy ban Xã hội thăm, làm việc với Công ty Thương Thương Ủy ban Xã hội thăm, làm việc với Công ty Thương Thương Ủy ban Xã hội thăm","TIME4_3":"Thứ sáu, ngày 27/02/2023","HEADER5":"Đối Tác Của Chúng Tôi","HEADER6":"Liên hệ với chúng tôi","TITLE6_1":"Điện thoại : + 84 24 3993 9819","TITLE6_2":"Hotline : + 84 98 408 9990","TITLE6_3":"Email : info@thuongthuong.com.vn","TITLE6_4":"Add : 123 Trung Văn, Nam Từ Liêm, Hà Nội","TITLE6_5":"Add : Thương Thương tại Nhật Bản 591_8037 1_6_1 #410 Mozu Akahatacho, Sakai, Osaka, Japan.","TITLE6_6":"XƯỞNG: 08:00 _ 17:30, DỊCH VỤ: 08:00 _ 23:00","DESCRIPTION6_1":"Thương Thương Space là một không gian mở và kiến tạo được Thương Thương hun đúc trong những năm qua.","DESCRIPTION6_2":"Chúng tôi mong muốn cùng sự chung tay của cộng đồng để tạo dựng hệ sinh thái bền vững,","DESCRIPTION6_3":"hòa nhập và phát triển vì người khuyết tật và người yếu thế."},"about_pages":{"TITLE1":"Đem những điều mới lạ và thú vị hơn đến với cuộc sống hàng ngày.","DESCRIPTION1":"Những nghệ sỹ chính là khởi nguồn của sáng tạo. Họ là người yêu thích văn hoá và kể lại những câu chuyện mới lạ qua tác phẩm sáng tạo độc đáo của mình, chúng tôi gọi đó là sức sáng tạo cá nhân. Tuy nhiên các tác phầm thường chỉ nằm trên giấy, trên máy tính cá nhân hay trong cộng đồng nghệ sỹ xung quanh họ. Vì vậy TiredCity đóng vai trò là cầu nối lan toả hàng ngàn tác phẩm từ hàng ngàn nghệ sỹ khắp Việt Nam tới bạn.","TITLE2":"Lan toả sáng tạo cá nhân trong từng sản phẩm ứng dụng","DESCRIPTION2":"Được thành lập vào tháng 10/2016, TiredCity là doanh nghiệp chuyên về quản trị, sản xuất và phân phối các dòng sản phẩm bao gồm thời trang, văn phòng phẩm, phụ kiện và tranh in (Artprint), đa phần là các bản in mang tác phẩm của các nghệ sỹ trẻ hàng đầu Việt Nam."},"list_news":{"TITLE":"Theo thống kê của Bộ Thương binh và LĐXH _ 2019","DESCRIPTION":"“ThuongThuong chơi” là chương trình giáo dục trải nghiệm độc đáo dành riêng cho đối tượng học sinh. Chương trình được xây dựng bởi doanh nghiệp xã hội Thuongthuong và những chuyên gia giáo dục uy tín. “ThuongThuong chơi” nằm trong khuôn khổ của “ThuongThuong Edu”, một nhánh thuộc hệ sinh thái Thuongthuong. Với chương trình công phu, ý nghĩa và hấp dẫn như “ThuongThuong chơi”, Thuongthuong khát khao chung tay phát triển giáo dục, cùng xã hội vun đắp những thế hệ Việt ưu tú, giàu cảm xúc, giàu kĩ năng, giàu trải nghiệm.","TIME":"Thứ sáu, ngày 27/02/2023"},"news":{"TITLE":"TIÊU ĐỀ TIN TỨC TEST","MENU":"Sự kiện","SUB1":"Sản phẩm người khuyết tật","SUB2":"Đóng góp tình thương"},"list_products":{"TITLE":"DANH MỤC SẢN PHẨM","TITLE1":"TOÀN BỘ SẢN PHẨM","TITLE2":"Có tất cả","MENU1":"Tranh Giấy","DES1":"Tranh Phố Giấy Cuốn","DES2":"Tranh Chim","DES3":"Tranh Trống Đồng","DES4":"Tranh Hoa","DES5":"Tranh Trống Đồng"},"carts":{"HEADER":"GIỎ HÀNG","MENU1":"Sản Phẩm","MENU2":"Đơn Giá","MENU3":"Số Lượng","MENU4":"Tạm Tính","TITLE":"THÔNG TIN ĐƠN HÀNG","LABEL1":"Tạm Tính","LABEL2":"sp","LABEL3":"Tổng Tiền","LABEL4":"Đã bao gồm VAT (nếu có)","NOTICAL1":"XÓA ĐƠN HÀNG","NOTICAL2":"TIẾN HÀNH ĐẶT HÀNG","NOTICAL3":"ĐẶT HÀNG","NOTICAL_TEXT1":"Bạn chắc chắn muốn xóa sản phẩm","NOTICAL_TEXT2":"này khỏi giỏ hàng ?","NOTICAL_TEXT3":"Bạn chưa có sản phẩm nào trong giỏ hàng !!!"},"bills":{"HEADER":"THANH TOÁN","TITLE1":"Thông Tin Nhận Hàng","DESCRIPTION1":"Bạn chưa có địa chỉ nhận hàng hãy bấm thêm địa chỉ mới","TITLE2":"Thời Gian Nhận Hàng","DESCRIPTION2_1":"Chỉ giao hàng giờ hành chính (phù hợp với địa chỉ văn phòng/cơ quan)","DESCRIPTION2_2":"Tất cả các ngày trong tuần (phù hợp với địa chỉ nhà riêng, luôn có người nhận hàng)","DESCRIPTION2_3":"Giao nhanh trong 2h (áp dụng với địa chỉ giao hàng tại Hà Nội và Hồ Chí Minh)","DESCRIPTION2_4":"Khác ...","TITLE3":"Ghi Chú Đơn Hàng","DESCRIPTION3":"Lời nhắn cho người bán","TITLE5":"Họ tên","TITLE6":"Số điện thoại","TITLE7":"Email","TITLE8":"Địa chỉ","TITLE9":"Đặt hàng thành công!","TITLE10":"Đặt hàng thất bại!","TITLE11":"Quay về trang chủ","TITLE12":"Thử lại"},"footer":{"TITLE1":"Danh Mục","TITLE2":"Hướng Dẫn","TITLE3":"Hỗ Trợ","TITLE4":"Liên Hệ","LISTMENU1_1":"Unisex Tee","LISTMENU1_2":"Gifts","LISTMENU1_3":"Collection","LISTMENU1_4":"Newsletter","LISTMENU1_5":"Community","LISTMENU1_6":"Về Thương Thương","LISTMENU2_1":"Hướng dẫn mua hàng","LISTMENU2_2":"Hướng dẫn thanh toán","LISTMENU3_1":"Tìm kiếm","LISTMENU3_2":"Đăng nhập","LISTMENU3_3":"Đăng ký","LISTMENU3_4":"Giỏ hàng","LISTMENU4_1":"123 Main Street, New York, NY 10001, 123 Main Street, New York, NY 10001 , 123 Main Street, New York, NY 10001","LISTMENU4_2":"0981.83.9980","LISTMENU4_3":"Sonnguyenprofessor@gmail.com","LISTMENU5_1":"Giới Thiệu","LISTMENU5_2":"Tin Tức","LISTMENU5_3":"©2023 Bản quyền thuộc về ThuongThuong"},"button":{"BUTTON1":"Xem Thêm","BUTTON2":"Ẩn bớt","BUTTON3":"Xem Tất Cả","BUTTON4":"Mua Ngay","BUTTON5":"Thêm Giỏ Hàng","BUTTON6":"Gửi","BUTTON7":"Chia sẻ","BUTTON8":"Sản phẩm mới thêm","BUTTON9":"Xem giỏ hàng","BUTTON10":"TIẾN HÀNG ĐẶT HÀNG","BUTTON11":"ĐẶT HÀNG","BUTTON12":"Thêm địa chỉ mới","BUTTON13":"TRỞ LẠI","BUTTON14":"XÁC NHẬN"},"label":{"LABEL1":"Họ và Tên","LABEL2":"Email","LABEL3":"Số điện thoại","LABEL4":"Lời nhắn","LABEL5":"Tìm kiếm"},"products":{"TITLE1":"Tranh Phố Cổ 45x45","TITLE2":"Tranh Con Công 65x65","TITLE3":"Tranh Hoa Sen 45x70","TITLE4":"Tranh Giấy Cuốn 25x30","TITLE5":"Bộ Bàn Cờ Vua Gỗ Khảm Trai 25x30","TITLE6":"Tranh Thuê Hoa Thổ Cẩm","DES_TITLE":"Mô tả sản phẩm","DESCRIPTION":"Quilling này hoa mẫu được tạo ra bằng cách sử dụng dải giấy mỏng, Quilling chỉ là một hình thức nghệ thuật để tạo ra mô hình đẹp bằng cách lăn, xoắn và ép mỏng giấy tờ thành dạng mong muốn của bạn và hình dạng, thông thường là một công cụ Quilling được sử dụng và tất cả các phần mô_đun được tạo ra đầu tiên và sau đó đặt tất cả lại với nhau để tạo ra nghệ thuật đã hoàn thành. Mô hình hoa Quilling này là lý tưởng được sử dụng để tạo ra thẻ đẹp ba chiều cho lời mời đám cưới.","PRICE":"Giá Liên Hệ","CATEGORY":"Danh mục sản phẩm","CATEGORY_TEXT":"Tranh Giấy","SUB":"Sản Phẩm Của Người Khuyết Tật","QUANTITY":"Số Lượng","HEADER1":"SẢN PHẨM CÙNG LOẠI","HEADER2":"CHI TIẾT SẢN PHẨM","HEADER3":"CÓ THỂ BẠN QUAN TÂM"},"navigator":{"HOME":"Trang chủ","MENU1":"Toàn bộ tin tức","MENU2":"Toàn bộ sản phẩm","MENU3":"Tuyển Dụng","MENU4":"Liên Hệ","MENU5":"Giỏ hàng","MENU6":"Đơn hàng","MENU7":"Tin tức","MENU8":"Tin tức test","MENU9":"Tranh giấy","MENU10":"Tranh cuốn giấy"},"notical":{"TITLE1":"Chưa có sản phẩm nào trong giỏ hàng !","TITLE2":"Sản phẩm đã được thêm vào giỏ hàng !","TITLE3":"Vui lòng nhập họ và tên của bạn !","TITLE4":"Email không hợp lệ !","TITLE5":"Vui lòng nhập email của bạn !","TITLE6":"Số điện thoại không hợp lệ !","TITLE7":"Vui lòng nhập số điện thoại của bạn !","TITLE8":"","TITLE9":"","TITLE10":"","TITLE11":""}}');

/***/ })

};
;