"use strict";
exports.id = 8580;
exports.ids = [8580];
exports.modules = {

/***/ 461:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "E": () => (/* reexport */ titleBlock),
  "L": () => (/* reexport */ titleProduct)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/elements/block/titleBlock.tsx


const TitleBlock = ({ title , urlImage , underlined  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: (title || urlImage) && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "home__title",
            children: [
                urlImage && /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "https://api.thuongthuonghandmade.vn" + "/" + urlImage,
                    alt: "ThuongThuong",
                    width: 80,
                    height: 80,
                    loading: "lazy"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    className: "home__title-text",
                    children: title
                }),
                underlined && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "home__title-wall",
                    children: " "
                })
            ]
        })
    });
};
/* harmony default export */ const titleBlock = (TitleBlock);

// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/elements/block/titleProduct.tsx



const TitleProduct = ({ title , link , t  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        style: {
            display: "flex",
            justifyContent: "space-between"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "home__products-header-title",
                children: title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    display: "flex",
                    alignItems: "center"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Button, {
                    type: "primary",
                    size: "large",
                    className: "home__products-header-btn",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: link,
                        className: "home__products-header-btn-text",
                        children: t.button.BUTTON3
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const titleProduct = (TitleProduct);

;// CONCATENATED MODULE: ./src/components/elements/block/index.ts




/***/ }),

/***/ 1287:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9648);
/* harmony import */ var _utils_Functions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9343);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_4__, _utils_Functions__WEBPACK_IMPORTED_MODULE_5__]);
([axios__WEBPACK_IMPORTED_MODULE_4__, _utils_Functions__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const { TextArea  } = antd__WEBPACK_IMPORTED_MODULE_2__.Input;
const FormContactHome = (props)=>{
    const { t  } = props;
    const [contactForm] = antd__WEBPACK_IMPORTED_MODULE_2__.Form.useForm();
    const onFinish = async (values)=>{
        try {
            await axios__WEBPACK_IMPORTED_MODULE_4__["default"].post(`${"https://api.thuongthuonghandmade.vn"}/contact`, values).then((e)=>{
                _utils_Functions__WEBPACK_IMPORTED_MODULE_5__/* .Message.successNotify */ .v0.successNotify("Tạo li\xean hệ th\xe0nh c\xf4ng");
                console.log("contactForm", contactForm.getFieldsValue());
                contactForm.resetFields();
            });
        } catch (error) {
            _utils_Functions__WEBPACK_IMPORTED_MODULE_5__/* .Message.errorNotify */ .v0.errorNotify(error.response.data.message);
        }
    // console.log('Received values of form: ', formRef.current?.description)
    };
    const onReset = ()=>{
        contactForm.resetFields();
    };
    const handleSubmit = ()=>{};
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_2__.Form, {
            name: "contactForm",
            form: contactForm,
            onFinish: onFinish,
            initialValues: {
                remember: true
            },
            layout: "vertical",
            className: "home__contact-wrap-right-form",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                    name: "name",
                    label: t.label.LABEL1,
                    className: "home__contact-wrap-right-form",
                    rules: [
                        {
                            required: true,
                            message: `${t.notical.TITLE3}`
                        }
                    ],
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Input, {
                        prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__.UserOutlined, {})
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                    name: "email",
                    label: t.label.LABEL2,
                    rules: [
                        {
                            type: "email",
                            message: `${t.notical.TITLE4}`
                        },
                        {
                            required: true,
                            message: `${t.notical.TITLE5}`
                        }
                    ],
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Input, {
                        prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__.MailOutlined, {})
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                    name: "phone",
                    label: t.label.LABEL3,
                    rules: [
                        {
                            required: true,
                            message: `${t.notical.TITLE7}`
                        }
                    ],
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Input, {
                        prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__.PhoneOutlined, {})
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                    name: "message",
                    label: t.label.LABEL4,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextArea, {
                        rows: 4
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        type: "primary",
                        htmlType: "submit",
                        children: t.button.BUTTON6
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormContactHome);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 277:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* reexport safe */ _FormContactHome__WEBPACK_IMPORTED_MODULE_0__.Z)
/* harmony export */ });
/* harmony import */ var _FormContactHome__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1287);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_FormContactHome__WEBPACK_IMPORTED_MODULE_0__]);
_FormContactHome__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;