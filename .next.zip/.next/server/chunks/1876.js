"use strict";
exports.id = 1876;
exports.ids = [1876];
exports.modules = {

/***/ 1684:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ cart_Cart)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./store/slices/cartSlice.ts
var cartSlice = __webpack_require__(633);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./src/languages/vie.json
var vie = __webpack_require__(4516);
// EXTERNAL MODULE: external "@ant-design/icons"
var icons_ = __webpack_require__(7066);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./src/languages/index.ts
var languages = __webpack_require__(8612);
;// CONCATENATED MODULE: ./src/components/elements/cart/CartItem.tsx








const CartItem = (props)=>{
    const item = props.item;
    const [text, setText] = (0,external_react_.useState)(vie);
    const lang = (0,external_react_redux_.useSelector)((state)=>state.language.currentLanguage);
    (0,external_react_.useEffect)(()=>{
        (0,languages/* default */.Z)(lang, setText);
    }, [
        lang
    ]);
    console.log(item, "item");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
        className: "products-cart-table-body-item",
        children: [
            props.showCheckbox && /*#__PURE__*/ jsx_runtime_.jsx("td", {
                className: "products-cart-table-body-item-0",
                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                    type: "checkbox",
                    checked: item.selected,
                    onChange: props.onCheckOneItem.bind(null, item.id),
                    className: "products-cart-table-input"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                className: "products-cart-table-body-item-1",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: `${"https://api.thuongthuonghandmade.vn"}/${item.imageUrl}`,
                        alt: item.title,
                        width: 80,
                        height: 80,
                        className: "products-cart-table-body-item-1-img"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "products-cart-table-body-item-1-title",
                        children: item.title
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                className: "products-cart-table-body-item-2",
                children: !item.price ? text.products.PRICE : item.price + " ₫"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                className: "products-cart-table-body-item-3",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    style: {
                        display: "flex",
                        alignItems: "center"
                    },
                    children: [
                        " ",
                        props.showCheckbox && /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Button, {
                            onClick: props.onRemoveItem.bind(null, item.id),
                            className: "products-cart-table-body-item-3-btn",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "products-cart-table-body-item-3-btn-icon",
                                children: "-"
                            })
                        }),
                        props.showCheckbox && /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.InputNumber, {
                            value: item.quantity,
                            style: {
                                color: "black",
                                margin: "0 0.2em",
                                background: "#fafafa",
                                pointerEvents: "none"
                            },
                            className: "products-cart-table-body-item-3-input",
                            disabled: true
                        }),
                        !props.showCheckbox && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            style: {
                                color: "black",
                                fontWeight: "bold",
                                fontSize: 16.5,
                                margin: "0 2.2em",
                                background: "#fafafa",
                                pointerEvents: "none"
                            },
                            children: [
                                "x",
                                item.quantity
                            ]
                        }),
                        " ",
                        props.showCheckbox && /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Button, {
                            onClick: props.onAddItem.bind(null, item),
                            className: "products-cart-table-body-item-3-btn",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "products-cart-table-body-item-3-btn-icon",
                                children: "+"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                className: "products-cart-table-body-item-4",
                children: item.price ? item.price * item.quantity + " ₫" : text.products.PRICE
            }),
            " ",
            props.showCheckbox && /*#__PURE__*/ jsx_runtime_.jsx("td", {
                className: "products-cart-table-body-item-5",
                children: /*#__PURE__*/ jsx_runtime_.jsx(icons_.DeleteOutlined, {
                    onClick: props.onDeleteModal.bind(null, item.id)
                })
            })
        ]
    }, item.id);
};
/* harmony default export */ const cart_CartItem = (CartItem);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);
;// CONCATENATED MODULE: ./src/components/elements/cart/Cart.tsx











const Cart = (props)=>{
    const { items , showCheckbox  } = props;
    const [itemToBeDeleted, setItemToBeDeleted] = (0,external_react_.useState)(0);
    const [text, setText] = (0,external_react_.useState)(vie);
    const lang = (0,external_react_redux_.useSelector)((state)=>state.language.currentLanguage);
    (0,external_react_.useEffect)(()=>{
        (0,languages/* default */.Z)(lang, setText);
    }, [
        lang
    ]);
    const allItemsSelected = (0,external_react_redux_.useSelector)((state)=>state.cart.allSelected);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const [totalOrderItems, setTotalOrderItems] = (0,external_react_.useState)(0);
    const [dataCart, setdataCart] = (0,external_react_.useState)([]);
    (0,external_react_.useEffect)(()=>{
        if (items) {
            const orderItemsTotal = items.filter((item)=>item.selected).reduce((currNumber, item)=>currNumber + item.quantity, 0);
            setTotalOrderItems(orderItemsTotal);
            setdataCart(items);
        }
    }, [
        items
    ]);
    const [isModalItemOpen, setIsModalItemOpen] = (0,external_react_.useState)(false);
    const checkOneItemHandler = (id)=>{
        dispatch(cartSlice/* cartActions.checkItem */.Uw.checkItem(id));
    };
    const checkAllItemsHandler = ()=>{
        dispatch(cartSlice/* cartActions.checkAllItems */.Uw.checkAllItems());
    };
    const addItemHandler = (item)=>{
        dispatch(cartSlice/* cartActions.addItemToCart */.Uw.addItemToCart(item));
    };
    const decreaseItemQuantityHandler = (id)=>{
        dispatch(cartSlice/* cartActions.decreaseItemQuantity */.Uw.decreaseItemQuantity(id));
    };
    const confirmOrderHandler = ()=>{
        router_default().push("/don-hang");
    };
    const confirmDeleteItemsHandler = ()=>{
        dispatch(cartSlice/* cartActions.removeItemFromCart */.Uw.removeItemFromCart(items.filter((item)=>item.selected).map((item)=>item.id)));
        setIsModalItemOpen(false);
        if (allItemsSelected) {
            cartSlice/* cartActions.toggleSelected */.Uw.toggleSelected();
        }
    };
    const confirmDeleteItemHandler = ()=>{
        dispatch(cartSlice/* cartActions.removeItemFromCart */.Uw.removeItemFromCart([
            itemToBeDeleted
        ]));
        setIsModalItemOpen(false);
    };
    const deleteItemHandler = (id)=>{
        setItemToBeDeleted(id);
        setIsModalItemOpen(true);
    };
    const deleteItemsHandler = ()=>{
        setIsModalItemOpen(true);
    };
    const handleCancel = ()=>{
        setIsModalItemOpen(false);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Modal, {
                    centered: true,
                    visible: isModalItemOpen,
                    onCancel: handleCancel,
                    className: "products-cart-modal",
                    footer: [],
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "products-cart-modal-title",
                            children: text.carts.NOTICAL1
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            className: "products-cart-modal-description",
                            children: [
                                text.carts.NOTICAL_TEXT1,
                                " ",
                                text.carts.NOTICAL_TEXT2
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "products-cart-modal-group",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "products-cart-modal-group-btn1",
                                    onClick: handleCancel,
                                    children: text.button.BUTTON13
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "products-cart-modal-group-btn2",
                                    onClick: itemToBeDeleted ? confirmDeleteItemHandler : confirmDeleteItemsHandler,
                                    children: text.button.BUTTON14
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "products-cart",
                    children: [
                        dataCart && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                            children: dataCart.length > 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                                className: "products-cart-table",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            className: "products-cart-table-header",
                                            children: [
                                                showCheckbox && /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "products-cart-table-header-0",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        type: "checkbox",
                                                        className: "products-cart-table-input",
                                                        style: {
                                                            width: "20px",
                                                            height: "20px"
                                                        },
                                                        checked: allItemsSelected,
                                                        onChange: checkAllItemsHandler
                                                    })
                                                }),
                                                totalOrderItems > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("th", {
                                                            className: "products-cart-table-header-1",
                                                            children: [
                                                                text.carts.MENU1,
                                                                " ",
                                                                showCheckbox && `(${totalOrderItems})`
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                            className: "products-cart-table-header-2"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                            className: "products-cart-table-header-3"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                            className: "products-cart-table-header-4"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("th", {
                                                            className: "products-cart-table-header-5",
                                                            children: [
                                                                " ",
                                                                showCheckbox && /*#__PURE__*/ jsx_runtime_.jsx(icons_.DeleteOutlined, {
                                                                    onClick: deleteItemsHandler
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                totalOrderItems === 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                            className: "products-cart-table-header-1",
                                                            children: text.carts.MENU1
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                            className: "products-cart-table-header-2",
                                                            children: text.carts.MENU2
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                            className: "products-cart-table-header-3",
                                                            children: text.carts.MENU3
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                            className: "products-cart-table-header-4",
                                                            children: text.carts.MENU4
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                            className: "products-cart-table-header-5"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                                        className: "products-cart-table-body",
                                        children: items.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(cart_CartItem, {
                                                item: item,
                                                unknownPrice: text.carts.LABEL1,
                                                onAddItem: addItemHandler.bind(null, item),
                                                onCheckOneItem: checkOneItemHandler.bind(null, item.id),
                                                onCheckAllItems: checkAllItemsHandler,
                                                onConfirmOrder: confirmOrderHandler,
                                                onRemoveItem: decreaseItemQuantityHandler.bind(null, item.id),
                                                onDeleteModal: deleteItemHandler.bind(null, item.id),
                                                showCheckbox: showCheckbox
                                            }, item.id))
                                    })
                                ]
                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "products-cart-embty",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "/images/cart_empty.png",
                                        width: 300,
                                        height: 220,
                                        alt: "Giỏ h\xe0ng trống",
                                        className: "products-cart-embty-img"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "products-cart-embty-text",
                                        children: text.carts.NOTICAL_TEXT3
                                    })
                                ]
                            })
                        }),
                        showCheckbox && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "products-cart-infor",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "products-cart-infor-header",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "products-cart-infor-title",
                                            children: text.carts.TITLE
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "products-cart-infor-block",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "products-cart-infor-block-title",
                                                    children: [
                                                        text.carts.LABEL1,
                                                        " ",
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "products-cart-infor-block-title-s",
                                                            children: [
                                                                "(",
                                                                totalOrderItems,
                                                                " ",
                                                                text.carts.LABEL2,
                                                                ")"
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "products-cart-infor-block-number",
                                                    children: text.products.PRICE
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "products-cart-infor-blockt",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "products-cart-infor-blockt-title",
                                                    children: text.carts.LABEL3
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "products-cart-infor-blockt-number",
                                                    children: text.products.PRICE
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "products-cart-infor-sub",
                                            children: text.carts.LABEL4
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: items.filter((item)=>item.selected).length > 0 ? "products-cart-infor-btn" : "products-cart-infor-btn-dis",
                                    onClick: confirmOrderHandler,
                                    children: text.carts.NOTICAL2
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const cart_Cart = (Cart);


/***/ }),

/***/ 8724:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ saveCartData),
/* harmony export */   "m": () => (/* binding */ fetchCartData)
/* harmony export */ });
/* harmony import */ var _slices_cartSlice__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(633);

const fetchCartData = ()=>{
    return (dispatch)=>{
        const cartData = JSON.parse(localStorage.getItem("cart") || "{}");
        if (cartData.length > 0) {
            dispatch(_slices_cartSlice__WEBPACK_IMPORTED_MODULE_0__/* .cartActions.replaceCart */ .Uw.replaceCart({
                items: cartData.items || [],
                totalQuantity: cartData.totalQuantity || 0,
                changed: false,
                allSelected: false
            }));
        }
    };
};
const saveCartData = (cart)=>{
    localStorage.setItem("cart", JSON.stringify({
        items: cart.items,
        totalQuantity: cart.totalQuantity
    }));
};


/***/ })

};
;