"use strict";
exports.id = 3951;
exports.ids = [3951];
exports.modules = {

/***/ 2287:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_Functions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9343);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd_img_crop__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2367);
/* harmony import */ var antd_img_crop__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd_img_crop__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_Functions__WEBPACK_IMPORTED_MODULE_1__, axios__WEBPACK_IMPORTED_MODULE_4__]);
([_utils_Functions__WEBPACK_IMPORTED_MODULE_1__, axios__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const URL = (/* unused pure expression or super */ null && (`${"https://api.thuongthuonghandmade.vn"}`));
const ImageUpload = (props)=>{
    const { linkUpload , data  } = props;
    const [fileList, setFileList] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)([]);
    const [errorMessage, setErrorMessage] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("");
    const onChange = ({ fileList: newFileList  })=>{
        // setErrorMessage('')
        setFileList(newFileList);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        if (props?.data?.imageUrl) {
            const initialFileList = [
                {
                    uid: "-1",
                    name: "image.jpg",
                    status: "done",
                    url: `${"https://api.thuongthuonghandmade.vn"}/${props.data.imageUrl}`
                }
            ];
            setFileList(initialFileList);
        }
    }, [
        props?.data
    ]);
    const onPreview = async (file)=>{
        let src = file.url;
        if (!src) {
            src = await new Promise((resolve)=>{
                const reader = new FileReader();
                reader.readAsDataURL(file.originFileObj);
                reader.onload = ()=>resolve(reader.result);
            });
        }
        const image = new Image();
        image.src = src;
        const imgWindow = window.open(src);
        imgWindow?.document.write(image.outerHTML);
    };
    const customUploadRequest = async (options)=>{
        const { onSuccess , onError , file  } = options;
        try {
            const body = new FormData();
            body.append("file", file, _utils_Functions__WEBPACK_IMPORTED_MODULE_1__/* .Diacritic.convertValueWithDashes */ .mz.convertValueWithDashes(file.name));
            const response = await axios__WEBPACK_IMPORTED_MODULE_4__["default"].post(`${"https://api.thuongthuonghandmade.vn"}/${linkUpload}`, body);
            props.data.imageUrl = `${response.data.path}`;
            setErrorMessage("");
            onSuccess(response.data, file);
        } catch (error) {
            // Xử lý lỗi nếu có
            setErrorMessage("Tải ảnh thất bại: " + error?.response?.data?.message);
            onError(error);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_img_crop__WEBPACK_IMPORTED_MODULE_3___default()), {
                rotationSlider: true,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Upload, {
                    customRequest: customUploadRequest,
                    listType: "picture-card",
                    fileList: fileList,
                    onChange: onChange,
                    onPreview: onPreview,
                    children: fileList.length < 1 && "+ Upload"
                })
            }),
            errorMessage !== "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                style: {
                    color: "red"
                },
                children: errorMessage
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageUpload);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4476:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ LANGUAGE_TABS)
/* harmony export */ });
const LANGUAGE_TABS = [
    {
        id: 1,
        key: "tab1",
        language: "VI",
        label: "Tiếng Việt"
    },
    {
        id: 2,
        key: "tab2",
        language: "EN",
        label: "Tiếng Anh"
    }
];


/***/ })

};
;