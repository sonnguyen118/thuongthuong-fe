"use strict";
exports.id = 2287;
exports.ids = [2287];
exports.modules = {

/***/ 7641:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "v": () => (/* reexport */ navigation_NavigationAdmin),
  "a": () => (/* reexport */ navigation_NavigationTopBar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@ant-design/icons"
var icons_ = __webpack_require__(7066);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/elements/navigation/NavigationTopBar.tsx




const NavigationTopBar = (props)=>{
    const { data  } = props;
    const [navigationData, setNavigationData] = (0,external_react_.useState)([]);
    (0,external_react_.useEffect)(()=>{
        setNavigationData(data);
        console.log(navigationData);
    }, [
        data
    ]);
    console.log(navigationData, "data");
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "navigation-top",
        children: navigationData && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: navigationData.map((menu, index)=>/*#__PURE__*/ jsx_runtime_.jsx((external_react_default()).Fragment, {
                    children: index !== data.length - 1 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: menu.link,
                                className: "navigation-top-text",
                                children: menu.title
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(icons_.RightOutlined, {
                                className: "navigation-top-icon"
                            })
                        ]
                    }) : /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: menu.link,
                        className: "navigation-top-text-lastchildren",
                        children: menu.title
                    })
                }, menu.id))
        })
    });
};
/* harmony default export */ const navigation_NavigationTopBar = (NavigationTopBar);

;// CONCATENATED MODULE: ./src/components/elements/navigation/NavigationAdmin.tsx




const NavigationAdmin = (props)=>{
    const { header , description , data  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "admin__element--navigation-wrap",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "admin__element--navigation",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "admin__element--navigation-title",
                        children: header
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "admin__element--navigation-fragment",
                        children: data.map((menu, index)=>/*#__PURE__*/ jsx_runtime_.jsx((external_react_default()).Fragment, {
                                children: index !== data.length - 1 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: menu.link,
                                            className: "admin__element--navigation-fragment-text",
                                            children: menu.title
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(icons_.RightOutlined, {
                                            className: "admin__element--navigation-fragment-icon"
                                        })
                                    ]
                                }) : /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: menu.link,
                                    className: "admin__element--navigation-fragment-text-lastchildren",
                                    children: menu.title
                                })
                            }, menu.id))
                    })
                ]
            }),
            description && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "admin__element--navigation-description",
                children: description
            })
        ]
    });
};
/* harmony default export */ const navigation_NavigationAdmin = (NavigationAdmin);

;// CONCATENATED MODULE: ./src/components/elements/navigation/index.ts




/***/ })

};
;