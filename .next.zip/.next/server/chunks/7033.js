"use strict";
exports.id = 7033;
exports.ids = [7033];
exports.modules = {

/***/ 7033:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5515);
/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_cookie__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_Functions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9343);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _slices_loadingState__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4214);
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4612);
/* harmony import */ var _service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2065);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_Functions__WEBPACK_IMPORTED_MODULE_5__, socket_io_client__WEBPACK_IMPORTED_MODULE_11__, _service__WEBPACK_IMPORTED_MODULE_12__]);
([_utils_Functions__WEBPACK_IMPORTED_MODULE_5__, socket_io_client__WEBPACK_IMPORTED_MODULE_11__, _service__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const Dashboard = ({ children  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const loading = (0,react_redux__WEBPACK_IMPORTED_MODULE_9__.useSelector)((state)=>state.loading.loading);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_9__.useDispatch)();
    const [notice, setNotice] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [totalNotice, setTotalNotice] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const toggleLoading = ()=>{
        dispatch((0,_slices_loadingState__WEBPACK_IMPORTED_MODULE_10__/* .setLoading */ .K4)(!loading));
    };
    const [collapsed, setCollapsed] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [searchVisible, setSearchVisible] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const toggleCollapsed = ()=>{
        setCollapsed(!collapsed);
    };
    const toggleSearchVisible = ()=>{
        setSearchVisible(!searchVisible);
    };
    const handleInputClick = (e)=>{
        e.stopPropagation();
    };
    // lấy dữ liệu order
    const [dataContact, setDataContact] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [dataContactSocket, setDataContactSocket] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [totalContact, setTotalContact] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [dataOrder, setDataOrder] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [dataOrderSocket, setDataOrderSocket] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [totalOrder, setTotalOrder] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const body = {
            status: 1,
            page: 1,
            size: 5
        };
        dispatch((0,_slices_loadingState__WEBPACK_IMPORTED_MODULE_10__/* .setLoading */ .K4)(true));
        _service__WEBPACK_IMPORTED_MODULE_12__/* .OrderAdmin.handleGetOrder */ .zI.handleGetOrder(body).then((result)=>{
            // Xử lý kết quả trả về ở đây
            const { data , meta  } = result;
            if (meta.status === 200) {
                setDataOrder(data.orders);
                setTotalOrder(data.pagination?.totalRecords ?? 0);
            }
            dispatch((0,_slices_loadingState__WEBPACK_IMPORTED_MODULE_10__/* .setLoading */ .K4)(false));
        }).catch((error)=>{
            // Xử lý lỗi ở đây
            console.log(error);
            dispatch((0,_slices_loadingState__WEBPACK_IMPORTED_MODULE_10__/* .setLoading */ .K4)(false));
        });
        _service__WEBPACK_IMPORTED_MODULE_12__/* .ContactAdmin.handleGetList */ .zq.handleGetList(body).then((result)=>{
            // Xử lý kết quả trả về ở đây
            const { data , meta  } = result;
            if (meta.status === 200) {
                setDataContact(data.contact);
                setTotalContact(data.pagination?.totalRecords ?? 0);
            }
            dispatch((0,_slices_loadingState__WEBPACK_IMPORTED_MODULE_10__/* .setLoading */ .K4)(false));
        }).catch((error)=>{
            // Xử lý lỗi ở đây
            console.log(error);
            dispatch((0,_slices_loadingState__WEBPACK_IMPORTED_MODULE_10__/* .setLoading */ .K4)(false));
        });
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (dataContact && dataOrder) {
            var total = Number(totalContact) + Number(totalOrder);
            var newArray = [];
            if (dataContact.length > 0) {
                dataContact.forEach((contact)=>{
                    const newContact = {
                        link: `/admin/lien-he/${contact.id}`,
                        title: "Li\xean Hệ mới",
                        time: contact.createdAt,
                        subTitle: " đ\xe3 gửi cho bạn một li\xean hệ mới",
                        name: contact.name,
                        email: contact.email,
                        phone: contact.phone,
                        isOrder: false
                    };
                    newArray.push(newContact);
                });
            }
            if (dataOrder.length > 0) {
                dataOrder.forEach((order)=>{
                    const newOrder = {
                        link: `/admin/lien-he/${order.id}`,
                        title: "Đơn H\xe0ng mới",
                        time: order.createdAt,
                        subTitle: " đ\xe3 tạo một đơn h\xe0ng mới",
                        name: order.name,
                        email: order.email,
                        phone: order.phone,
                        isOrder: true
                    };
                    newArray.push(newOrder);
                });
            }
            if (newArray.length > 0) {
                newArray.sort((a, b)=>{
                    const timeA = new Date(a.time).getTime();
                    const timeB = new Date(b.time).getTime();
                    return timeB - timeA;
                });
            }
            if (dataOrderSocket.length > 0) {
                newArray = [
                    ...dataOrderSocket,
                    ...newArray
                ];
                total += 1;
            }
            if (dataContactSocket.length > 0) {
                newArray = [
                    ...dataContactSocket,
                    ...newArray
                ];
                total += 1;
            }
            // set vào state
            setNotice(newArray);
            setTotalNotice(total);
        }
    }, [
        dataContact,
        dataOrder,
        totalContact,
        totalOrder,
        dataOrderSocket,
        dataContactSocket
    ]);
    const logoCompany = "/icon/logo.png";
    console.log(totalNotice, "totalNotice");
    // socket
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const api = "https://api.thuongthuonghandmade.vn";
        if (api) {
            const socket = (0,socket_io_client__WEBPACK_IMPORTED_MODULE_11__["default"])(api);
            socket.on("connect", ()=>{
                console.log("Connected to WebSocket");
            });
            socket.on("orderCreated", (order)=>{
                console.log("Received order:", order);
                // Xử lý thông tin đơn hàng ở đây
                showNotification("Hệ thống: Bạn c\xf3 đơn h\xe0ng mới", `${order.name} đã tạo một đơn hàng mới`, logoCompany);
                const orderPush = [
                    {
                        link: `/admin/lien-he/${order.id}`,
                        title: "Đơn H\xe0ng mới",
                        time: order.createdAt,
                        subTitle: " đ\xe3 tạo một đơn h\xe0ng mới",
                        name: order.name,
                        email: order.email,
                        phone: order.phone,
                        isOrder: true
                    }
                ];
                setDataOrderSocket(orderPush);
            });
            socket.on("newContact", (contact)=>{
                console.log("Received contact:", contact);
                // Xử lý thông tin đơn hàng ở đây
                showNotification("Hệ thống: Bạn c\xf3 li\xean hệ mới", `${contact.name} đã gửi cho bạn một liên hệ mới`, logoCompany);
                const contactPush = [
                    {
                        link: `/admin/lien-he/${contact.id}`,
                        title: "Li\xean Hệ mới",
                        time: contact.createdAt,
                        subTitle: " đ\xe3 gửi cho bạn một li\xean hệ mới",
                        name: contact.name,
                        email: contact.email,
                        phone: contact.phone,
                        isOrder: false
                    }
                ];
                setDataContactSocket(contactPush);
            });
            return ()=>{
                console.log("Connect Failure to WebSocket");
                socket.disconnect();
            };
        }
    }, []);
    function showNotification(title, body, icon) {
        if ("Notification" in window) {
            Notification.requestPermission().then(function(permission) {
                if (permission === "granted") {
                    var notification = new Notification(title, {
                        body: body,
                        icon: icon
                    });
                    notification.onclick = function() {
                        // Xử lý khi người dùng nhấp vào thông báo
                        console.log("Th\xf4ng b\xe1o đ\xe3 được nhấp");
                    };
                    setTimeout(function() {
                        notification.close();
                    }, 15000); // Đóng thông báo sau 15 giây
                }
            });
        }
    }
    // Function to generate menu items
    function getItem(label, key, icon, children, to) {
        return {
            key,
            label,
            icon,
            children,
            to
        };
    }
    // Render menu item function
    function renderMenuItem(item) {
        if (item.children) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Menu.SubMenu, {
                icon: item.icon,
                title: item.label,
                children: item.children.map(renderMenuItem)
            }, item.key);
        } else if (item.to) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Menu.Item, {
                icon: item.icon,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                    href: item.to,
                    children: item.label
                })
            }, item.key);
        } else {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Menu.Item, {
                icon: item.icon,
                children: item.label
            }, item.key);
        }
    }
    const items = [
        getItem("Dashbroad", "1", /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.PieChartOutlined, {}), undefined, "/admin"),
        getItem("Đơn H\xe0ng", "sub1", /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.ShoppingCartOutlined, {}), [
            getItem("Đơn H\xe0ng chưa xử l\xfd", "2", undefined, undefined, "/admin/don-hang/don-hang-chua-xu-ly"),
            getItem("Đơn H\xe0ng đ\xe3 xử l\xfd", "3", undefined, undefined, "/admin/don-hang/don-hang-da-xu-ly"),
            getItem("Tất cả Đơn H\xe0ng", "4", undefined, undefined, "/admin/don-hang")
        ]),
        getItem("Li\xean Hệ", "sub2", /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.MailOutlined, {}), [
            getItem("Li\xean Hệ chưa xử l\xfd", "9", undefined, undefined, "/admin/lien-he/lien-he-chua-xu-ly"),
            getItem("Li\xean Hệ đ\xe3 xử l\xfd", "8", undefined, undefined, "/admin/lien-he/lien-he-da-xu-ly"),
            getItem("Tất cả Li\xean Hệ", "10", undefined, undefined, "/admin/lien-he")
        ]),
        getItem("Danh Mục Sản Phẩm", "sub3", /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.ShopOutlined, {}), [
            getItem("Danh mục cấp 1", "13", undefined, undefined, "/admin/danh-muc/danh-muc-cap-1"),
            getItem("Danh mục cấp 2", "14", undefined, undefined, "/admin/danh-muc/danh-muc-cap-2"),
            getItem("Tạo mới Danh Mục cấp 1", "15", undefined, undefined, "/admin/danh-muc/tao-moi-danh-muc?level=1"),
            getItem("Tạo mới Danh Mục cấp 2", "16", undefined, undefined, "/admin/danh-muc/tao-moi-danh-muc?level=2"),
            getItem("Tất cả Danh Mục", "12", undefined, undefined, "/admin/danh-muc")
        ]),
        getItem("Sản Phẩm", "sub4", /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.InboxOutlined, {}), [
            getItem("To\xe0n bộ Sản Phẩm", "21", undefined, undefined, "/admin/san-pham/toan-bo-san-pham"),
            getItem("Sản Phẩm đ\xe3 ẩn", "20", undefined, undefined, "/admin/san-pham/san-pham-da-an"),
            getItem("Tạo mới Sản Phẩm", "22", undefined, undefined, "/admin/san-pham/tao-moi-san-pham"),
            getItem("Sản Phẩm b\xe1n chạy", "19", undefined, undefined, "/admin/san-pham/san-pham-noi-bat")
        ]),
        getItem("Layout", "sub5", /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.DesktopOutlined, {}), [
            getItem("Menu", "25", undefined, undefined, "/admin/layout/menu"),
            getItem("Footer", "26", undefined, undefined, "/admin/layout/footer")
        ]),
        getItem("B\xe0i viết hệ thống", "sub6", /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.FileProtectOutlined, {}), [
            getItem("Trang chủ", "29", undefined, undefined, "/admin/he-thong/trang-chu"),
            getItem("Giới Thiệu", "30", undefined, undefined, "/admin/he-thong/gioi-thieu"),
            getItem("Tuyển Dụng", "31", undefined, undefined, "/admin/he-thong/tuyen-dung"),
            getItem("Li\xean Hệ", "32", undefined, undefined, "/admin/he-thong/lien-he")
        ]),
        getItem("B\xe0i viết tin tức", "sub7", /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.FileTextOutlined, {}), [
            getItem("To\xe0n bộ b\xe0i viết", "35", undefined, undefined, "/admin/bai-viet"),
            getItem("Tạo b\xe0i viết", "37", undefined, undefined, "/admin/bai-viet/them-bai-viet")
        ]),
        getItem("Người D\xf9ng", "sub8", /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.UserOutlined, {}), [
            getItem("Danh s\xe1ch người d\xf9ng", "40", undefined, undefined, "/admin/user/list"),
            getItem("Th\xeam người d\xf9ng", "41", undefined, undefined, "/admin/user/add")
        ])
    ];
    const [cookies, setCookie, removeCookie] = (0,react_cookie__WEBPACK_IMPORTED_MODULE_3__.useCookies)([
        "accessToken",
        "refreshToken"
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!cookies.accessToken) {
            router.push("/login");
        }
    }, [
        cookies.accessToken,
        router
    ]);
    const handleMenuClick = (e)=>{
        handleLogout();
    };
    const handleLogout = ()=>{
        removeCookie("accessToken");
        removeCookie("refreshToken");
        router.push("/login");
    };
    // hàm kiểm tra và check đang ở menu nào
    const [selectedKeys, setSelectedKeys] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        "1"
    ]);
    const [openKeys, setOpenKeys] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        ""
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const url = router.route;
        const level = router.query.level;
        const slectorKeys = _utils_Functions__WEBPACK_IMPORTED_MODULE_5__/* .DasbroahAdmin.getSelectKeys */ .J3.getSelectKeys(url, level);
        setOpenKeys([
            slectorKeys?.openKeys
        ]);
        setSelectedKeys([
            slectorKeys?.selectedKeys
        ]);
    }, [
        router.route,
        router.query
    ]);
    const handeleOnClick = (link)=>{
        console.log(link, "link");
    };
    const cartContent = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: notice.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "admin__notice-title",
                    children: "TH\xd4NG B\xc1O"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "admin__notice-title-sub",
                    children: totalNotice > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            "Bạn c\xf3",
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "admin__notice-title-sub-highlight",
                                children: totalNotice
                            }),
                            " ",
                            "th\xf4ng b\xe1o chưa đọc"
                        ]
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: "Chưa c\xf3 th\xf4ng b\xe1o n\xe0o !!"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.List, {
                    size: "small",
                    dataSource: notice,
                    className: "admin__notice-list",
                    renderItem: (item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.List.Item, {
                            className: "admin__notice-item",
                            onClick: ()=>handeleOnClick(item.link),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "admin__notice-item-information",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "admin__notice-item-information-header",
                                        children: [
                                            item.isOrder ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.ShoppingCartOutlined, {
                                                className: "admin__notice-item-information-header-icon"
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.MailOutlined, {
                                                className: "admin__notice-item-information-header-icon"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "admin__notice-item-information-title",
                                                children: item.title
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "admin__notice-item-information-body",
                                        children: item.name + item.subTitle
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "admin__notice-item-information-time",
                                        children: _utils_Functions__WEBPACK_IMPORTED_MODULE_5__/* .DateTime.formatExacthlyTime */ .ou.formatExacthlyTime(item.time)
                                    })
                                ]
                            })
                        })
                })
            ]
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: "cart-none-text"
            })
        })
    });
    const itemsLogout = [
        {
            label: "Đăng xuất",
            key: "1",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.LogoutOutlined, {})
        }
    ];
    const menuProps = {
        items: itemsLogout,
        onClick: handleMenuClick
    };
    const handleMenuOpenChange = (keys)=>{
        setOpenKeys(keys.length > 0 ? keys : "");
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "admin__layout-dasbroah",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: collapsed ? "admin__layout-dasbroah-slidebar admin__layout-dasbroah-slidebar-off" : "admin__layout-dasbroah-slidebar admin__layout-dasbroah-slidebar-on",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                        href: "/admin",
                        className: "admin__layout-dasbroah-slidebar-header",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_8___default()), {
                                src: "/icon/logo.png",
                                alt: "logo",
                                width: 40,
                                height: 36,
                                className: "admin__layout-dasbroah-slidebar-header-logo"
                            }),
                            !collapsed && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "admin__layout-dasbroah-slidebar-header-title",
                                children: "ThuongThuong Admin"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Menu, {
                        mode: "inline",
                        theme: "dark",
                        selectedKeys: selectedKeys,
                        openKeys: openKeys,
                        onOpenChange: handleMenuOpenChange,
                        inlineCollapsed: collapsed,
                        className: "admin__layout-dasbroah-slidebar-menu",
                        children: items.map(renderMenuItem)
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "admin__layout-dasbroah-slidebar-logout",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.LogoutOutlined, {
                                className: "admin__layout-dasbroah-slidebar-logout-icon"
                            }),
                            !collapsed && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "admin__layout-dasbroah-slidebar-logout-text",
                                onClick: handleLogout,
                                children: "Đăng xuất"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: collapsed ? "admin__layout-dasbroah-wrap admin__layout-dasbroah-wrap-off" : "admin__layout-dasbroah-wrap admin__layout-dasbroah-wrap-on",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: collapsed ? "admin__layout-dasbroah-navbar admin__layout-dasbroah-navbar-off" : "admin__layout-dasbroah-navbar admin__layout-dasbroah-navbar-on",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                type: "primary",
                                onClick: toggleCollapsed,
                                style: {
                                    marginBottom: 16
                                },
                                className: "admin__layout-dasbroah-navbar-btn",
                                children: collapsed ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.MenuUnfoldOutlined, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.MenuFoldOutlined, {})
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "admin__layout-dasbroah-navbar-information",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Menu, {
                                        mode: "horizontal",
                                        style: {
                                            display: "flex",
                                            justifyContent: "space-between",
                                            alignItems: "center",
                                            width: "100%"
                                        },
                                        className: "admin__layout-dasbroah-navbar-information-notical",
                                        items: [
                                            {
                                                key: "search",
                                                label: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    style: {
                                                        position: "relative"
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.SearchOutlined, {
                                                            style: {
                                                                fontSize: "18px"
                                                            }
                                                        }),
                                                        searchVisible && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            style: {
                                                                position: "absolute",
                                                                top: "100%",
                                                                right: 0,
                                                                width: "300px",
                                                                zIndex: 1
                                                            },
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Input, {
                                                                placeholder: "T\xecm kiếm",
                                                                prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.SearchOutlined, {}),
                                                                style: {
                                                                    width: "100%"
                                                                },
                                                                onClick: handleInputClick
                                                            })
                                                        })
                                                    ]
                                                }),
                                                className: "admin__layout-dasbroah-navbar-information-notical-icon",
                                                onClick: toggleSearchVisible
                                            },
                                            {
                                                key: "notice",
                                                label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Popover, {
                                                    placement: "bottom",
                                                    content: cartContent,
                                                    className: "",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Badge, {
                                                        count: totalNotice,
                                                        overflowCount: 99,
                                                        style: {
                                                            backgroundColor: "red"
                                                        },
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                                            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.BellOutlined, {
                                                                style: {
                                                                    fontSize: "18px"
                                                                }
                                                            }),
                                                            style: {
                                                                border: "none",
                                                                textDecoration: "underline",
                                                                boxShadow: "none"
                                                            }
                                                        })
                                                    })
                                                }),
                                                className: ""
                                            }
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "admin__layout-dasbroah-navbar-information-user",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    backgroundImage: 'url("/images/admin/usertest.jpg")',
                                                    backgroundSize: "cover",
                                                    backgroundPosition: "center",
                                                    backgroundRepeat: "no-repeat",
                                                    borderRadius: "50%",
                                                    border: "1px solid green"
                                                },
                                                className: "admin__layout-dasbroah-navbar-information-avatar"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Dropdown, {
                                                menu: menuProps,
                                                className: "admin__layout-dasbroah-navbar-information-avatar-logout",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_6__.Space, {
                                                        children: [
                                                            "Xin Ch\xe0o ",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                                children: "AdminStaylor"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.DownOutlined, {})
                                                        ]
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "admin__layout-main",
                        children: [
                            children,
                            loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "admin__layout-main-loading",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_6__.Spin, {
                                    size: "large",
                                    className: "admin__layout-main-loading-icon"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Dashboard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4214:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K4": () => (/* binding */ setLoading),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export loadingSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    loading: false
};
const loadingSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "loading",
    initialState,
    reducers: {
        setLoading: (state, action)=>{
            state.loading = action.payload;
        }
    }
});
const { setLoading  } = loadingSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (loadingSlice.reducer);


/***/ })

};
;