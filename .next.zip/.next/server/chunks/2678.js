"use strict";
exports.id = 2678;
exports.ids = [2678];
exports.modules = {

/***/ 2678:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_Selector_ramda__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3580);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_Selector_ramda__WEBPACK_IMPORTED_MODULE_3__]);
_utils_Selector_ramda__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const HeadSEO = ({ pageSEO , url , image  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: (0,_utils_Selector_ramda__WEBPACK_IMPORTED_MODULE_3__/* .orEmpty */ .Ft)("title", pageSEO)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                charSet: "UTF-8"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "title",
                content: (0,_utils_Selector_ramda__WEBPACK_IMPORTED_MODULE_3__/* .orEmpty */ .Ft)("title", pageSEO)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "keywords",
                content: (0,_utils_Selector_ramda__WEBPACK_IMPORTED_MODULE_3__/* .orEmpty */ .Ft)("keywords", pageSEO)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "description",
                content: (0,_utils_Selector_ramda__WEBPACK_IMPORTED_MODULE_3__/* .orEmpty */ .Ft)("description", pageSEO)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:locale",
                content: "vi_VN"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:type",
                content: "website"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:url",
                content: url
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:title",
                content: (0,_utils_Selector_ramda__WEBPACK_IMPORTED_MODULE_3__/* .orEmpty */ .Ft)("title", pageSEO)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:description",
                content: (0,_utils_Selector_ramda__WEBPACK_IMPORTED_MODULE_3__/* .orEmpty */ .Ft)("description", pageSEO)
            }),
            image && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:image",
                content: image
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "article:modified_time",
                content: "2023-08-28T09:39:44+00:00"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "twitter:card",
                content: "summary_large_image"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "twitter:url",
                content: (0,_utils_Selector_ramda__WEBPACK_IMPORTED_MODULE_3__/* .orEmpty */ .Ft)("url", pageSEO)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "twitter:title",
                content: (0,_utils_Selector_ramda__WEBPACK_IMPORTED_MODULE_3__/* .orEmpty */ .Ft)("title", pageSEO)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "twitter:description",
                content: (0,_utils_Selector_ramda__WEBPACK_IMPORTED_MODULE_3__/* .orEmpty */ .Ft)("description", pageSEO)
            }),
            image && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "twitter:image",
                content: image
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "viewport",
                content: "maximum-scale=1, initial-scale=1,width=device-width, shrink-to-fit=no, user-scalable=no, viewport-fit=cover, maximum-scale=4.0"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                httpEquiv: "Content-Security-Policy",
                content: "frame-src *.google.com *.facebook.com https://thuongthuonghandmade.vn/ https://thuongthuonghandmade.vn http://thuongthuonghandmade.vn http://thuongthuonghandmade.vn/ http://thuongthuong.net http://thuongthuong.net/ *.youtube.com https://www.youtube.com"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "robots",
                content: "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "dlm-version",
                content: "4.8.6"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "canonical",
                href: url
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "alternate",
                href: url,
                hrefLang: "vi-vn"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "dns-prefetch",
                href: "//thuongthuonghandmade.vn"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "generator",
                content: "Nextjs13"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "shortlink",
                href: "https://thuongthuonghandmade.vn/"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeadSEO);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3580:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ft": () => (/* binding */ orEmpty)
/* harmony export */ });
/* unused harmony exports orArray, orNull, orString, orNewDate, orObject, orNumber, orNow, orErrorType, orBoolean, orDefault, orDefaultValue */
/* harmony import */ var ramda__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3991);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([ramda__WEBPACK_IMPORTED_MODULE_0__]);
ramda__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/* Split Path from string to Array */ // xSplit(properties: string): string[]: hàm này nhận vào một chuỗi properties
// và chuyển đổi nó thành một mảng các phần tử bằng cách sử dụng ký tự "." để phân tách.
const xSplit = (properties)=>{
    return properties.split(".");
};
// orArray(properties: string, record: object): any[]:
// hàm này truy cập đến một thuộc tính trong record bằng đường dẫn properties,
// nếu thuộc tính không tồn tại thì trả về một mảng rỗng.
const orArray = (properties, record)=>{
    return R.pathOr([], xSplit(properties))(record);
};
// orNull(properties: string, record: object): any:
// hàm này truy cập đến một thuộc tính trong record bằng đường dẫn properties,
// nếu thuộc tính không tồn tại thì trả về giá trị null.
const orNull = (properties, record)=>{
    return R.pathOr(null, xSplit(properties))(record);
};
// orString(properties: string, record: object): string:
// hàm này truy cập đến một thuộc tính trong record bằng đường dẫn properties,
// nếu thuộc tính không tồn tại thì trả về một chuỗi rỗng.
const orString = (properties, record)=>{
    return R.pathOr("", xSplit(properties))(record);
};
// orNewDate(properties: string, record: object): Date:
// hàm này truy cập đến một thuộc tính trong record bằng đường dẫn properties,
// nếu thuộc tính không tồn tại thì trả về một đối tượng Date mới.
const orNewDate = (properties, record)=>{
    return R.pathOr(new Date(), xSplit(properties))(record);
};
// orObject(prototypes: string, record: object): object:
// hàm này truy cập đến một thuộc tính trong record bằng đường dẫn prototypes,
// nếu thuộc tính không tồn tại thì trả về một đối tượng rỗng.
const orObject = (prototypes, record)=>{
    return R.pathOr({}, xSplit(prototypes))(record);
};
// orNumber(prototypes: string, record: object): number:
// hàm này truy cập đến một thuộc tính trong record bằng đường dẫn prototypes,
// nếu thuộc tính không tồn tại thì trả về giá trị 0.
const orNumber = (prototypes, record)=>{
    return R.pathOr(0, xSplit(prototypes))(record);
};
// orNow(prototypes: string, record: object): Date:
// hàm này truy cập đến một thuộc tính trong record bằng đường dẫn prototypes,
// nếu thuộc tính không tồn tại thì trả về đối tượng Date hiện tại.
const orNow = (prototypes, record)=>{
    return R.pathOr(new Date(), xSplit(prototypes))(record);
};
// orEmpty(properties: string, record: object): string:
// hàm này truy cập đến một thuộc tính trong record bằng đường dẫn properties,
// nếu thuộc tính không tồn tại thì trả về một chuỗi rỗng.
const orEmpty = (properties, record)=>{
    return ramda__WEBPACK_IMPORTED_MODULE_0__.pathOr("", xSplit(properties))(record);
};
// Hàm orErrorType sẽ trả về giá trị chuỗi "error"
// nếu giá trị của thuộc tính được chỉ định không tồn tại hoặc là một giá trị rỗng.
const orErrorType = (properties, record)=>{
    return R.pathOr("error", xSplit(properties))(record);
};
// Hàm orBoolean sẽ trả về giá trị false
// nếu giá trị của thuộc tính được chỉ định không tồn tại hoặc là một giá trị rỗng.
const orBoolean = (properties, record)=>{
    return R.pathOr(false, xSplit(properties))(record);
};
// Hàm orDefault sẽ trả về giá trị mặc định (dv) được chỉ định
// nếu giá trị của thuộc tính được chỉ định không tồn tại hoặc là một giá trị rỗng.
const orDefault = (dv, properties, record)=>{
    const arrPath = xSplit(properties);
    return R.pathOr(dv, arrPath, record);
};
// Hàm orDefaultValue sẽ trả về giá trị đầu vào (value) nếu nó tồn tại và không phải là một giá trị rỗng.
// Nếu không, nó sẽ trả về giá trị mặc định (dv) được chỉ định.
const orDefaultValue = (value, dv)=>{
    return R.or(value, dv);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;