"use strict";
exports.id = 9374;
exports.ids = [9374];
exports.modules = {

/***/ 1712:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4516);
/* harmony import */ var _languages__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8612);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var src_constant_link_master__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9144);







const ListCategory = (props)=>{
    const [t, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_languages_vie_json__WEBPACK_IMPORTED_MODULE_3__);
    const [categories, setCategories] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.language.currentLanguage);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setCategories(props.data);
    }, [
        props
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (0,_languages__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(lang, setText);
    }, [
        lang
    ]);
    const renderCategories = (arr)=>{
        const categoryElement = [];
        arr.forEach((e)=>{
            categoryElement.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "list-products-left-item-ul",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                    href: `${src_constant_link_master__WEBPACK_IMPORTED_MODULE_6__/* .SAN_PHAM */ .fx}${e.link}?language=${lang}`,
                    className: "list-products-left-item-ul-li",
                    children: [
                        e.name,
                        " "
                    ]
                })
            }, e.id));
            if (e.subCategories && e.subCategories.length > 0) {
                const paddingLeft = 0;
                handleSubCate(e.subCategories, categoryElement, paddingLeft);
            }
        });
        return categoryElement;
    };
    const handleSubCate = (arr, collector, paddingLeft)=>{
        const cssPadding = paddingLeft + 30;
        const subElementStyle = {
            paddingLeft: cssPadding // Giá trị padding-left 100px
        };
        arr.forEach((sub)=>{
            if (sub.subCategories && sub.subCategories.length > 0) {
                collector.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "list-products-left-item-li",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                        href: `${src_constant_link_master__WEBPACK_IMPORTED_MODULE_6__/* .SAN_PHAM */ .fx}${sub.link}?language=${lang}`,
                        className: "list-products-left-item-li-sub",
                        children: [
                            sub.name,
                            " "
                        ]
                    })
                }, sub.id));
                handleSubCate(sub.subCategories, collector, cssPadding);
            } else collector.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "list-products-left-item-li",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                    href: `${src_constant_link_master__WEBPACK_IMPORTED_MODULE_6__/* .SAN_PHAM */ .fx}${sub.link}?language=${lang}`,
                    className: "list-products-left-item-sub",
                    children: [
                        sub.name,
                        " "
                    ]
                })
            }, sub.id));
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "list-products-left",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "list-products-left-title",
                children: t.list_products.TITLE
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "list-products-left-wall"
            }),
            categories?.length > 0 ? renderCategories(categories) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: "No categories found."
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ListCategory);


/***/ }),

/***/ 6345:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _languages_vie_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4516);
/* harmony import */ var _components_elements_card__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3249);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var src_constant_constant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6223);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_elements_card__WEBPACK_IMPORTED_MODULE_4__]);
_components_elements_card__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const { Search  } = antd__WEBPACK_IMPORTED_MODULE_5__.Input;
const ListProducts = (props)=>{
    const { products , pagination , title  } = props;
    console.log(pagination, "pagination");
    const [t, setText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_languages_vie_json__WEBPACK_IMPORTED_MODULE_3__);
    const [categoryName, setCategoryName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [categoryId, setCategoryId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    console.log(pagination, "pagination");
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.language.currentLanguage);
    // const getProducts = async (
    //   categoryId: string,
    //   language: string,
    //   page: any,
    //   size: any,
    //   productName?: string
    // ) => {
    //   const res = await productClient.getProductByCategoryId({categoryId, language, page, size, productName});
    //   setProducts(res.data.data.products);
    // }
    const setSearchPlaceHolderNote = ()=>{
        let mesage = "";
        if (categoryId) {
            if (lang.toUpperCase() == "VI") {
                mesage = `Tìm kiếm trong '${categoryName}'`;
            } else {
                mesage = `Search in '${categoryName}'`;
            }
        } else {
            if (lang.toUpperCase() == "VI") {
                mesage = `Tìm kiếm toàn bộ sản phẩm`;
            } else {
                mesage = `Search all products`;
            }
        }
        return mesage;
    };
    // const onChangePagination = async (current: number, pageSize: number) => {
    //   pagination.page = current
    //   pagination.size = pageSize
    //   setPagination(pagination)
    //   getProducts(categoryId, lang, current, pageSize, productName)
    // }
    const handleInputClick = (e)=>{
        e.stopPropagation();
    };
    // const searchProduct = async (value: any) => {
    //   setProductName(value)
    //   getProducts(categoryId, lang, 1, pagination.size, value)
    // };
    // console.log(categoryName, "categoryName");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "list-products-right",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "list-products-right-title",
                children: title ? title : `${t.list_products.TITLE1}`
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "list-products-right-title-sub",
                children: [
                    t.list_products.TITLE2,
                    " ",
                    pagination.totalRecords,
                    " sản phẩm"
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: products?.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "list-products-right-wrap",
                            children: products.map((data, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "list-products-right-wrap-item",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_card__WEBPACK_IMPORTED_MODULE_4__/* .CardProduct */ .QF, {
                                        props: data,
                                        t: t
                                    })
                                }, index))
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_5__.Pagination, {
                            style: {
                                flex: "alignItems"
                            },
                            total: pagination?.totalRecords ? pagination?.totalRecords : 10,
                            defaultCurrent: 1,
                            current: pagination?.page ? pagination?.page : 1,
                            pageSize: pagination?.size ? pagination?.size : 10,
                            pageSizeOptions: src_constant_constant__WEBPACK_IMPORTED_MODULE_6__/* .PAGE_SIZE */ .IV,
                            // showSizeChanger
                            // onChange={onChangePagination}
                            // onShowSizeChange={onChangePagination}
                            className: "list-news-pagination"
                        })
                    ]
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    style: {
                        flex: "alignItems"
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                        src: "/images/noproducts.png",
                        alt: "Thuong thuong handmade",
                        width: 1019,
                        height: 400,
                        className: "list-products-empty"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ListProducts);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9374:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": () => (/* reexport safe */ _ListCategory__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "u": () => (/* reexport safe */ _ListProducts__WEBPACK_IMPORTED_MODULE_1__.Z)
/* harmony export */ });
/* harmony import */ var _ListCategory__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1712);
/* harmony import */ var _ListProducts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6345);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ListProducts__WEBPACK_IMPORTED_MODULE_1__]);
_ListProducts__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6223:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IV": () => (/* binding */ PAGE_SIZE),
/* harmony export */   "rb": () => (/* binding */ bread_crumb)
/* harmony export */ });
/* unused harmony exports home, product, CONTACT_STATUS */
const PAGE_SIZE = [
    "1",
    "2",
    "10",
    "20",
    "50"
];
const bread_crumb = {
    home: {
        VI: "Trang chủ",
        EN: "Home"
    },
    product: {
        VI: "Sản phẩm",
        EN: "Products"
    }
};
const home = {
    VI: "VI",
    EN: "EN"
};
const product = {
    VI: "Sản phẩm",
    EN: "Products"
};
const CONTACT_STATUS = {
    CHUA_XU_LY: "Chưa xử l\xfd",
    DA_XU_LY: "Đ\xe3 xử l\xfd"
};


/***/ })

};
;