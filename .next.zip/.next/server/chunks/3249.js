"use strict";
exports.id = 3249;
exports.ids = [3249];
exports.modules = {

/***/ 8208:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);




const { Meta  } = antd__WEBPACK_IMPORTED_MODULE_1__.Card;
const CustomCard = ({ title , description , imageSrc  })=>{
    const datetime = "Thứ s\xe1u, ng\xe0y 27/02/2023";
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: /*#__PURE__*/ _jsxs(Card, {
            hoverable: true,
            className: "home__event-wrap-card",
            cover: /*#__PURE__*/ _jsx(Image, {
                alt: title,
                src: imageSrc,
                width: 300,
                height: 300
            }),
            bordered: false,
            children: [
                /*#__PURE__*/ _jsx(Meta, {
                    title: title,
                    description: description
                }),
                /*#__PURE__*/ _jsxs("div", {
                    className: "home__event-wrap-card-time",
                    children: [
                        /*#__PURE__*/ _jsx(ClockCircleOutlined, {}),
                        /*#__PURE__*/ _jsx("span", {
                            style: {
                                marginLeft: 8
                            },
                            children: datetime
                        })
                    ]
                })
            ]
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (CustomCard)));


/***/ }),

/***/ 5054:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);




const CustomCard = ({ title , description , imageSrc  })=>{
    const datetime = "Thứ s\xe1u, ng\xe0y 27/02/2023";
    return /*#__PURE__*/ _jsx(Card, {
        bordered: false,
        children: /*#__PURE__*/ _jsxs("div", {
            style: {
                display: "flex"
            },
            className: "home__event-list-card",
            children: [
                /*#__PURE__*/ _jsx("div", {
                    className: "home__event-list-card-img",
                    children: /*#__PURE__*/ _jsx(Image, {
                        alt: title,
                        src: imageSrc,
                        width: 120,
                        height: 120,
                        loading: "lazy"
                    })
                }),
                /*#__PURE__*/ _jsxs("div", {
                    className: "home__event-list-card-infor",
                    children: [
                        /*#__PURE__*/ _jsx("h3", {
                            className: "home__event-list-card-infor-title",
                            children: title
                        }),
                        /*#__PURE__*/ _jsx("p", {
                            className: "home__event-list-card-infor-description",
                            children: description
                        }),
                        /*#__PURE__*/ _jsxs("div", {
                            className: "home__event-list-card-infor-time",
                            children: [
                                /*#__PURE__*/ _jsx(ClockCircleOutlined, {}),
                                /*#__PURE__*/ _jsx("span", {
                                    style: {
                                        marginLeft: 8
                                    },
                                    children: datetime
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (CustomCard)));


/***/ }),

/***/ 4698:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);





const { Meta  } = antd__WEBPACK_IMPORTED_MODULE_1__.Card;
const CardPageNews = ({ title , description , imageSrc , link , time  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
        href: "/tin-tuc/" + link,
        passHref: true,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_1__.Card, {
            hoverable: true,
            className: "list-news-item-card",
            cover: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                alt: title,
                src: imageSrc,
                width: 300,
                height: 300,
                className: "list-news-item-card-img"
            }),
            bordered: false,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Meta, {
                    title: title,
                    description: description
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "list-news-item-card-time",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__.ClockCircleOutlined, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            style: {
                                marginLeft: 8
                            },
                            children: time
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CardPageNews);


/***/ }),

/***/ 6155:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_molecules_Modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2857);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _slices_cartSlice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(633);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var src_constant_link_master__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9144);
/* harmony import */ var _service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2065);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_service__WEBPACK_IMPORTED_MODULE_9__]);
_service__WEBPACK_IMPORTED_MODULE_9__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






// sử dụng redux






const CardProduct = ({ props , t  })=>{
    const { id , title , imageUrl , name , link , price  } = props;
    const [dataDetailProduct, setDataDetailProduct] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const imageUrlProduct = `${"https://api.thuongthuonghandmade.vn"}/${imageUrl}`;
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.language.currentLanguage);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useDispatch)();
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [confirmLoading, setConfirmLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [modalText, setModalText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Content of the modal");
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const showModal = ()=>{
        // thực hiện việc lấy dữ liệu chi tiết sản phẩm
        if (id) {
            _service__WEBPACK_IMPORTED_MODULE_9__/* .handleProductsClient.getDetailProductsID */ .oO.getDetailProductsID(id, "VI").then((result)=>{
                if (result.meta.status === 200) {
                    setDataDetailProduct(result.data);
                }
            }).catch((error)=>{
                // Xử lý lỗi ở đây
                console.log(error);
            });
            setOpen(true);
        }
    };
    const handleOk = ()=>{
        setModalText("The modal will be closed after two seconds");
        setConfirmLoading(true);
        setTimeout(()=>{
            setOpen(false);
            setConfirmLoading(false);
        }, 2000);
    };
    const handleCancel = ()=>{
        console.log("Clicked cancel button");
        setOpen(false);
    };
    const handleCardClick = ()=>{
        console.log("card", props);
        router.push(`${src_constant_link_master__WEBPACK_IMPORTED_MODULE_10__/* .CHI_TIET_SAN_PHAM */ .ZT}${link}?language=${lang}`);
    };
    const addItemHandler = ()=>{
        const item = {
            id: id,
            imageUrl: imageUrl,
            title: title,
            name: name,
            price: price,
            quantity: 1,
            selected: false
        };
        dispatch(_slices_cartSlice__WEBPACK_IMPORTED_MODULE_7__/* .cartActions.addItemToCart */ .Uw.addItemToCart(item));
    };
    const buyItemHandler = ()=>{
        const item = {
            id: id,
            imageUrl: imageUrl,
            title: title,
            name: name,
            price: price,
            quantity: 1,
            selected: true
        };
        dispatch(_slices_cartSlice__WEBPACK_IMPORTED_MODULE_7__/* .cartActions.addItemToCart */ .Uw.addItemToCart(item));
        router.push("/gio-hang");
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "products__card-wrap",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.SearchOutlined, {
                onClick: showModal,
                className: "products__card-modal"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "products__card-group",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "products__card-group-btn",
                        onClick: buyItemHandler,
                        children: t.button.BUTTON4
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "products__card-group-btn",
                        onClick: addItemHandler,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "products__card-group-btn-text",
                                children: "+"
                            }),
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_4__.ShoppingCartOutlined, {
                                className: "products__card-group-btn-icon"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Card, {
                hoverable: true,
                className: "products__card",
                cover: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                    src: imageUrl ? imageUrlProduct : src_constant_link_master__WEBPACK_IMPORTED_MODULE_10__/* .EMPTY_IMAGE */ .AU,
                    alt: "example",
                    className: "products__card-img",
                    width: 300,
                    height: 300
                }),
                onClick: handleCardClick,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "products__card-data",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "products__card-title",
                            children: title
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "products__card-price",
                            children: !price ? `${t.products.PRICE}` : `${price} ₫`
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Modal, {
                open: open,
                onOk: handleOk,
                confirmLoading: confirmLoading,
                onCancel: handleCancel,
                className: "products__card-dialog",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_molecules_Modal__WEBPACK_IMPORTED_MODULE_5__/* .ProductsModal */ .w, {
                    props: props,
                    dataDetailProduct: dataDetailProduct
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CardProduct);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8205:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);




const CardStatisticalAdmin = (props)=>{
    const { header , total , image , infor1 , infor2 , footer , number  } = props;
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: /*#__PURE__*/ _jsxs("div", {
            className: "admin__main-card-item",
            children: [
                /*#__PURE__*/ _jsxs("div", {
                    className: "admin__main-card-item-header",
                    children: [
                        /*#__PURE__*/ _jsx("span", {
                            className: "admin__main-card-item-header-title",
                            children: header
                        }),
                        /*#__PURE__*/ _jsx(ExclamationCircleOutlined, {
                            className: "admin__main-card-item-header-icon"
                        })
                    ]
                }),
                /*#__PURE__*/ _jsxs("div", {
                    className: "admin__main-card-item-main",
                    children: [
                        /*#__PURE__*/ _jsxs("div", {
                            className: "admin__main-card-item-main-wrap",
                            children: [
                                /*#__PURE__*/ _jsx(Image, {
                                    src: image,
                                    width: 80,
                                    height: 80,
                                    alt: "thuongthuong",
                                    className: "admin__main-card-item-main-img"
                                }),
                                /*#__PURE__*/ _jsx("span", {
                                    className: "admin__main-card-item-main-title",
                                    children: total
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsxs("div", {
                            className: "admin__main-card-item-main-infor",
                            children: [
                                /*#__PURE__*/ _jsxs("div", {
                                    className: "admin__main-card-item-main-infor-item",
                                    children: [
                                        /*#__PURE__*/ _jsx("span", {
                                            className: "admin__main-card-item-main-infor-item-title",
                                            children: "Tuần Trước"
                                        }),
                                        /*#__PURE__*/ _jsx(CaretUpOutlined, {
                                            className: Number(infor1) > 0 ? "admin__main-card-item-main-infor-item-icon-up" : "admin__main-card-item-main-infor-item-icon-down"
                                        }),
                                        /*#__PURE__*/ _jsxs("span", {
                                            className: Number(infor1) > 0 ? "admin__main-card-item-main-infor-item-number-up" : "admin__main-card-item-main-infor-item-number-down",
                                            children: [
                                                infor1,
                                                "%"
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ _jsxs("div", {
                                    className: "admin__main-card-item-main-infor-item",
                                    children: [
                                        /*#__PURE__*/ _jsx("span", {
                                            className: "admin__main-card-item-main-infor-item-title",
                                            children: "Th\xe1ng Trước"
                                        }),
                                        /*#__PURE__*/ _jsx(CaretDownOutlined, {
                                            className: Number(infor2) > 0 ? "admin__main-card-item-main-infor-item-icon-up" : "admin__main-card-item-main-infor-item-icon-down"
                                        }),
                                        /*#__PURE__*/ _jsxs("span", {
                                            className: Number(infor2) > 0 ? "admin__main-card-item-main-infor-item-number-up" : "admin__main-card-item-main-infor-item-number-down",
                                            children: [
                                                infor2,
                                                "%"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ _jsxs("div", {
                    className: "admin__main-card-item-footer",
                    children: [
                        footer,
                        ": ",
                        /*#__PURE__*/ _jsx("strong", {
                            children: number
                        })
                    ]
                })
            ]
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (CardStatisticalAdmin)));


/***/ }),

/***/ 3249:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "KQ": () => (/* reexport safe */ _CardPageNews__WEBPACK_IMPORTED_MODULE_3__.Z),
/* harmony export */   "QF": () => (/* reexport safe */ _CardProduct__WEBPACK_IMPORTED_MODULE_0__.Z)
/* harmony export */ });
/* harmony import */ var _CardProduct__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6155);
/* harmony import */ var _CardNewsHome__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8208);
/* harmony import */ var _CardNewsList__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5054);
/* harmony import */ var _CardPageNews__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4698);
/* harmony import */ var _CardStatisticalAdmin__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8205);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CardProduct__WEBPACK_IMPORTED_MODULE_0__]);
_CardProduct__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// dùng trong admin


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "w": () => (/* reexport */ Modal_ProductsModal)
});

// UNUSED EXPORTS: ModalCarts

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./store/slices/cartSlice.ts
var cartSlice = __webpack_require__(633);
// EXTERNAL MODULE: ./src/languages/vie.json
var vie = __webpack_require__(4516);
// EXTERNAL MODULE: ./src/languages/index.ts
var languages = __webpack_require__(8612);
;// CONCATENATED MODULE: ./src/components/molecules/Modal/ProductsModal.tsx








const ProductsModal = ({ props , dataDetailProduct  })=>{
    const { id , title , imageUrl , name , link , price  } = props;
    const imageUrlProduct = `${"https://api.thuongthuonghandmade.vn"}/${imageUrl}`;
    const [t, setText] = (0,external_react_.useState)(vie);
    const lang = (0,external_react_redux_.useSelector)((state)=>state.language.currentLanguage);
    (0,external_react_.useEffect)(()=>{
        (0,languages/* default */.Z)(lang, setText);
    }, [
        lang
    ]);
    const [value, setValue] = (0,external_react_.useState)(1);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const handleOnChange = (newValue)=>{
        if (newValue === null) {
            setValue(1);
        } else {
            setValue(newValue);
        }
    };
    const [expanded, setExpanded] = (0,external_react_.useState)(true);
    const toggleExpanded = ()=>{
        setExpanded(!expanded);
    };
    const handleAddItem = ()=>{
        const item = {
            id: id,
            imageUrl: imageUrlProduct,
            title: title,
            price: price,
            quantity: 1,
            selected: false
        };
        dispatch(cartSlice/* cartActions.addItemToCart */.Uw.addItemToCart(item));
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "products__card-dialog--wrap",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: imageUrl ? imageUrlProduct : "",
                alt: "example",
                className: "products__card-dialog--wrap-image",
                width: 300,
                height: 300
            }),
            dataDetailProduct ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "products__card-dialog--wrap-information",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "products__card-dialog--wrap-information-title",
                        children: dataDetailProduct.name
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "products__card-dialog--wrap-information-category",
                        children: [
                            dataDetailProduct.danhMuc1.name,
                            "  ",
                            dataDetailProduct.danhMuc2.name
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "products__card-dialog--wrap-information-price",
                        children: !price ? `${t.products.PRICE}` : price
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "products__card-dialog--wrap-information-description",
                        children: expanded ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "products__card-dialog--wrap-information-description-hide",
                                    children: dataDetailProduct.description
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "products__card-dialog--wrap-information-description-button",
                                    onClick: toggleExpanded,
                                    children: t.button.BUTTON1
                                })
                            ]
                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "products__card-dialog--wrap-information-description-show",
                                    children: dataDetailProduct.description
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "products__card-dialog--wrap-information-description-button",
                                    onClick: toggleExpanded,
                                    children: t.button.BUTTON2
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "products__card-dialog--wrap-information-sub",
                        children: t.products.SUB
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        style: {
                            display: "flex",
                            alignItems: "center"
                        },
                        className: "products__card-dialog--wrap-information-inputnumber",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Button, {
                                onClick: ()=>handleOnChange(value - 1),
                                className: "products__card-dialog--wrap-information-inputnumber-btn",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "products__card-dialog--wrap-information-inputnumber-btn-icon",
                                    children: "-"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.InputNumber, {
                                defaultValue: 1,
                                min: 1,
                                max: 100,
                                value: value,
                                onChange: handleOnChange,
                                className: "products__card-dialog--wrap-information-inputnumber-main",
                                style: {
                                    margin: "0 0.2em"
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Button, {
                                onClick: ()=>handleOnChange(value + 1),
                                className: "products__card-dialog--wrap-information-inputnumber-btn",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "products__card-dialog--wrap-information-inputnumber-btn-icon",
                                    children: "+"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "products-detail-group",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Button, {
                                type: "primary",
                                style: {
                                    marginLeft: 0
                                },
                                onClick: handleAddItem,
                                className: "products__card-dialog--wrap-information-btn",
                                children: t.button.BUTTON4
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Button, {
                                type: "primary",
                                style: {
                                    marginLeft: 16
                                },
                                onClick: handleAddItem,
                                className: "products__card-dialog--wrap-information-btn",
                                children: t.button.BUTTON5
                            })
                        ]
                    })
                ]
            }) : /*#__PURE__*/ jsx_runtime_.jsx(external_antd_.Spin, {})
        ]
    });
};
/* harmony default export */ const Modal_ProductsModal = (ProductsModal);

;// CONCATENATED MODULE: ./src/components/molecules/Modal/ModalCarts.tsx



const ModalCarts = ()=>{
    return /*#__PURE__*/ _jsxs("div", {
        className: "modal-cart",
        children: [
            /*#__PURE__*/ _jsx(Image, {
                src: "/icon/succeed.png",
                width: 100,
                height: 100,
                alt: "Thương Thương",
                className: "modal-cart-img"
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "modal-cart-text",
                children: "Sản phẩm đ\xe3 được th\xeam v\xe0o giỏ h\xe0ng"
            })
        ]
    });
};
/* harmony default export */ const Modal_ModalCarts = ((/* unused pure expression or super */ null && (ModalCarts)));

;// CONCATENATED MODULE: ./src/components/molecules/Modal/index.ts




/***/ }),

/***/ 9144:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AU": () => (/* binding */ EMPTY_IMAGE),
/* harmony export */   "T0": () => (/* binding */ TIN_TUC),
/* harmony export */   "ZT": () => (/* binding */ CHI_TIET_SAN_PHAM),
/* harmony export */   "fx": () => (/* binding */ SAN_PHAM)
/* harmony export */ });
const EMPTY_IMAGE = "/uploads/empty.jpg";
const SAN_PHAM = "/san-pham";
const TIN_TUC = "/tin-tuc";
const CHI_TIET_SAN_PHAM = "/chi-tiet-san-pham";


/***/ })

};
;