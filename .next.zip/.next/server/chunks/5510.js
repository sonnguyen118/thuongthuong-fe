"use strict";
exports.id = 5510;
exports.ids = [5510];
exports.modules = {

/***/ 5510:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ TextEditor)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ckeditor_ckeditor5_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(384);
/* harmony import */ var _ckeditor_ckeditor5_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ckeditor_ckeditor5_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ckeditor5_custom_build_build_ckeditor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4082);
/* harmony import */ var ckeditor5_custom_build_build_ckeditor__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(ckeditor5_custom_build_build_ckeditor__WEBPACK_IMPORTED_MODULE_2__);



const API_URL = "http://localhost:3001";
const UPLOAD_ENDPOINT = "product/admin/upload";
function TextEditor({ handleChange , ...props }) {
    function uploadAdapter(loader) {
        return {
            upload: ()=>{
                return new Promise((resolve, reject)=>{
                    console.log("before body");
                    const body = new FormData();
                    loader.file.then((file)=>{
                        body.append("upload", file);
                        // let headers = new Headers();
                        // headers.append("Origin", "http://localhost:3000");
                        fetch(`${API_URL}/${UPLOAD_ENDPOINT}`, {
                            method: "post",
                            body: body
                        }).then((res)=>{
                            return res.json();
                        }).then((res)=>{
                            resolve({
                                default: `${API_URL}/${res.path}`
                            });
                        }).catch((err)=>{
                            console.log(err);
                            reject(err);
                        });
                    });
                });
            }
        };
    }
    function uploadPlugin(editor) {
        editor.plugins.get("FileRepository").createUploadAdapter = (loader)=>{
            return uploadAdapter(loader);
        };
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ckeditor_ckeditor5_react__WEBPACK_IMPORTED_MODULE_1__.CKEditor, {
            config: {
                extraPlugins: [
                    uploadPlugin
                ]
            },
            editor: (ckeditor5_custom_build_build_ckeditor__WEBPACK_IMPORTED_MODULE_2___default()),
            onReady: (editor)=>{},
            onBlur: (event, editor)=>{},
            onFocus: (event, editor)=>{},
            onChange: (event, editor)=>{
                console.log(editor.getData());
                handleChange(editor.getData());
            },
            ...props
        })
    });
}


/***/ })

};
;