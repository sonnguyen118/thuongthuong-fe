"use strict";
exports.id = 2065;
exports.ids = [2065];
exports.modules = {

/***/ 9043:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X_": () => (/* binding */ axiosInstanceAuthorizationUpload),
/* harmony export */   "ke": () => (/* binding */ axiosInstanceClient),
/* harmony export */   "sM": () => (/* binding */ axiosInstanceAuthorization)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _utils_Functions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9343);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__, _utils_Functions__WEBPACK_IMPORTED_MODULE_1__]);
([axios__WEBPACK_IMPORTED_MODULE_0__, _utils_Functions__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

 // Tạo một file Cookie.ts để chứa hàm getAccessTokenFromCookie()
// Tạo một instance mới của Axios với cấu hình interceptor
const axiosInstanceAuthorization = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create();
// Thêm interceptor trước mỗi request được gửi đi
axiosInstanceAuthorization.interceptors.request.use((config)=>{
    const token = _utils_Functions__WEBPACK_IMPORTED_MODULE_1__/* .Cookie.getAccessTokenFromCookie */ .Vj.getAccessTokenFromCookie();
    config.headers["Content-Type"] = "application/json"; // Sửa thành "Content-Type" (không có dấu ngoặc kép bên trong)
    config.headers["Authorization"] = `Bearer ${token}`;
    return config;
}, (error)=>{
    return Promise.reject(error);
});
const axiosInstanceAuthorizationUpload = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create();
axiosInstanceAuthorizationUpload.interceptors.request.use((config)=>{
    const token = _utils_Functions__WEBPACK_IMPORTED_MODULE_1__/* .Cookie.getAccessTokenFromCookie */ .Vj.getAccessTokenFromCookie();
    config.headers["Content-Type"] = "multipart/form-data";
    config.headers["Authorization"] = `Bearer ${token}`;
    return config;
}, (error)=>{
    return Promise.reject(error);
});
// Tạo một instance mới của Axios không có cấu hình interceptor
// Tạo một instance mới của Axios với cấu hình interceptor
const axiosInstanceClient = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create();
// Thêm interceptor trước mỗi request được gửi đi
axiosInstanceClient.interceptors.request.use((config)=>{
    config.headers["Content-type"] = "application/json";
    return config;
});


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7093:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9043);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__]);
_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const adminGetArticle = (params)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/article/admin/get-by-menu", params);
};
const adminGetArticleDetail = (id, link)=>{
    const end_point = "https://api.thuongthuonghandmade.vn" + `/article/admin/get-detail?id=${id}`;
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.get */ .sM.get(end_point);
};
const createArticle = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/article/create", body);
};
const updateStatusArticle = (dto)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/article/update-status", dto);
};
const updateArticle = (dto)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/article/update", dto);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    adminGetArticle,
    createArticle,
    updateStatusArticle,
    updateArticle,
    adminGetArticleDetail
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2088:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9043);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__]);
_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const createCategory = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/category/create", body);
};
const getAllCategory = ()=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.get */ .sM.get("https://api.thuongthuonghandmade.vn" + "/category/admin-get-all");
};
const updateStatusCategory = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/category/update-status", body);
};
const getOne = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/category/get-one", body);
};
const update = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/category/update", body);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    createCategory,
    getAllCategory,
    updateStatusCategory,
    getOne,
    update
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9434:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9043);
/* harmony import */ var _utils_Functions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9343);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__, _utils_Functions__WEBPACK_IMPORTED_MODULE_1__]);
([_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__, _utils_Functions__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const API_URL = "http://localhost:3001";
const UPLOAD_ENDPOINT = "product/admin/upload";
const ckeditorUploadImages = (file)=>{
    const body = new FormData();
    const fileName = Date.now() + "-" + _utils_Functions__WEBPACK_IMPORTED_MODULE_1__/* .Diacritic.convertValueWithDashes */ .mz.convertValueWithDashes(file.name);
    console.log("1");
    body.append("upload", file);
    const options = {
        headers: {
            "Content-Type": "multipart/form-data"
        }
    };
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceClient.post */ .ke.post("https://api.thuongthuonghandmade.vn" + "/product/admin/upload ", body, options);
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({
    ckeditorUploadImages
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3746:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9043);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__]);
_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getContact = (dto)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/contact/find", dto);
};
const getDetailContact = (id)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.get */ .sM.get("https://api.thuongthuonghandmade.vn" + "/contact/" + id);
};
const updateContact = (dto)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/contact/update", dto);
};
const getList = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/contact/list", body);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    getContact,
    updateContact,
    getList,
    getDetailContact
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1205:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9043);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__]);
_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const loginAuthorize = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceClient.post */ .ke.post("https://api.thuongthuonghandmade.vn" + "/auth/login", body);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    loginAuthorize
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 257:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9043);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__]);
_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const adminGetAllMenu = ()=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.get */ .sM.get("https://api.thuongthuonghandmade.vn" + "/menu/admin-get-all");
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    adminGetAllMenu
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8141:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9043);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__]);
_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getOrder = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/order", body);
};
const changeStatus = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/order/update-status", body);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    getOrder,
    changeStatus
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9181:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9043);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__]);
_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const createProducts = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/product/admin/create", body);
};
const uploadImagesProduct = (formData)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorizationUpload.post */ .X_.post("https://api.thuongthuonghandmade.vn" + "/product/admin/upload", formData);
};
const getAllProducts = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/product/admin/get-products", body);
};
const getDataOne = (id)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.get */ .sM.get("https://api.thuongthuonghandmade.vn" + `/product/admin/get-detail?productId=${id}`);
};
const updateStatus = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + `/product/admin/update-status`, body);
};
const updateProducts = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + `/product/admin/update`, body);
};
const getHighlight = ()=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.get */ .sM.get("https://api.thuongthuonghandmade.vn" + `/product/get-all?language=VI&isHighlight=true`);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    createProducts,
    updateProducts,
    uploadImagesProduct,
    getAllProducts,
    getDataOne,
    updateStatus,
    getHighlight
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3625:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9043);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__]);
_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const createWebInformation = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/web-information", body);
};
const updateWebInformation = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.patch */ .sM.patch("https://api.thuongthuonghandmade.vn" + "/web-information", body);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    createWebInformation,
    updateWebInformation
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9090:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9043);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__]);
_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getArticleClient = (language, page, size, name, categoryId, categoryLink)=>{
    const params = {
        language,
        page,
        size,
        name,
        categoryId,
        categoryLink
    };
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceClient.post */ .ke.post(`${"https://api.thuongthuonghandmade.vn"}/article/get-by-menu`, params);
};
const getArticleDetail = (language, link)=>{
    const params = {
        language,
        link: `${link}`
    };
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceClient.get */ .ke.get(`${"https://api.thuongthuonghandmade.vn"}/article`, {
        params
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    getArticleClient,
    getArticleDetail
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4539:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9043);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__]);
_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getAllCategoryClient = (language, page, size)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceClient.get */ .ke.get(`${"https://api.thuongthuonghandmade.vn"}/category?language=${language}&page=${page}&size=${size}`);
};
const getAllFullCategoryClient = (language)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceClient.get */ .ke.get(`${"https://api.thuongthuonghandmade.vn"}/category?language=${language}`);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    getAllCategoryClient,
    getAllFullCategoryClient
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4686:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9043);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__]);
_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const placeOrder = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceAuthorization.post */ .sM.post("https://api.thuongthuonghandmade.vn" + "/order/create", body);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    placeOrder
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2200:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9043);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__]);
_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getAllProductClient = (language, page, size)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceClient.get */ .ke.get(`${"https://api.thuongthuonghandmade.vn"}/product/get-all?language=${language}&page=${page}&size=${size}`);
};
const searchProductClient = (language, page, size, categoryId, name)=>{
    const params = {
        language,
        page,
        size,
        categoryId,
        name
    };
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceClient.get */ .ke.get(`${"https://api.thuongthuonghandmade.vn"}/product/get-all`, {
        params
    });
};
const getProductByCategoryLink = (categoryLink, language, page, size)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceClient.post */ .ke.post(`${"https://api.thuongthuonghandmade.vn"}/product`, {
        categoryLink,
        language,
        page,
        size
    });
};
const getProductByCategoryId = (body)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceClient.post */ .ke.post(`${"https://api.thuongthuonghandmade.vn"}/product`, body);
};
const getDetailProduct = (productLink, language)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceClient.get */ .ke.get(`${"https://api.thuongthuonghandmade.vn"}/product/detail?productLink=${productLink}&language=${language}`);
};
const getDetailProductID = (productId, language)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceClient.get */ .ke.get(`${"https://api.thuongthuonghandmade.vn"}/product/detail?productId=${productId}&language=${language}`);
};
const getHighlight = ()=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceClient.get */ .ke.get("https://api.thuongthuonghandmade.vn" + `/product/get-all?language=VI&isHighlight=true`);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    getAllProductClient,
    getProductByCategoryLink,
    getProductByCategoryId,
    getDetailProduct,
    searchProductClient,
    getHighlight,
    getDetailProductID
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2079:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9043);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__]);
_api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getWebInformation = (params)=>{
    return _api_AxiosInterceptor__WEBPACK_IMPORTED_MODULE_0__/* .axiosInstanceClient.get */ .ke.get("https://api.thuongthuonghandmade.vn" + `/web-information/${params}`);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    getWebInformation
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7631:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "KM": () => (/* reexport safe */ _client_orders__WEBPACK_IMPORTED_MODULE_13__.Z),
/* harmony export */   "Mn": () => (/* reexport safe */ _client_product__WEBPACK_IMPORTED_MODULE_10__.Z),
/* harmony export */   "QI": () => (/* reexport safe */ _admin_products__WEBPACK_IMPORTED_MODULE_2__.Z),
/* harmony export */   "Tl": () => (/* reexport safe */ _client_webinformation__WEBPACK_IMPORTED_MODULE_12__.Z),
/* harmony export */   "WD": () => (/* reexport safe */ _admin_category__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "XY": () => (/* reexport safe */ _client_category__WEBPACK_IMPORTED_MODULE_9__.Z),
/* harmony export */   "_t": () => (/* reexport safe */ _client_article__WEBPACK_IMPORTED_MODULE_11__.Z),
/* harmony export */   "iT": () => (/* reexport safe */ _admin_webinformation__WEBPACK_IMPORTED_MODULE_4__.Z),
/* harmony export */   "m3": () => (/* reexport safe */ _admin_login__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "yW": () => (/* reexport safe */ _admin_articles__WEBPACK_IMPORTED_MODULE_6__.Z),
/* harmony export */   "zC": () => (/* reexport safe */ _admin_menu__WEBPACK_IMPORTED_MODULE_5__.Z),
/* harmony export */   "zI": () => (/* reexport safe */ _admin_orders__WEBPACK_IMPORTED_MODULE_8__.Z),
/* harmony export */   "zq": () => (/* reexport safe */ _admin_contact__WEBPACK_IMPORTED_MODULE_7__.Z)
/* harmony export */ });
/* harmony import */ var _admin_login__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1205);
/* harmony import */ var _admin_category__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2088);
/* harmony import */ var _admin_products__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9181);
/* harmony import */ var _admin_ckeditor_phe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9434);
/* harmony import */ var _admin_webinformation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3625);
/* harmony import */ var _admin_menu__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(257);
/* harmony import */ var _admin_articles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7093);
/* harmony import */ var _admin_contact__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3746);
/* harmony import */ var _admin_orders__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8141);
/* harmony import */ var _client_category__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4539);
/* harmony import */ var _client_product__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2200);
/* harmony import */ var _client_article__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9090);
/* harmony import */ var _client_webinformation__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2079);
/* harmony import */ var _client_orders__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4686);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_admin_login__WEBPACK_IMPORTED_MODULE_0__, _admin_category__WEBPACK_IMPORTED_MODULE_1__, _admin_products__WEBPACK_IMPORTED_MODULE_2__, _admin_ckeditor_phe__WEBPACK_IMPORTED_MODULE_3__, _admin_webinformation__WEBPACK_IMPORTED_MODULE_4__, _admin_menu__WEBPACK_IMPORTED_MODULE_5__, _admin_articles__WEBPACK_IMPORTED_MODULE_6__, _admin_contact__WEBPACK_IMPORTED_MODULE_7__, _admin_orders__WEBPACK_IMPORTED_MODULE_8__, _client_category__WEBPACK_IMPORTED_MODULE_9__, _client_product__WEBPACK_IMPORTED_MODULE_10__, _client_article__WEBPACK_IMPORTED_MODULE_11__, _client_webinformation__WEBPACK_IMPORTED_MODULE_12__, _client_orders__WEBPACK_IMPORTED_MODULE_13__]);
([_admin_login__WEBPACK_IMPORTED_MODULE_0__, _admin_category__WEBPACK_IMPORTED_MODULE_1__, _admin_products__WEBPACK_IMPORTED_MODULE_2__, _admin_ckeditor_phe__WEBPACK_IMPORTED_MODULE_3__, _admin_webinformation__WEBPACK_IMPORTED_MODULE_4__, _admin_menu__WEBPACK_IMPORTED_MODULE_5__, _admin_articles__WEBPACK_IMPORTED_MODULE_6__, _admin_contact__WEBPACK_IMPORTED_MODULE_7__, _admin_orders__WEBPACK_IMPORTED_MODULE_8__, _client_category__WEBPACK_IMPORTED_MODULE_9__, _client_product__WEBPACK_IMPORTED_MODULE_10__, _client_article__WEBPACK_IMPORTED_MODULE_11__, _client_webinformation__WEBPACK_IMPORTED_MODULE_12__, _client_orders__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// Với admin sử dụng các api này










// Với phía client sử dụng các api này






__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4219:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7631);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const handleCreateCategory = async (body)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .Category.createCategory */ .WD.createCategory(body);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
const handleGetAllCategory = async ()=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .Category.getAllCategory */ .WD.getAllCategory();
        const { data , meta  } = response.data;
        console.log(response, "response");
        if (meta.status === 200) {
            return data;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
const handleUpdateStatus = async (body)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .Category.updateStatusCategory */ .WD.updateStatusCategory(body);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            return data;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
const handleGetOne = async (body)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .Category.getOne */ .WD.getOne(body);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            return data;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
const handleUpdate = async (body)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .Category.update */ .WD.update(body);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            return data;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    handleGetAllCategory,
    handleCreateCategory,
    handleUpdateStatus,
    handleGetOne,
    handleUpdate
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7783:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_Functions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9343);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_Functions__WEBPACK_IMPORTED_MODULE_0__]);
_utils_Functions__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const API_URL = "https://api.thuongthuonghandmade.vn";
const UPLOAD_ENDPOINT = "product/admin/upload";
const uploadAdapter = (loader)=>{
    return {
        upload: ()=>{
            return new Promise((resolve, reject)=>{
                loader.file.then((file)=>{
                    const body = new FormData();
                    console.log("test file");
                    console.log(file);
                    const fileName = Date.now() + "-" + _utils_Functions__WEBPACK_IMPORTED_MODULE_0__/* .Diacritic.convertValueWithDashes */ .mz.convertValueWithDashes(file.name);
                    console.log(fileName);
                    body.append("upload", file);
                    // let headers = new Headers();
                    // headers.append("Origin", "http://localhost:3000");
                    fetch(`${API_URL}/${UPLOAD_ENDPOINT}`, {
                        method: "post",
                        body: body
                    }).then((res)=>{
                        return res.json();
                    }).then((res)=>{
                        resolve({
                            default: `${API_URL}/${res.path}`
                        });
                    }).catch((err)=>{
                        console.log(err);
                        reject(err);
                    });
                });
            });
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    uploadAdapter
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6670:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7631);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const handleGetList = async (body)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .ContactAdmin.getList */ .zq.getList(body);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
const handleGetDetail = async (id)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .ContactAdmin.getDetailContact */ .zq.getDetailContact(id);
        const data = response.data;
        if (data) {
            const resData = data;
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${data}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
const handleUpdateStatus = async (body)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .ContactAdmin.updateContact */ .zq.updateContact(body);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    handleGetList,
    handleGetDetail,
    handleUpdateStatus
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5113:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7631);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const handleLogin = async (body)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .Login.loginAuthorize */ .m3.loginAuthorize(body);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    handleLogin
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5316:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7631);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const handleGetOrder = async (body)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .OrderAdmin.getOrder */ .zI.getOrder(body);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
const handleChangeStatus = async (body)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .OrderAdmin.changeStatus */ .zI.changeStatus(body);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    handleGetOrder,
    handleChangeStatus
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2684:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7631);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const handleCreateProducts = async (body)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .Products.createProducts */ .QI.createProducts(body);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
const handleUpdateProducts = async (body)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .Products.updateProducts */ .QI.updateProducts(body);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
const handleUpdateStatus = async (body)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .Products.updateStatus */ .QI.updateStatus(body);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
const handleUploadImageProducts = async (file)=>{
    const formData = new FormData();
    formData.append("upload", file);
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .Products.uploadImagesProduct */ .QI.uploadImagesProduct(formData);
        if (response) {
            return response;
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
const handleGetAllProducts = async (body)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .Products.getAllProducts */ .QI.getAllProducts(body);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
const handleGetOne = async (id)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .Products.getDataOne */ .QI.getDataOne(id);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
const handleGetHighlight = async ()=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .Products.getHighlight */ .QI.getHighlight();
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    handleCreateProducts,
    handleUpdateProducts,
    handleUploadImageProducts,
    handleGetAllProducts,
    handleGetOne,
    handleUpdateStatus,
    handleGetHighlight
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3074:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7631);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const handleCreateWebInformation = async (body)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .WebInformation.createWebInformation */ .iT.createWebInformation(body);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
const handleUpdateWebInformation = async (body)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .WebInformation.updateWebInformation */ .iT.updateWebInformation(body);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    handleCreateWebInformation,
    handleUpdateWebInformation
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9077:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7631);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const handleGetAllCategory = async (language)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .categoryClient.getAllFullCategoryClient */ .XY.getAllFullCategoryClient(language);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            return data;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    handleGetAllCategory
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7987:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7631);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const handleGetHighlight = async ()=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .productClient.getHighlight */ .Mn.getHighlight();
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
const getProductsByCategoryID = async (body)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .productClient.getProductByCategoryId */ .Mn.getProductByCategoryId(body);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
const getDetailProductsID = async (productId, language)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .productClient.getDetailProductID */ .Mn.getDetailProductID(productId, language);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            const resData = {
                meta: meta,
                data: data
            };
            return resData;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    handleGetHighlight,
    getProductsByCategoryID,
    getDetailProductsID
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5635:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7631);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const handleGetWebInformation = async (params)=>{
    try {
        const response = await _api__WEBPACK_IMPORTED_MODULE_0__/* .WebInformationClient.getWebInformation */ .Tl.getWebInformation(params);
        const { data , meta  } = response.data;
        if (meta.status === 200) {
            return data;
        } else {
            throw new Error(`Unexpected status code: ${meta.status}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return error;
        } else {
            return new Error("Unexpected error");
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    handleGetWebInformation
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2065:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J0": () => (/* reexport safe */ _client_category__WEBPACK_IMPORTED_MODULE_7__.Z),
/* harmony export */   "LW": () => (/* reexport safe */ _admin_category__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "TI": () => (/* reexport safe */ _admin_products__WEBPACK_IMPORTED_MODULE_2__.Z),
/* harmony export */   "YC": () => (/* reexport safe */ _admin_webinformation__WEBPACK_IMPORTED_MODULE_4__.Z),
/* harmony export */   "YI": () => (/* reexport safe */ _admin_ckeditor__WEBPACK_IMPORTED_MODULE_3__.Z),
/* harmony export */   "m3": () => (/* reexport safe */ _admin_login__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "oO": () => (/* reexport safe */ _client_products__WEBPACK_IMPORTED_MODULE_8__.Z),
/* harmony export */   "xP": () => (/* reexport safe */ _client_webinformation__WEBPACK_IMPORTED_MODULE_9__.Z),
/* harmony export */   "zI": () => (/* reexport safe */ _admin_order__WEBPACK_IMPORTED_MODULE_5__.Z),
/* harmony export */   "zq": () => (/* reexport safe */ _admin_contact__WEBPACK_IMPORTED_MODULE_6__.Z)
/* harmony export */ });
/* harmony import */ var _admin_login__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5113);
/* harmony import */ var _admin_category__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4219);
/* harmony import */ var _admin_products__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2684);
/* harmony import */ var _admin_ckeditor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7783);
/* harmony import */ var _admin_webinformation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3074);
/* harmony import */ var _admin_order__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5316);
/* harmony import */ var _admin_contact__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6670);
/* harmony import */ var _client_category__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9077);
/* harmony import */ var _client_products__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7987);
/* harmony import */ var _client_webinformation__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5635);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_admin_login__WEBPACK_IMPORTED_MODULE_0__, _admin_category__WEBPACK_IMPORTED_MODULE_1__, _admin_products__WEBPACK_IMPORTED_MODULE_2__, _admin_ckeditor__WEBPACK_IMPORTED_MODULE_3__, _admin_webinformation__WEBPACK_IMPORTED_MODULE_4__, _admin_order__WEBPACK_IMPORTED_MODULE_5__, _admin_contact__WEBPACK_IMPORTED_MODULE_6__, _client_category__WEBPACK_IMPORTED_MODULE_7__, _client_products__WEBPACK_IMPORTED_MODULE_8__, _client_webinformation__WEBPACK_IMPORTED_MODULE_9__]);
([_admin_login__WEBPACK_IMPORTED_MODULE_0__, _admin_category__WEBPACK_IMPORTED_MODULE_1__, _admin_products__WEBPACK_IMPORTED_MODULE_2__, _admin_ckeditor__WEBPACK_IMPORTED_MODULE_3__, _admin_webinformation__WEBPACK_IMPORTED_MODULE_4__, _admin_order__WEBPACK_IMPORTED_MODULE_5__, _admin_contact__WEBPACK_IMPORTED_MODULE_6__, _client_category__WEBPACK_IMPORTED_MODULE_7__, _client_products__WEBPACK_IMPORTED_MODULE_8__, _client_webinformation__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// services cho administrator







// services cho client




__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5899:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function getAccessTokenFromCookie() {
    // Lấy tất cả các cookie hiện tại
    const cookies = document.cookie.split(";");
    // Tìm và trích xuất giá trị của accessToken từ cookie
    for(let i = 0; i < cookies.length; i++){
        const cookie = cookies[i].trim();
        // Kiểm tra xem cookie có bắt đầu bằng 'accessToken=' hay không
        if (cookie.startsWith("accessToken=")) {
            // Trích xuất giá trị accessToken từ cookie
            const accessToken = cookie.substring("accessToken=".length);
            // Trả về giá trị accessToken
            return accessToken;
        }
    }
    // Nếu không tìm thấy accessToken trong cookie, trả về rỗng ""
    return "";
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    getAccessTokenFromCookie
});


/***/ }),

/***/ 206:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function getSelectKeys(url, level) {
    let selectedKeys = "";
    let openKeys = "";
    if (url === "/admin") {
        selectedKeys = "1";
        openKeys = "";
        return {
            selectedKeys: selectedKeys,
            openKeys: openKeys
        };
    } else if (url.includes("/admin/don-hang")) {
        openKeys = "sub1";
        if (url === "/admin/don-hang") {
            selectedKeys = "4";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/don-hang/don-hang-chua-xu-ly") {
            selectedKeys = "2";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/don-hang/don-hang-da-xu-ly") {
            selectedKeys = "3";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else {
            return {
                openKeys: openKeys
            };
        }
    } else if (url.includes("/admin/lien-he")) {
        openKeys = "sub2";
        if (url === "/admin/lien-he") {
            selectedKeys = "10";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/lien-he/lien-he-da-xu-ly") {
            selectedKeys = "8";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/lien-he/lien-he-chua-xu-ly") {
            selectedKeys = "9";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else {
            return {
                openKeys: openKeys
            };
        }
    } else if (url.includes("/admin/danh-muc")) {
        openKeys = "sub3";
        if (url === "/admin/danh-muc") {
            selectedKeys = "12";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/danh-muc/danh-muc-cap-1") {
            selectedKeys = "13";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/danh-muc/danh-muc-cap-2") {
            selectedKeys = "14";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/danh-muc/tao-moi-danh-muc") {
            if (level === "1") {
                selectedKeys = "15";
                return {
                    selectedKeys: selectedKeys,
                    openKeys: openKeys
                };
            } else if (level === "2") {
                selectedKeys = "16";
                return {
                    selectedKeys: selectedKeys,
                    openKeys: openKeys
                };
            }
        }
    } else if (url.includes("/admin/san-pham")) {
        openKeys = "sub4";
        if (url === "/admin/san-pham/toan-bo-san-pham") {
            selectedKeys = "21";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/san-pham/san-pham-da-an") {
            selectedKeys = "20";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/san-pham/tao-moi-san-pham") {
            selectedKeys = "22";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/san-pham/san-pham-ban-chayc") {
            selectedKeys = "19";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        }
    } else if (url.includes("/admin/layout")) {
        openKeys = "sub5";
        if (url === "/admin/layout/menu") {
            selectedKeys = "25";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/layout/footer") {
            selectedKeys = "26";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        }
    } else if (url.includes("/admin/he-thong")) {
        openKeys = "sub6";
        if (url === "/admin/he-thong/trang-chu") {
            selectedKeys = "29";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/he-thong/gioi-thieu") {
            selectedKeys = "30";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/he-thong/tuyen-dung") {
            selectedKeys = "31";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/he-thong/lien-he") {
            selectedKeys = "32";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        }
    } else if (url.includes("/admin/bai-viet")) {
        openKeys = "sub7";
        if (url === "/admin/bai-viet") {
            selectedKeys = "35";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/bai-viet/bai-viet-bi-an") {
            selectedKeys = "36";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/bai-viet/them-bai-viet") {
            selectedKeys = "37";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        }
    } else if (url.includes("/admin/user")) {
        openKeys = "sub8";
        if (url === "/admin/user/list") {
            selectedKeys = "40";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        } else if (url === "/admin/user/add") {
            selectedKeys = "41";
            return {
                selectedKeys: selectedKeys,
                openKeys: openKeys
            };
        }
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    getSelectKeys
});


/***/ }),

/***/ 6418:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function formatDateTime(inputDateTime, leng) {
    if (inputDateTime === null || inputDateTime === undefined) {
        return "";
    }
    if (leng === "en") {
        const dateObj = new Date(inputDateTime);
        // Lấy tên của ngày trong tuần
        const weekday = [
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday"
        ];
        const dayOfWeek = weekday[dateObj.getDay()];
        // Lấy ngày, tháng và năm
        const day = dateObj.getDate();
        const month = dateObj.getMonth() + 1; // Vì tháng được đếm từ 0, nên cần cộng thêm 1
        const year = dateObj.getFullYear();
        // Định dạng lại ngày tháng
        const formattedDate = `${dayOfWeek}, ${day < 10 ? "0" + day : day}/${month < 10 ? "0" + month : month}/${year}`;
        return formattedDate;
    }
    const dateObj = new Date(inputDateTime);
    // Lấy tên của ngày trong tuần
    const weekday = [
        "Chủ Nhật",
        "Thứ Hai",
        "Thứ Ba",
        "Thứ Tư",
        "Thứ Năm",
        "Thứ S\xe1u",
        "Thứ Bảy"
    ];
    const dayOfWeek = weekday[dateObj.getDay()];
    // Lấy ngày, tháng và năm
    const day = dateObj.getDate();
    const month = dateObj.getMonth() + 1; // Vì tháng được đếm từ 0, nên cần cộng thêm 1
    const year = dateObj.getFullYear();
    // Định dạng lại ngày tháng
    const formattedDate = `${dayOfWeek}, ngày ${day < 10 ? "0" + day : day}/${month < 10 ? "0" + month : month}/${year}`;
    return formattedDate;
}
function formatExacthlyTime(inputDateTime) {
    if (inputDateTime === null || inputDateTime === undefined) {
        return "";
    }
    const dateObj = new Date(inputDateTime);
    // Lấy tên của ngày trong tuần
    const weekday = [
        "Chủ Nhật",
        "Thứ Hai",
        "Thứ Ba",
        "Thứ Tư",
        "Thứ Năm",
        "Thứ S\xe1u",
        "Thứ Bảy"
    ];
    const dayOfWeek = weekday[dateObj.getDay()];
    // Lấy ngày, tháng và năm
    const day = dateObj.getDate();
    const month = dateObj.getMonth() + 1; // Vì tháng được đếm từ 0, nên cần cộng thêm 1
    const year = dateObj.getFullYear();
    // Lấy giờ và phút
    const hours = dateObj.getHours();
    const minutes = dateObj.getMinutes();
    // Định dạng lại ngày tháng, giờ và phút
    const formattedDate = `${dayOfWeek}, ngày ${day < 10 ? "0" + day : day}/${month < 10 ? "0" + month : month}/${year}, ${hours < 10 ? "0" + hours : hours}:${minutes < 10 ? "0" + minutes : minutes}`;
    return formattedDate;
}
function formatExacthlyTimeTable(inputDateTime) {
    if (inputDateTime === null || inputDateTime === undefined) {
        return "";
    }
    const dateObj = new Date(inputDateTime);
    // Chuyển múi giờ từ UTC sang múi giờ Việt Nam (GPT +7)
    const vietnamTimeZoneOffset = 7 * 60; // Đổi thành phút
    dateObj.setMinutes(dateObj.getMinutes() + vietnamTimeZoneOffset);
    // Lấy ngày, tháng và năm
    const day = dateObj.getDate();
    const month = dateObj.getMonth() + 1; // Vì tháng được đếm từ 0, nên cần cộng thêm 1
    const year = dateObj.getFullYear();
    // Lấy giờ và phút
    const hours = dateObj.getHours();
    const minutes = dateObj.getMinutes();
    // Định dạng lại ngày tháng, giờ và phút
    const formattedDate = `${day < 10 ? "0" + day : day}/${month < 10 ? "0" + month : month}/${year}, ${hours < 10 ? "0" + hours : hours}:${minutes < 10 ? "0" + minutes : minutes}`;
    return formattedDate;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    formatDateTime,
    formatExacthlyTime,
    formatExacthlyTimeTable
});


/***/ }),

/***/ 3749:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const diacritic = __webpack_require__(9843);
function removeDiacriticalMarks(str) {
    return diacritic.clean(str);
}
;
function replaceSpacesWithDash(str) {
    return str.replace(/\s+/g, "-");
}
;
function convertValueWithDashes(value) {
    const strWithoutDiacriticalMarks = removeDiacriticalMarks(value);
    const strWithDashes = replaceSpacesWithDash(strWithoutDiacriticalMarks);
    return strWithDashes;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    removeDiacriticalMarks,
    replaceSpacesWithDash,
    convertValueWithDashes
});


/***/ }),

/***/ 9402:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function removeUploadPath(str) {
    return str.replace(/^uploads\/product\//, "");
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    removeUploadPath
});


/***/ }),

/***/ 6449:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_0__]);
react_toastify__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

function successNotify(str, action) {
    react_toastify__WEBPACK_IMPORTED_MODULE_0__.toast.success(str, {
        position: "top-right",
        autoClose: 1200,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light"
    });
}
;
function errorNotify(str) {
    react_toastify__WEBPACK_IMPORTED_MODULE_0__.toast.error(str, {
        position: "top-right",
        autoClose: 1200,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light"
    });
}
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    successNotify,
    errorNotify
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9343:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Co": () => (/* reexport safe */ _HandleString__WEBPACK_IMPORTED_MODULE_2__.Z),
/* harmony export */   "J3": () => (/* reexport safe */ _DasbroahAdmin__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "Vj": () => (/* reexport safe */ _Cookie__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "mz": () => (/* reexport safe */ _Diacritic__WEBPACK_IMPORTED_MODULE_3__.Z),
/* harmony export */   "ou": () => (/* reexport safe */ _DateTime__WEBPACK_IMPORTED_MODULE_5__.Z),
/* harmony export */   "v0": () => (/* reexport safe */ _Message__WEBPACK_IMPORTED_MODULE_4__.Z)
/* harmony export */ });
/* harmony import */ var _Cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5899);
/* harmony import */ var _DasbroahAdmin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(206);
/* harmony import */ var _HandleString__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9402);
/* harmony import */ var _Diacritic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3749);
/* harmony import */ var _Message__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6449);
/* harmony import */ var _DateTime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6418);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Message__WEBPACK_IMPORTED_MODULE_4__]);
_Message__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;